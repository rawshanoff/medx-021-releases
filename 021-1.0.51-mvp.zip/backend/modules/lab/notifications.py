"""
Lab notifications service for Telegram.
"""
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from backend.modules.lab.models import LabOrder, LabResult
from backend.modules.patients.models import Patient

logger = logging.getLogger("medx.lab_notifications")


async def send_result_notification(order: LabOrder, db: AsyncSession) -> bool:
    """
    Send Telegram notification to patient when lab results are ready.
    
    Args:
        order: LabOrder instance
        db: AsyncSession for DB queries
    
    Returns:
        True if notification sent, False otherwise
    """
    try:
        # Import bot here to avoid circular imports
        from backend.core.telegram_bot import bot
        
        if not bot:
            logger.warning(f"Telegram bot not initialized. Skipping notification for order {order.id}")
            return False
        
        # Fetch patient with eager loading
        patient_result = await db.execute(
            select(Patient).where(Patient.id == order.patient_id)
        )
        patient = patient_result.scalars().first()
        
        if not patient or not patient.telegram_chat_id:
            logger.debug(f"Patient {order.patient_id} has no telegram_chat_id. Skipping notification.")
            return False
        
        # Fetch order details with results
        order_result = await db.execute(
            select(LabOrder)
            .options(
                selectinload(LabOrder.results).selectinload(LabResult.test),
                selectinload(LabOrder.patient),
            )
            .where(LabOrder.id == order.id)
        )
        full_order = order_result.scalars().first()
        
        if not full_order or not full_order.results:
            logger.warning(f"Order {order.id} has no results. Skipping notification.")
            return False
        
        # Build message
        message = "📋 *Результаты анализов готовы!*\n\n"
        message += f"*Клиника MedX*\n"
        
        has_abnormal = False
        for result in full_order.results:
            test_name = result.test.name if result.test else "Unknown"
            units = result.test.units or ""
            value = result.value or "—"
            
            if result.is_abnormal:
                has_abnormal = True
                message += f"⚠️ *{test_name}*: `{value}` {units}\n"
            else:
                message += f"✅ *{test_name}*: `{value}` {units}\n"
        
        if result.comment:
            message += f"\n💬 {result.comment}\n"
        
        message += "\n_Берегите своё здоровье!_"
        
        # Send via bot
        await bot.send_message(
            chat_id=patient.telegram_chat_id,
            text=message,
            parse_mode="Markdown",
        )
        
        logger.info(f"Notification sent to patient {patient.id} (chat_id={patient.telegram_chat_id}) for order {order.id}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to send result notification for order {order.id}: {e}")
        return False
