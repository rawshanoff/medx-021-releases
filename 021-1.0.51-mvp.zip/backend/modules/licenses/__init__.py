"""Licensing endpoints (upload/status)."""
