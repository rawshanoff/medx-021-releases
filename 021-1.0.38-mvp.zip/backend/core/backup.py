import asyncio
import logging
import os
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path

from backend.core.config import settings
from backend.core.database import SessionLocal
from backend.modules.system.models import SystemSetting
from sqlalchemy import select

logger = logging.getLogger("medx.backup")

PROJECT_ROOT = Path(__file__).resolve().parents[2]
BACKUP_ROOT = PROJECT_ROOT / "backups"


def _normalize_db_url(db_url: str) -> str:
    return (
        db_url.replace("postgresql+asyncpg://", "postgresql://")
        .replace("postgresql+psycopg2://", "postgresql://")
        .strip()
    )


def _cleanup_old_backups(keep_days: int) -> None:
    if not BACKUP_ROOT.exists():
        return
    cutoff = datetime.now(timezone.utc) - timedelta(days=keep_days)
    for path in BACKUP_ROOT.rglob("*.sql"):
        try:
            mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
            if mtime < cutoff:
                path.unlink(missing_ok=True)
        except Exception:
            logger.exception("Failed to remove old backup: %s", path)


def _run_pg_dump(keep_days: int) -> dict:
    BACKUP_ROOT.mkdir(parents=True, exist_ok=True)
    date_dir = datetime.now().strftime("%Y-%m-%d")
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = BACKUP_ROOT / date_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    out_file = out_dir / f"medx_{ts}.sql"

    db_url = os.getenv("DATABASE_URL", settings.DATABASE_URL)
    db_url = _normalize_db_url(db_url)

    cmd = ["pg_dump", db_url]
    logger.info("Running backup to %s", out_file)
    with out_file.open("wb") as fh:
        res = subprocess.run(cmd, stdout=fh, stderr=subprocess.PIPE)
    if res.returncode != 0:
        err = res.stderr.decode(errors="ignore")
        raise RuntimeError(err or "pg_dump failed")

    size = out_file.stat().st_size
    if size < 1000:
        raise RuntimeError("Backup file too small, possibly incomplete")

    _cleanup_old_backups(keep_days)
    return {"path": str(out_file), "size": size}


async def run_backup_now(keep_days: int) -> dict:
    return await asyncio.to_thread(_run_pg_dump, keep_days)


async def _load_backup_settings() -> list[tuple[int, dict]]:
    async with SessionLocal() as db:
        result = await db.execute(
            select(SystemSetting).where(
                SystemSetting.key == "backup_settings",
                SystemSetting.deleted_at.is_(None),
            )
        )
        rows = []
        for setting in result.scalars().all():
            if isinstance(setting.value, dict):
                rows.append((setting.user_id, setting.value))
        return rows


async def _update_backup_status(user_id: int, status: dict) -> None:
    async with SessionLocal() as db:
        result = await db.execute(
            select(SystemSetting).where(
                SystemSetting.user_id == user_id,
                SystemSetting.key == "backup_status",
                SystemSetting.deleted_at.is_(None),
            )
        )
        setting = result.scalars().first()
        if setting:
            setting.value = status
        else:
            db.add(SystemSetting(user_id=user_id, key="backup_status", value=status))
        await db.commit()


async def _update_backup_settings(user_id: int, value: dict) -> None:
    async with SessionLocal() as db:
        result = await db.execute(
            select(SystemSetting).where(
                SystemSetting.user_id == user_id,
                SystemSetting.key == "backup_settings",
                SystemSetting.deleted_at.is_(None),
            )
        )
        setting = result.scalars().first()
        if setting:
            setting.value = value
            await db.commit()


async def backup_scheduler(stop_event: asyncio.Event) -> None:
    logger.info("Backup scheduler started")
    while not stop_event.is_set():
        try:
            settings_list = await _load_backup_settings()
            now = datetime.now(timezone.utc)
            for user_id, cfg in settings_list:
                if not cfg.get("enabled"):
                    continue
                interval_hours = int(cfg.get("intervalHours") or 24)
                keep_days = int(cfg.get("keepDays") or 30)

                last_run = cfg.get("lastRunAt")
                last_dt = None
                if isinstance(last_run, str):
                    try:
                        last_dt = datetime.fromisoformat(last_run)
                    except ValueError:
                        last_dt = None
                if last_dt and now - last_dt < timedelta(hours=interval_hours):
                    continue

                try:
                    result = await run_backup_now(keep_days)
                    cfg = {**cfg, "lastRunAt": now.isoformat()}
                    await _update_backup_settings(user_id, cfg)
                    await _update_backup_status(
                        user_id,
                        {
                            "ok": True,
                            "lastRunAt": cfg["lastRunAt"],
                            "lastPath": result.get("path"),
                            "size": result.get("size"),
                        },
                    )
                except Exception as err:
                    await _update_backup_status(
                        user_id,
                        {
                            "ok": False,
                            "lastRunAt": now.isoformat(),
                            "error": str(err),
                        },
                    )
        except Exception:
            logger.exception("Backup scheduler loop failed")

        try:
            await asyncio.wait_for(stop_event.wait(), timeout=300)
        except asyncio.TimeoutError:
            pass
