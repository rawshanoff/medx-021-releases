"""add queue notes and unique manual_queue_number per doctor per day

Revision ID: b00000000002
Revises: a00000000001
Create Date: 2026-02-12

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "b00000000002"
down_revision: Union[str, None] = "a00000000001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("queue_items", sa.Column("notes", sa.Text(), nullable=True))

    # Resolve duplicates before creating unique index: keep first (min id), set manual_queue_number=NULL for rest
    op.execute("""
        WITH duplicates AS (
            SELECT id, ROW_NUMBER() OVER (
                PARTITION BY doctor_id, queue_date, manual_queue_number
                ORDER BY id
            ) AS rn
            FROM queue_items
            WHERE manual_queue_number IS NOT NULL AND deleted_at IS NULL
        )
        UPDATE queue_items qi
        SET manual_queue_number = NULL
        FROM duplicates d
        WHERE qi.id = d.id AND d.rn > 1
    """)

    # Unique manual_queue_number per (doctor_id, queue_date) when not null
    op.execute("""
        CREATE UNIQUE INDEX ix_queue_items_doctor_date_manual_unique
        ON queue_items (doctor_id, queue_date, manual_queue_number)
        WHERE manual_queue_number IS NOT NULL AND deleted_at IS NULL
    """)


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS ix_queue_items_doctor_date_manual_unique")
    op.drop_column("queue_items", "notes")
