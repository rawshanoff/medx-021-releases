import logging
from datetime import datetime, timezone, date
from typing import Optional

from backend.core.audit import log_action
from backend.core.config import settings
from backend.core.database import get_db
from backend.core.features import FEATURE_CORE, FEATURE_FINANCE_BASIC
from backend.core.licenses import license_manager
from backend.modules.auth import require_roles
from backend.modules.finance.models import (
    Expense,
    FinanceAuditLog,
    PaymentMethod,
    Shift,
    Transaction,
)
from backend.modules.finance.schemas import (
    ExpenseCreate,
    ExpenseRead,
    ReceiptRead,
    RefundCreate,
    ReportXRead,
    ReportZRead,
    ShiftCreate,
    ShiftRead,
    TransactionCreate,
    TransactionRead,
)
from backend.modules.users.models import User, UserRole
from backend.modules.lab.models import LabOrder, LabResult, LabOrderStatus
from backend.modules.doctors.models import DoctorService
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select, text, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

router = APIRouter()
logger = logging.getLogger("medx")
_advisory_lock_warned = False


@router.get("/health")
async def finance_health():
    """Health check for finance module"""
    return {"status": "ok", "module": "finance"}


async def _acquire_shift_lock(db: AsyncSession) -> None:
    """Serialize shift operations (open/close/pay) to avoid races.

    We use Postgres advisory transaction lock. If DB doesn't support it, we skip.
    """
    global _advisory_lock_warned
    bind = db.get_bind()
    dialect_name = bind.dialect.name if bind is not None else ""
    if dialect_name and dialect_name != "postgresql":
        if not _advisory_lock_warned:
            logger.warning(
                "Advisory locks are not supported for %s",
                dialect_name,
            )
            _advisory_lock_warned = True
        return
    try:
        await db.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": 21_001})
    except Exception:
        # best-effort (e.g., sqlite in some environments)
        logger.debug("Advisory shift lock unavailable", exc_info=True)
        return


async def check_finance_license():
    """Check if Finance module is licensed.

    Raises HTTPException if finance features are not activated.
    Finance requires either FEATURE_FINANCE_BASIC or FEATURE_CORE license.
    """
    features = license_manager.get_active_features()
    if FEATURE_FINANCE_BASIC not in features and FEATURE_CORE not in features:
        raise HTTPException(
            status_code=403,
            detail="Finance module not active. Please upgrade your license.",
        )


async def _audit(
    db: AsyncSession, user: User | None, action: str, details: str | None = None
) -> None:
    db.add(
        FinanceAuditLog(
            user_id=user.id if user else None, action=action, details=details
        )
    )


async def _calculate_shift_totals(
    db: AsyncSession, shift_id: int
) -> tuple[int, int, int]:
    cash_result = await db.execute(
        select(func.sum(Transaction.cash_amount)).where(
            Transaction.shift_id == shift_id,
            Transaction.payment_method == PaymentMethod.MIXED,
            Transaction.deleted_at.is_(None),
        )
    )
    mixed_cash = cash_result.scalar() or 0

    card_result = await db.execute(
        select(func.sum(Transaction.card_amount)).where(
            Transaction.shift_id == shift_id,
            Transaction.payment_method == PaymentMethod.MIXED,
            Transaction.deleted_at.is_(None),
        )
    )
    mixed_card = card_result.scalar() or 0

    transfer_result = await db.execute(
        select(func.sum(Transaction.transfer_amount)).where(
            Transaction.shift_id == shift_id,
            Transaction.payment_method == PaymentMethod.MIXED,
            Transaction.deleted_at.is_(None),
        )
    )
    mixed_transfer = transfer_result.scalar() or 0

    cash_tx_result = await db.execute(
        select(func.sum(Transaction.amount)).where(
            Transaction.shift_id == shift_id,
            Transaction.payment_method == PaymentMethod.CASH,
            Transaction.deleted_at.is_(None),
        )
    )
    cash_total = (cash_tx_result.scalar() or 0) + mixed_cash

    card_tx_result = await db.execute(
        select(func.sum(Transaction.amount)).where(
            Transaction.shift_id == shift_id,
            Transaction.payment_method == PaymentMethod.CARD,
            Transaction.deleted_at.is_(None),
        )
    )
    card_total = (card_tx_result.scalar() or 0) + mixed_card

    transfer_tx_result = await db.execute(
        select(func.sum(Transaction.amount)).where(
            Transaction.shift_id == shift_id,
            Transaction.payment_method == PaymentMethod.TRANSFER,
            Transaction.deleted_at.is_(None),
        )
    )
    transfer_total = (transfer_tx_result.scalar() or 0) + mixed_transfer

    return int(cash_total), int(card_total), int(transfer_total)


def _validate_payment_splits(tx: TransactionCreate) -> None:
    if tx.amount == 0:
        raise HTTPException(
            status_code=400, detail="Transaction amount must be non-zero"
        )
    if tx.payment_method == PaymentMethod.MIXED:
        if tx.amount <= 0:
            raise HTTPException(
                status_code=400, detail="Mixed payment amount must be positive"
            )
        component_total = (
            int(tx.cash_amount) + int(tx.card_amount) + int(tx.transfer_amount)
        )
        if component_total != int(tx.amount):
            raise HTTPException(
                status_code=400,
                detail="Mixed payment components must equal total amount",
            )
        return

    cash = int(tx.cash_amount or 0)
    card = int(tx.card_amount or 0)
    transfer = int(tx.transfer_amount or 0)
    if tx.payment_method == PaymentMethod.CASH:
        if card != 0 or transfer != 0 or (cash not in (0, int(tx.amount))):
            raise HTTPException(
                status_code=400,
                detail="Invalid split for CASH payment",
            )
        return
    if tx.payment_method == PaymentMethod.CARD:
        if cash != 0 or transfer != 0 or (card not in (0, int(tx.amount))):
            raise HTTPException(
                status_code=400,
                detail="Invalid split for CARD payment",
            )
        return
    if tx.payment_method == PaymentMethod.TRANSFER:
        if cash != 0 or card != 0 or (transfer not in (0, int(tx.amount))):
            raise HTTPException(
                status_code=400,
                detail="Invalid split for TRANSFER payment",
            )
        return


async def _assert_shift_totals_consistent(db: AsyncSession, shift: Shift) -> None:
    cash_total, card_total, transfer_total = await _calculate_shift_totals(db, shift.id)
    stored_cash = int(shift.total_cash or 0)
    stored_card = int(shift.total_card or 0)
    stored_transfer = int(shift.total_transfer or 0)

    if (
        stored_cash != cash_total
        or stored_card != card_total
        or stored_transfer != transfer_total
    ):
        logger.error(
            "Shift #%s totals mismatch before payment. "
            "Stored: cash=%s, card=%s, transfer=%s. "
            "Calculated: cash=%s, card=%s, transfer=%s",
            shift.id,
            stored_cash,
            stored_card,
            stored_transfer,
            cash_total,
            card_total,
            transfer_total,
        )
        raise HTTPException(
            status_code=409,
            detail="Shift totals are inconsistent. Contact support.",
        )


@router.get("/shifts/active", response_model=Optional[ShiftRead])
async def get_active_shift(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(
        require_roles(UserRole.ADMIN, UserRole.OWNER, UserRole.CASHIER, UserRole.RECEPTIONIST)
    ),
):
    await check_finance_license()
    existing = await db.execute(
        select(Shift).where(Shift.is_closed == False, Shift.deleted_at.is_(None))
    )
    shift = existing.scalars().first()
    return shift


@router.post("/shifts/open", response_model=ShiftRead, status_code=201)
async def open_shift(
    shift_data: ShiftCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(
        require_roles(UserRole.ADMIN, UserRole.OWNER, UserRole.CASHIER, UserRole.RECEPTIONIST)
    ),
):
    await check_finance_license()
    await _acquire_shift_lock(db)

    # Check if there is already an open shift
    existing = await db.execute(
        select(Shift).where(Shift.is_closed == False, Shift.deleted_at.is_(None))
    )
    if existing.scalars().first():
        raise HTTPException(status_code=400, detail="A shift is already open")

    new_shift = Shift(cashier_id=shift_data.cashier_id)
    db.add(new_shift)
    await db.flush()
    await _audit(
        db,
        user,
        "shift_open",
        f"cashier_id={shift_data.cashier_id}, shift_id={new_shift.id}",
    )
    await db.commit()
    await db.refresh(new_shift)
    return new_shift


def _client_ip(request: Request) -> str | None:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    if request.client:
        return request.client.host
    return None


@router.post("/shifts/close", response_model=ShiftRead)
async def close_shift(
    request: Request,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(
        require_roles(UserRole.ADMIN, UserRole.OWNER, UserRole.CASHIER)
    ),
):
    """Close current shift and verify totals match transactions."""
    await check_finance_license()
    await _acquire_shift_lock(db)
    result = await db.execute(
        select(Shift).where(Shift.is_closed == False, Shift.deleted_at.is_(None))
    )
    shift = result.scalars().first()
    if not shift:
        raise HTTPException(status_code=400, detail="No open shift found")

    cash_total, card_total, transfer_total = await _calculate_shift_totals(db, shift.id)

    # Verify stored totals match calculated
    if (
        shift.total_cash != cash_total
        or shift.total_card != card_total
        or shift.total_transfer != transfer_total
    ):
        logger.error(
            f"Shift #{shift.id} total mismatch on close! "
            f"Stored: cash={shift.total_cash}, card={shift.total_card}, transfer={shift.total_transfer} "
            f"Calculated: cash={cash_total}, card={card_total}, transfer={transfer_total}"
        )
        raise HTTPException(
            status_code=400,
            detail="Shift totals do not match transactions. Contact support.",
        )

    await _audit(
        db,
        user,
        "shift_close",
        f"shift_id={shift.id}, total_cash={shift.total_cash}, total_card={shift.total_card}, total_transfer={shift.total_transfer}",
    )
    close_time = datetime.now(timezone.utc)

    # Mark all waiting queue items as cancelled on shift close
    try:
        from backend.modules.reception.models import QueueItem

        result = await db.execute(
            update(QueueItem)
            .where(
                QueueItem.status == "WAITING",
                QueueItem.deleted_at.is_(None),
            )
            .values(status="CANCELLED")
        )
        logger.info(
            "Shift close: marked waiting queue items as cancelled (%s)",
            result.rowcount,
        )
    except Exception as err:
        logger.exception("Failed to cancel waiting queue items on shift close")
    update_result = await db.execute(
        update(Shift)
        .where(
            Shift.id == shift.id,
            Shift.version == shift.version,
            Shift.is_closed == False,
            Shift.deleted_at.is_(None),
        )
        .values(is_closed=True, end_time=close_time, version=Shift.version + 1)
    )
    if update_result.rowcount != 1:
        await db.rollback()
        raise HTTPException(
            status_code=409, detail="Shift was modified concurrently. Try again."
        )

    await db.commit()
    await db.refresh(shift)
    await log_action(
        user_id=user.id,
        action="UPDATE",
        module="FINANCE",
        entity_id=str(shift.id),
        details={
            "event": "close_shift",
            "shift_id": shift.id,
            "total_cash": shift.total_cash,
            "total_card": shift.total_card,
            "total_transfer": shift.total_transfer,
        },
        ip_address=_client_ip(request),
    )
    return shift


@router.post("/transactions", response_model=TransactionRead, status_code=201)
async def process_payment(
    request: Request,
    tx: TransactionCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(
        require_roles(UserRole.ADMIN, UserRole.OWNER, UserRole.CASHIER)
    ),
):
    logger.info(f"Processing payment: {tx.model_dump()}, user: {user.id}")
    await check_finance_license()
    await _acquire_shift_lock(db)

    # Validate amount is within limits
    if abs(tx.amount) > settings.MAX_TRANSACTION_AMOUNT:
        raise HTTPException(
            status_code=400,
            detail=f"Transaction amount exceeds maximum limit of {settings.MAX_TRANSACTION_AMOUNT:,}",
        )

    # Требуем описание для отрицательных сумм (расход/возврат)
    if tx.amount < 0 and not (tx.description and tx.description.strip()):
        raise HTTPException(
            status_code=400, detail="Description is required for negative transactions"
        )

    _validate_payment_splits(tx)

    # Find current shift
    # Lock active shift row to prevent race conditions on running totals.
    # We still perform atomic UPDATE on totals, but the lock guarantees a single active shift is used consistently.
    logger.info("Looking for open shift")
    result = await db.execute(
        select(Shift)
        .where(Shift.is_closed == False, Shift.deleted_at.is_(None))
        .with_for_update()
    )
    shift = result.scalars().first()
    logger.info(f"Found shift: {shift}")
    if not shift:
        logger.warning("No open shift found")
        raise HTTPException(
            status_code=400, detail="No open shift. Open a shift first."
        )

    await _assert_shift_totals_consistent(db, shift)

    # Idempotency check scoped to shift
    if tx.idempotency_key:
        existing = await db.execute(
            select(Transaction)
            .where(
                Transaction.shift_id == shift.id,
                Transaction.idempotency_key == tx.idempotency_key,
                Transaction.deleted_at.is_(None),
            )
            .options(
                selectinload(Transaction.patient),
                selectinload(Transaction.created_by_user),
            )
        )
        if found := existing.scalars().first():
            logger.info(f"Idempotent hit: {tx.idempotency_key}")
            return found

    logger.info(f"Creating transaction with shift_id: {shift.id}")
    new_tx = Transaction(
        shift_id=shift.id,
        created_by_user_id=user.id,
        **tx.model_dump(),
    )
    logger.info(f"Transaction created: {new_tx.id}")

    # Atomic running totals update (race-safe).
    delta_cash = (
        int(tx.cash_amount)
        if tx.payment_method == PaymentMethod.MIXED
        else (int(tx.amount) if tx.payment_method == PaymentMethod.CASH else 0)
    )
    delta_card = (
        int(tx.card_amount)
        if tx.payment_method == PaymentMethod.MIXED
        else (int(tx.amount) if tx.payment_method == PaymentMethod.CARD else 0)
    )
    delta_transfer = (
        int(tx.transfer_amount)
        if tx.payment_method == PaymentMethod.MIXED
        else (int(tx.amount) if tx.payment_method == PaymentMethod.TRANSFER else 0)
    )
    logger.info(
        f"Deltas: cash={delta_cash}, card={delta_card}, transfer={delta_transfer}"
    )

    stored_cash = int(shift.total_cash or 0)
    stored_card = int(shift.total_card or 0)
    stored_transfer = int(shift.total_transfer or 0)
    if (
        stored_cash + delta_cash < 0
        or stored_card + delta_card < 0
        or stored_transfer + delta_transfer < 0
    ):
        raise HTTPException(
            status_code=400,
            detail="Transaction would result in negative shift totals",
        )

    db.add(new_tx)
    await db.flush()
    logger.info("Transaction flushed")

    update_result = await db.execute(
        update(Shift)
        .where(
            Shift.id == shift.id,
            Shift.version == shift.version,
            Shift.is_closed == False,
            Shift.deleted_at.is_(None),
            func.coalesce(Shift.total_cash, 0) + delta_cash >= 0,
            func.coalesce(Shift.total_card, 0) + delta_card >= 0,
            func.coalesce(Shift.total_transfer, 0) + delta_transfer >= 0,
        )
        .values(
            total_cash=func.coalesce(Shift.total_cash, 0) + delta_cash,
            total_card=func.coalesce(Shift.total_card, 0) + delta_card,
            total_transfer=func.coalesce(Shift.total_transfer, 0) + delta_transfer,
            version=Shift.version + 1,
        )
    )
    if update_result.rowcount != 1:
        await db.rollback()
        raise HTTPException(
            status_code=409, detail="Shift was modified concurrently. Try again."
        )
    logger.info("Shift updated")

    await _audit(
        db,
        user,
        "transaction",
        f"tx_id={new_tx.id}, amount={tx.amount}, method={tx.payment_method}, patient_id={tx.patient_id}",
    )
    
    try:
        await db.commit()
    except IntegrityError:
        # Most likely a concurrent duplicate idempotency_key.
        await db.rollback()
        if tx.idempotency_key:
            existing = await db.execute(
                select(Transaction)
                .where(
                    Transaction.shift_id == shift.id,
                    Transaction.idempotency_key == tx.idempotency_key,
                    Transaction.deleted_at.is_(None),
                )
                .options(
                    selectinload(Transaction.patient),
                    selectinload(Transaction.created_by_user),
                )
            )
            if found := existing.scalars().first():
                logger.debug("Idempotent race hit: %s", tx.idempotency_key)
                return found
        raise

    logger.info("Transaction committed")
    await db.refresh(new_tx)
    reload_res = await db.execute(
        select(Transaction)
        .where(Transaction.id == new_tx.id)
        .options(
            selectinload(Transaction.patient),
            selectinload(Transaction.created_by_user),
        )
    )
    new_tx = reload_res.scalar_one()
    await log_action(
        user_id=user.id,
        action="CREATE",
        module="FINANCE",
        entity_id=str(new_tx.id),
        details={
            "amount": tx.amount,
            "payment_method": str(tx.payment_method),
            "patient_id": tx.patient_id,
        },
        ip_address=_client_ip(request),
    )
    # Auto-create LabOrder if service is linked to a lab test
    try:
        if new_tx.patient_id and new_tx.amount > 0:
            logger.info(f"[LAB] Checking transaction {new_tx.id} for lab order creation")
            
            # Query again with fresh session to get updated data
            tx_check = await db.execute(
                select(Transaction).where(Transaction.id == new_tx.id)
            )
            tx_fresh = tx_check.scalars().first()
            if not tx_fresh:
                logger.warning(f"[LAB] Transaction {new_tx.id} not found after refresh")
                return new_tx
            
            # Find service if doctor_id is set
            if tx_fresh.doctor_id:
                try:
                    doctor_id = int(tx_fresh.doctor_id)
                except (ValueError, TypeError):
                    doctor_id = None
                    logger.warning(f"[LAB] Invalid doctor_id: {tx_fresh.doctor_id}")
                
                if doctor_id:
                    # Get doctor's services to find linked lab test
                    services_result = await db.execute(
                        select(DoctorService).where(
                            DoctorService.doctor_id == doctor_id,
                            DoctorService.linked_lab_test_id.isnot(None),
                            DoctorService.deleted_at.is_(None),
                        )
                    )
                    services = services_result.scalars().all()
                    logger.info(f"[LAB] Query for services: doctor_id={doctor_id}, found {len(services)} services")
                    
                    if services:
                        logger.info(f"[LAB] Found {len(services)} services with linked lab tests for doctor {doctor_id}")
                    else:
                        logger.warning(f"[LAB] No services with linked lab tests found for doctor {doctor_id}")
                        logger.info(f"[LAB] Found {len(services)} services with linked lab tests for doctor {doctor_id}")
                        today = date.today()
                        
                        # Check if order already exists for today
                        existing_order = await db.execute(
                            select(LabOrder).where(
                                LabOrder.patient_id == tx_fresh.patient_id,
                                func.date(LabOrder.created_at) == today,
                                LabOrder.status == LabOrderStatus.PENDING,
                                LabOrder.deleted_at.is_(None),
                            )
                        )
                        lab_order = existing_order.scalars().first()
                        
                        if not lab_order:
                            logger.info(f"[LAB] Creating new LabOrder for patient {tx_fresh.patient_id}")
                            lab_order = LabOrder(
                                patient_id=tx_fresh.patient_id,
                                doctor_id=doctor_id,
                                status=LabOrderStatus.PENDING,
                            )
                            db.add(lab_order)
                            await db.flush()
                            logger.info(f"[LAB] LabOrder {lab_order.id} created")
                        else:
                            logger.info(f"[LAB] Order {lab_order.id} already exists for today")
                        
                        # Add results for all linked services
                        for service in services:
                            if service.linked_lab_test_id:
                                existing_result = await db.execute(
                                    select(LabResult).where(
                                        LabResult.order_id == lab_order.id,
                                        LabResult.test_id == service.linked_lab_test_id,
                                        LabResult.deleted_at.is_(None),
                                    )
                                )
                                if not existing_result.scalars().first():
                                    logger.info(f"[LAB] Creating LabResult for test {service.linked_lab_test_id} in order {lab_order.id}")
                                    result = LabResult(
                                        order_id=lab_order.id,
                                        test_id=service.linked_lab_test_id,
                                        value="",
                                        is_abnormal=False,
                                    )
                                    db.add(result)
                                    logger.info(f"[LAB] LabResult added to session")
                                else:
                                    logger.info(f"[LAB] LabResult for test {service.linked_lab_test_id} already exists")
                        
                        await db.commit()
                        logger.info(f"[LAB] Lab order processing complete")
    except Exception as err:
        logger.error(f"[LAB] Error creating lab order: {err}", exc_info=True)
    
    return new_tx


@router.post("/refund/{transaction_id}", response_model=TransactionRead)
async def refund_payment(
    request: Request,
    transaction_id: int,
    refund_data: RefundCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(
        require_roles(UserRole.ADMIN, UserRole.OWNER, UserRole.CASHIER)
    ),
):
    """Refund payment for unstarted appointment. Creates negative transaction."""
    await check_finance_license()
    await _acquire_shift_lock(db)

    reason = refund_data.reason

    # Find original transaction
    result = await db.execute(
        select(Transaction).where(
            Transaction.id == transaction_id, Transaction.deleted_at.is_(None)
        )
    )
    original_tx = result.scalars().first()
    if not original_tx:
        raise HTTPException(status_code=404, detail="Transaction not found")

    # Check if appointment has started (has appointment record)
    from backend.modules.appointments.models import Appointment

    appointment_result = await db.execute(
        select(Appointment)
        .where(
            Appointment.patient_id == original_tx.patient_id,
            Appointment.created_at >= original_tx.created_at,
            Appointment.deleted_at.is_(None),
        )
        .limit(1)
    )
    if appointment_result.scalars().first():
        raise HTTPException(
            status_code=400, detail="Cannot refund: appointment has already started"
        )

    # Find current shift
    shift_result = await db.execute(
        select(Shift)
        .where(Shift.is_closed == False, Shift.deleted_at.is_(None))
        .with_for_update()
    )
    shift = shift_result.scalars().first()
    if not shift:
        raise HTTPException(
            status_code=400, detail="No open shift. Open a shift first."
        )

    await _assert_shift_totals_consistent(db, shift)

    # Create refund transaction (negative amount)
    refund_tx = Transaction(
        shift_id=shift.id,
        patient_id=original_tx.patient_id,
        amount=-abs(original_tx.amount),  # Always negative
        doctor_id=original_tx.doctor_id,
        created_by_user_id=user.id,
        payment_method=original_tx.payment_method,
        cash_amount=-abs(original_tx.cash_amount),
        card_amount=-abs(original_tx.card_amount),
        transfer_amount=-abs(original_tx.transfer_amount),
        description=f"Refund: {reason.strip()} (original TX #{original_tx.id})",
        related_transaction_id=original_tx.id,
    )

    # Atomic running totals update (negative values for refund)
    delta_cash = (
        -abs(original_tx.cash_amount)
        if original_tx.payment_method == PaymentMethod.MIXED
        else (
            -abs(original_tx.amount)
            if original_tx.payment_method == PaymentMethod.CASH
            else 0
        )
    )
    delta_card = (
        -abs(original_tx.card_amount)
        if original_tx.payment_method == PaymentMethod.MIXED
        else (
            -abs(original_tx.amount)
            if original_tx.payment_method == PaymentMethod.CARD
            else 0
        )
    )
    delta_transfer = (
        -abs(original_tx.transfer_amount)
        if original_tx.payment_method == PaymentMethod.MIXED
        else (
            -abs(original_tx.amount)
            if original_tx.payment_method == PaymentMethod.TRANSFER
            else 0
        )
    )

    stored_cash = int(shift.total_cash or 0)
    stored_card = int(shift.total_card or 0)
    stored_transfer = int(shift.total_transfer or 0)
    if (
        stored_cash + delta_cash < 0
        or stored_card + delta_card < 0
        or stored_transfer + delta_transfer < 0
    ):
        raise HTTPException(
            status_code=400,
            detail="Refund would result in negative shift totals",
        )

    # Update shift totals atomically
    update_result = await db.execute(
        update(Shift)
        .where(
            Shift.id == shift.id,
            Shift.version == shift.version,
            Shift.is_closed == False,
            Shift.deleted_at.is_(None),
            func.coalesce(Shift.total_cash, 0) + delta_cash >= 0,
            func.coalesce(Shift.total_card, 0) + delta_card >= 0,
            func.coalesce(Shift.total_transfer, 0) + delta_transfer >= 0,
        )
        .values(
            total_cash=func.coalesce(Shift.total_cash, 0) + delta_cash,
            total_card=func.coalesce(Shift.total_card, 0) + delta_card,
            total_transfer=func.coalesce(Shift.total_transfer, 0) + delta_transfer,
            version=Shift.version + 1,
        )
    )
    if update_result.rowcount != 1:
        await db.rollback()
        raise HTTPException(
            status_code=409, detail="Shift was modified concurrently. Try again."
        )

    db.add(refund_tx)
    await _audit(
        db,
        user,
        "refund_payment",
        f"Refunded TX #{original_tx.id} for {abs(original_tx.amount)} (reason: {reason})",
    )
    await db.commit()
    await db.refresh(refund_tx)
    reload_res = await db.execute(
        select(Transaction)
        .where(Transaction.id == refund_tx.id)
        .options(
            selectinload(Transaction.patient),
            selectinload(Transaction.created_by_user),
        )
    )
    refund_tx = reload_res.scalar_one()
    await log_action(
        user_id=user.id,
        action="REFUND",
        module="FINANCE",
        entity_id=str(refund_tx.id),
        details={
            "original_tx_id": original_tx.id,
            "amount": abs(original_tx.amount),
            "reason": reason,
        },
        ip_address=_client_ip(request),
    )
    return refund_tx


@router.get("/receipt/{transaction_id}", response_model=ReceiptRead)
async def get_receipt_data(
    transaction_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.OWNER,
            UserRole.RECEPTIONIST,
            UserRole.DOCTOR,
            UserRole.CASHIER,
        )
    ),
):
    """Get receipt data for printing by transaction ID."""
    await check_finance_license()

    # Get transaction with related data
    result = await db.execute(
        select(Transaction)
        .options(
            selectinload(Transaction.patient),
        )
        .where(Transaction.id == transaction_id, Transaction.deleted_at.is_(None))
    )
    tx = result.scalars().first()
    if not tx:
        raise HTTPException(status_code=404, detail="Transaction not found")

    if not tx.patient:
        raise HTTPException(status_code=404, detail="Patient data not found")

    # Get queue item for ticket number
    from backend.modules.reception.models import QueueItem

    queue_result = await db.execute(
        select(QueueItem)
        .options(selectinload(QueueItem.doctor))
        .where(
            QueueItem.patient_id == tx.patient_id,
            QueueItem.created_at <= tx.created_at,
        )
        .order_by(QueueItem.created_at.desc())
        .limit(1)
    )
    queue_item = queue_result.scalars().first()

    ticket_number = queue_item.ticket_number if queue_item else "N/A"
    service_name = tx.doctor_id or "Consultation"  # Fallback if no specific service

    # Payment breakdown for mixed payments
    payment_breakdown = None
    if tx.payment_method == PaymentMethod.MIXED:
        payment_breakdown = {}
        if tx.cash_amount:
            payment_breakdown["cash"] = tx.cash_amount
        if tx.card_amount:
            payment_breakdown["card"] = tx.card_amount
        if tx.transfer_amount:
            payment_breakdown["transfer"] = tx.transfer_amount

    return ReceiptRead(
        receipt_no=f"TX-{tx.id}",
        ticket=ticket_number,
        created_at_iso=tx.created_at.isoformat(),
        patient_name=tx.patient.full_name,
        service_name=service_name,
        amount=tx.amount,
        currency="UZS",  # Assuming Uzbek Som as default
        payment_method=tx.payment_method,
        payment_breakdown=payment_breakdown,
    )


def _parse_range(value: Optional[str], is_end: bool) -> Optional[datetime]:
    if not value:
        return None
    raw = value.strip()
    dt = datetime.fromisoformat(raw)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    if len(raw) <= 10:
        if is_end:
            dt = dt.replace(hour=23, minute=59, second=59, microsecond=999999)
        else:
            dt = dt.replace(hour=0, minute=0, second=0, microsecond=0)
    return dt


@router.get("/reports/basic")
async def get_basic_report(
    type: str,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER, UserRole.CASHIER)),
):
    start = _parse_range(date_from, False)
    end = _parse_range(date_to, True)
    query = (
        select(Transaction)
        .where(Transaction.deleted_at.is_(None))
        .options(
            selectinload(Transaction.patient),
            selectinload(Transaction.created_by_user),
        )
    )
    if start:
        query = query.where(Transaction.created_at >= start)
    if end:
        query = query.where(Transaction.created_at <= end)
    tx_res = await db.execute(query.order_by(Transaction.created_at.asc()))
    txs = tx_res.scalars().all()

    report_type = type.lower()
    rows: list[dict] = []
    totals = {"count": 0, "total": 0, "cash": 0, "card": 0, "transfer": 0}

    def add_split(tx: Transaction, amount: int):
        if tx.payment_method == PaymentMethod.MIXED:
            totals["cash"] += abs(int(tx.cash_amount or 0))
            totals["card"] += abs(int(tx.card_amount or 0))
            totals["transfer"] += abs(int(tx.transfer_amount or 0))
        elif tx.payment_method == PaymentMethod.CARD:
            totals["card"] += amount
        elif tx.payment_method == PaymentMethod.TRANSFER:
            totals["transfer"] += amount
        else:
            totals["cash"] += amount

    if report_type == "refunds":
        for tx in txs:
            if tx.amount < 0 and tx.related_transaction_id:
                amount = abs(int(tx.amount or 0))
                totals["count"] += 1
                totals["total"] += amount
                add_split(tx, amount)
                rows.append(
                    {
                        "date": tx.created_at.isoformat(),
                        "amount": amount,
                        "payment_method": tx.payment_method,
                        "reason": tx.description or "",
                        "original_id": tx.related_transaction_id,
                    }
                )
    elif report_type == "expenses":
        for tx in txs:
            if tx.amount < 0 and not tx.related_transaction_id:
                amount = abs(int(tx.amount or 0))
                totals["count"] += 1
                totals["total"] += amount
                add_split(tx, amount)
                rows.append(
                    {
                        "date": tx.created_at.isoformat(),
                        "amount": amount,
                        "payment_method": tx.payment_method,
                        "description": tx.description or "",
                    }
                )
    elif report_type == "sales_by_day":
        bucket: dict[str, dict] = {}
        for tx in txs:
            if tx.amount <= 0:
                continue
            day = tx.created_at.date().isoformat()
            if day not in bucket:
                bucket[day] = {"date": day, "count": 0, "total": 0}
            bucket[day]["count"] += 1
            bucket[day]["total"] += int(tx.amount or 0)
        rows = list(bucket.values())
        rows.sort(key=lambda r: r["date"])
    elif report_type == "sales_by_doctor":
        bucket: dict[str, dict] = {}
        ids: set[int] = set()
        for tx in txs:
            if tx.amount <= 0:
                continue
            doctor_id = str(tx.doctor_id or "unknown")
            if doctor_id.isdigit():
                ids.add(int(doctor_id))
            if doctor_id not in bucket:
                bucket[doctor_id] = {"doctor_id": doctor_id, "count": 0, "total": 0}
            bucket[doctor_id]["count"] += 1
            bucket[doctor_id]["total"] += int(tx.amount or 0)
        doctor_map: dict[str, str] = {}
        if ids:
            from backend.modules.doctors.models import Doctor

            res = await db.execute(select(Doctor).where(Doctor.id.in_(list(ids))))
            for d in res.scalars().all():
                doctor_map[str(d.id)] = d.full_name
        rows = [
            {
                **v,
                "doctor_name": doctor_map.get(v["doctor_id"], v["doctor_id"]),
            }
            for v in bucket.values()
        ]
        rows.sort(key=lambda r: r["doctor_name"])
    elif report_type == "detailed":
        from backend.modules.doctors.models import Doctor
        from backend.modules.reception.models import QueueItem
        from backend.modules.users.models import User

        doctor_ids: set[int] = set()
        user_ids: set[int] = set()
        for tx in txs:
            if tx.doctor_id and str(tx.doctor_id).isdigit():
                doctor_ids.add(int(tx.doctor_id))
            if tx.created_by_user_id:
                user_ids.add(int(tx.created_by_user_id))
        doctor_map: dict[str, str] = {}
        if doctor_ids:
            res = await db.execute(select(Doctor).where(Doctor.id.in_(list(doctor_ids))))
            for d in res.scalars().all():
                doctor_map[str(d.id)] = d.full_name
        user_map: dict[str, str] = {}
        if user_ids:
            res = await db.execute(select(User).where(User.id.in_(list(user_ids))))
            for u in res.scalars().all():
                user_map[str(u.id)] = u.full_name or u.username or str(u.id)
        queue_by_tx: dict[int, QueueItem] = {}
        qi_res = await db.execute(
            select(QueueItem)
            .options(selectinload(QueueItem.doctor))
            .where(
                QueueItem.transaction_id.in_([t.id for t in txs if t.id]),
                QueueItem.deleted_at.is_(None),
            )
        )
        for qi in qi_res.scalars().all():
            if qi.transaction_id:
                queue_by_tx[qi.transaction_id] = qi
        for tx in txs:
            amount = int(tx.amount or 0)
            qi = queue_by_tx.get(tx.id)
            queue_number = ""
            patient_name = tx.patient_name or ""
            doctor_name = doctor_map.get(str(tx.doctor_id), str(tx.doctor_id or ""))
            if qi:
                queue_number = qi.manual_queue_number or qi.ticket_number or ""
                patient_name = qi.custom_name or qi.patient_name or patient_name
                if qi.doctor:
                    doctor_name = qi.doctor.full_name
            dt = tx.created_at
            date_str = dt.date().isoformat() if dt else ""
            time_str = dt.strftime("%H:%M:%S") if dt else ""
            income_or_expense = "Доход" if amount > 0 else "Расход"
            user_name = user_map.get(str(tx.created_by_user_id), "") if tx.created_by_user_id else ""
            rows.append(
                {
                    "date": date_str,
                    "time": time_str,
                    "id": tx.id,
                    "queue_number": queue_number,
                    "patient_name": patient_name,
                    "doctor_name": doctor_name,
                    "service": tx.description or "",
                    "amount": abs(amount),
                    "income_or_expense": income_or_expense,
                    "user": user_name,
                }
            )
        rows.sort(key=lambda r: (r["date"], r["time"], r.get("id", 0)))
    else:
        # sales_period
        doctor_ids: set[int] = set()
        for tx in txs:
            if tx.amount <= 0:
                continue
            if tx.doctor_id:
                doctor_ids.add(int(tx.doctor_id))
        doctor_map: dict[str, str] = {}
        if doctor_ids:
            from backend.modules.doctors.models import Doctor

            res = await db.execute(select(Doctor).where(Doctor.id.in_(list(doctor_ids))))
            for d in res.scalars().all():
                doctor_map[str(d.id)] = d.full_name
        for tx in txs:
            if tx.amount <= 0:
                continue
            amount = int(tx.amount or 0)
            totals["count"] += 1
            totals["total"] += amount
            add_split(tx, amount)
            doctor_name = doctor_map.get(str(tx.doctor_id), str(tx.doctor_id or ""))
            rows.append(
                {
                    "date": tx.created_at.isoformat(),
                    "amount": amount,
                    "payment_method": tx.payment_method,
                    "patient_name": tx.patient_name,
                    "doctor_id": tx.doctor_id,
                    "doctor_name": doctor_name,
                    "description": tx.description or "",
                }
            )

    return {
        "type": report_type,
        "from": start.isoformat() if start else None,
        "to": end.isoformat() if end else None,
        "rows": rows,
        "totals": totals,
    }


@router.get("/reports/{type}", response_model=ReportXRead | ReportZRead)
async def get_report(
    type: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(
        require_roles(UserRole.ADMIN, UserRole.OWNER, UserRole.CASHIER)
    ),
):
    # Check Active Shift
    res = await db.execute(
        select(Shift).where(Shift.is_closed == False, Shift.deleted_at.is_(None))
    )
    shift = res.scalars().first()

    async def collect_shift_stats(target_shift: Shift):
        tx_res = await db.execute(
            select(Transaction).where(
                Transaction.shift_id == target_shift.id,
                Transaction.deleted_at.is_(None),
            )
        )
        txs = tx_res.scalars().all()
        clients = {t.patient_id for t in txs if t.amount > 0 and t.patient_id}
        total_amount = sum(int(t.amount or 0) for t in txs if t.amount > 0)
        refund_amount = sum(
            abs(int(t.amount or 0))
            for t in txs
            if t.amount < 0 and t.related_transaction_id
        )
        expense_amount = sum(
            abs(int(t.amount or 0))
            for t in txs
            if t.amount < 0 and not t.related_transaction_id
        )
        net_total = int(total_amount - refund_amount - expense_amount)
        return {
            "clients_count": len(clients),
            "total_amount": int(total_amount),
            "refund_amount": int(refund_amount),
            "expense_amount": int(expense_amount),
            "net_total": net_total,
        }

    if type.upper() == "X":
        if not shift:
            return {
                "type": "X-Report",
                "shift_id": None,
                "cashier": None,
                "total_cash": 0,
                "total_card": 0,
                "total_transfer": 0,
                "clients_count": 0,
                "total_amount": 0,
                "refund_amount": 0,
                "expense_amount": 0,
                "net_total": 0,
                "generated_at": datetime.now(timezone.utc),
            }
        # For MVP returning stored running totals
        stats = await collect_shift_stats(shift)
        return {
            "type": "X-Report",
            "shift_id": shift.id,
            "cashier": shift.cashier_id,
            "total_cash": shift.total_cash,
            "total_card": shift.total_card,
            "total_transfer": shift.total_transfer,
            **stats,
            "generated_at": datetime.now(timezone.utc),
        }

    elif type.upper() == "Z":
        # Usually checking last closed shift or closing current
        # For simplicity, return last closed shift
        res = await db.execute(
            select(Shift)
            .where(Shift.is_closed == True, Shift.deleted_at.is_(None))
            .order_by(Shift.end_time.desc())
        )
        last_shift = res.scalars().first()
        if not last_shift:
            return {
                "type": "Z-Report",
                "shift_id": 0,
                "total_cash": 0,
                "total_card": 0,
                "total_transfer": 0,
                "clients_count": 0,
                "total_amount": 0,
                "refund_amount": 0,
                "expense_amount": 0,
                "net_total": 0,
                "total_income": 0,
                "closed_at": None,
            }

        stats = await collect_shift_stats(last_shift)
        return {
            "type": "Z-Report",
            "shift_id": last_shift.id,
            "total_cash": last_shift.total_cash,
            "total_card": last_shift.total_card,
            "total_transfer": last_shift.total_transfer,
            **stats,
            "total_income": last_shift.total_cash
            + last_shift.total_card
            + last_shift.total_transfer,
            "closed_at": last_shift.end_time,
        }
    raise HTTPException(status_code=400, detail="Unknown report type")


@router.post("/expenses", response_model=ExpenseRead, status_code=201)
async def create_expense(
    expense: ExpenseCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(
        require_roles(UserRole.ADMIN, UserRole.OWNER, UserRole.CASHIER)
    ),
):
    """Record an expense from the current shift's cash"""
    # Get active shift
    shift_res = await db.execute(
        select(Shift).where(Shift.is_closed == False, Shift.deleted_at.is_(None))
    )
    active_shift = shift_res.scalars().first()
    if not active_shift:
        raise HTTPException(status_code=400, detail="No active shift")

    # Check if shift has enough cash
    if active_shift.total_cash < expense.amount:
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient cash in shift. Available: {active_shift.total_cash}, Requested: {expense.amount}",
        )

    # Create expense record
    new_expense = Expense(
        shift_id=active_shift.id,
        amount=expense.amount,
        category=expense.category,
        comment=expense.comment,
        created_by=user.username or str(user.id),
    )
    db.add(new_expense)

    # Deduct from shift's cash
    active_shift.total_cash -= expense.amount

    await db.commit()
    await db.refresh(new_expense)
    logger.info(
        f"Expense recorded: {new_expense.amount} {new_expense.category} by {new_expense.created_by}"
    )
    return new_expense


@router.get("/orders/pending")
async def get_pending_orders(
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER, UserRole.RECEPTIONIST)),
):
    """Get all pending payment orders from doctor prescriptions"""
    try:
        from backend.modules.visits.models import PrescribedService, Visit
        from sqlalchemy.orm import selectinload
        
        # Query PrescribedService with related Visit and Patient
        result = await db.execute(
            select(PrescribedService)
            .join(PrescribedService.visit)
            .options(
                selectinload(PrescribedService.visit).selectinload(Visit.patient),
                selectinload(PrescribedService.service),
            )
            .where(PrescribedService.deleted_at.is_(None))
        )
        prescribed_services = result.unique().scalars().all()
        
        # Group by patient and visit
        pending_orders = {}
        for ps in prescribed_services:
            if not ps.visit or not ps.visit.patient:
                continue
                
            patient = ps.visit.patient
            patient_id = patient.id
            
            if patient_id not in pending_orders:
                pending_orders[patient_id] = {
                    "patient_id": patient_id,
                    "patient_name": patient.full_name,
                    "services": [],
                    "total_amount": 0,
                }
            
            # Get service price
            service = ps.service
            amount = int((service.price or 0) * ps.quantity) if service else 0
            
            pending_orders[patient_id]["services"].append({
                "prescribed_service_id": ps.id,
                "service_id": service.id if service else None,
                "service_name": service.name if service else "Unknown",
                "quantity": ps.quantity,
                "price": service.price if service else 0,
                "total": amount,
            })
            pending_orders[patient_id]["total_amount"] += amount
        
        return list(pending_orders.values())
    
    except Exception as e:
        logger.error(f"Failed to get pending orders: {e}", exc_info=True)
        # Return empty list instead of error to prevent UI crashes
        return []


@router.get("/recent-transactions", response_model=list[TransactionRead])
async def get_recent_transactions(
    limit: int = 5,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER, UserRole.CASHIER)),
):
    """Get recent transactions for current shift or last transactions"""
    # Get current active shift
    shift_res = await db.execute(
        select(Shift).where(Shift.is_closed == False, Shift.deleted_at.is_(None))
    )
    active_shift = shift_res.scalars().first()

    if active_shift:
        # Get transactions for active shift
        res = await db.execute(
            select(Transaction)
            .where(
                Transaction.shift_id == active_shift.id,
                Transaction.deleted_at.is_(None),
            )
            .options(
                selectinload(Transaction.patient),
                selectinload(Transaction.created_by_user),
            )
            .order_by(Transaction.created_at.desc())
            .limit(limit)
        )
    else:
        # Get last transactions regardless of shift
        res = await db.execute(
            select(Transaction)
            .where(Transaction.deleted_at.is_(None))
            .options(
                selectinload(Transaction.patient),
                selectinload(Transaction.created_by_user),
            )
            .order_by(Transaction.created_at.desc())
            .limit(limit)
        )

    transactions = res.scalars().all()

    return transactions
