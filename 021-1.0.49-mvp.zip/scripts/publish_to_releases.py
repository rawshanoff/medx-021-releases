#!/usr/bin/env python3
"""
Publish release to medx-021-releases (run locally with gh auth).
Usage: python scripts/publish_to_releases.py --version 1.0.46-mvp
"""
import argparse
import subprocess
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--version", required=True, help="Version (e.g. 1.0.46-mvp)")
    parser.add_argument("--skip-build", action="store_true", help="Skip build, use existing releases/")
    args = parser.parse_args()
    version = args.version
    project_root = Path(__file__).parent.parent
    releases_dir = project_root / "releases"
    zip_name = f"021-{version}.zip"
    zip_path = releases_dir / zip_name
    latest_json = releases_dir / "latest.json"

    if not args.skip_build:
        print("Building release...")
        subprocess.run(
            [
                sys.executable,
                "scripts/build_release.py",
                "--version", version,
                "--skip-frontend-build",
                "--base-url", f"https://github.com/rawshanoff/medx-021-releases/releases/download/v{version}",
                "--notes", f"Release {version}",
            ],
            cwd=project_root,
            check=True,
        )

    if not zip_path.exists():
        print(f"Error: {zip_path} not found")
        sys.exit(1)
    if not latest_json.exists():
        print(f"Error: {latest_json} not found")
        sys.exit(1)

    repo = "rawshanoff/medx-021-releases"
    print(f"Creating release v{version} in {repo}...")
    subprocess.run(
        ["gh", "release", "create", f"v{version}", str(zip_path), "--repo", repo, "--title", f"021 {version}", "--notes", f"Release {version}"],
        cwd=project_root,
        check=True,
    )

    print("Updating latest.json in medx-021-releases main...")
    clone_dir = project_root / "_releases_repo"
    if clone_dir.exists():
        subprocess.run(["git", "pull", "origin", "main"], cwd=clone_dir, check=True)
    else:
        subprocess.run(["git", "clone", f"https://github.com/{repo}.git", str(clone_dir)], cwd=project_root, check=True)

    import shutil
    shutil.copy(latest_json, clone_dir / "latest.json")
    shutil.copy(zip_path, clone_dir / zip_name)
    subprocess.run(["git", "add", "latest.json", zip_name], cwd=clone_dir, check=True)
    subprocess.run(["git", "commit", "-m", f"Release v{version}"], cwd=clone_dir, check=False)
    subprocess.run(["git", "push", "origin", "main"], cwd=clone_dir, check=True)
    print(f"Done. Release v{version} published to https://github.com/{repo}/releases")
