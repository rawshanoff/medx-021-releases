"""
Telegram bot core for patient authentication and notifications.
"""
import logging
from datetime import datetime, timezone, timedelta, date
from aiogram import Bot, Dispatcher, types, Router
from aiogram import F
from aiogram.filters import Command, StateFilter
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, and_, nulls_last, case
from sqlalchemy.orm import joinedload

from backend.core.config import settings
from backend.core.database import SessionLocal
from backend.modules.patients.models import Patient
from backend.modules.lab.models import LabOrder, LabResult, LabTest
from backend.modules.reception.models import QueueItem
from backend.modules.doctors.models import Doctor

logger = logging.getLogger("medx.telegram_bot")

# Clinic timezone UTC+5 (Uzbekistan/Tashkent)
CLINIC_TZ = timezone(timedelta(hours=5))


def _now_local() -> str:
    """Current time in clinic timezone (HH:MM)."""
    return datetime.now(CLINIC_TZ).strftime("%H:%M")


def _format_time(dt: datetime | None) -> str:
    """Format datetime to HH:MM in clinic tz."""
    if not dt:
        return "—"
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    local = dt.astimezone(CLINIC_TZ)
    return local.strftime("%H:%M")


# Bot and Dispatcher instances (exported for use in main.py)
bot: Bot | None = None
dp: Dispatcher | None = None

# Router for handlers
router = Router()


@router.message(Command("start"))
async def cmd_start(message: types.Message):
    """Handle /start command"""
    logger.info(f"Received /start from user {message.from_user.id} (chat_id={message.chat.id})")
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(
                    text="📱 Отправить номер телефона",
                    request_contact=True,
                )
            ]
        ],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    await message.answer(
        "👋 Добро пожаловать в MedX!\n\n"
        "Для доступа к результатам анализов, пожалуйста, поделитесь своим номером телефона.",
        reply_markup=keyboard,
    )


@router.message(StateFilter(None), F.contact)
async def handle_contact(message: types.Message):
    """Handle contact sharing — only when user shares contact."""
    logger.info(f"Received contact from {message.from_user.id}: {message.contact.phone_number}")
    phone = message.contact.phone_number
    chat_id = message.chat.id
    
    logger.info(f"Processing contact: phone={phone}, chat_id={chat_id}")
    
    # Normalize phone: remove +, spaces
    normalized_phone = phone.replace("+", "").replace(" ", "").replace("-", "")
    
    try:
        async with SessionLocal() as session:
            # Search for patient by phone
            result = await session.execute(
                select(Patient).where(
                    Patient.phone.like(f"%{normalized_phone}%"),
                    Patient.deleted_at.is_(None),
                )
            )
            patient = result.scalars().first()
            
            if patient:
                # Update telegram_chat_id
                patient.telegram_chat_id = chat_id
                session.add(patient)
                await session.commit()
                
                await message.answer(
                    "✅ Вы успешно авторизованы!\n\n"
                    "Мы пришлем результаты анализов сюда.",
                    reply_markup=types.ReplyKeyboardRemove(),
                )
                logger.info(f"Patient {patient.id} authenticated via Telegram (chat_id={chat_id})")
            else:
                await message.answer(
                    "❌ Ваш номер не найден в базе клиники.\n\n"
                    "Пожалуйста, обратитесь в регистратуру.",
                    reply_markup=types.ReplyKeyboardRemove(),
                )
                logger.warning(f"Patient not found with phone: {normalized_phone}")
    except Exception as e:
        logger.error(f"Error handling contact: {e}", exc_info=True)
        await message.answer(
            "❌ Произошла ошибка. Пожалуйста, попробуйте позже.",
            reply_markup=types.ReplyKeyboardRemove(),
        )


@router.message(Command("my_history", "history"))
async def cmd_my_history(message: types.Message):
    """Handle /my_history command - show patient's lab results"""
    logger.info(f"Received /my_history from user {message.from_user.id} (chat_id={message.chat.id})")
    
    chat_id = message.chat.id
    
    try:
        async with SessionLocal() as session:
            # Find patient by telegram_chat_id
            result = await session.execute(
                select(Patient).where(
                    Patient.telegram_chat_id == chat_id,
                    Patient.deleted_at.is_(None),
                )
            )
            patient = result.scalars().first()
            
            if not patient:
                await message.answer(
                    "❌ Вы не авторизованы.\n\n"
                    "Нажмите /start и отправьте контакт."
                )
                logger.warning(f"Unauthorized access attempt from chat_id={chat_id}")
                return
            
            # Fetch completed lab orders (last 5)
            orders_result = await session.execute(
                select(LabOrder).options(
                    joinedload(LabOrder.patient),
                    joinedload(LabOrder.doctor),
                    joinedload(LabOrder.results).joinedload(LabResult.test),
                ).where(
                    and_(
                        LabOrder.patient_id == patient.id,
                        LabOrder.status == "COMPLETED",
                        LabOrder.deleted_at.is_(None),
                    )
                ).order_by(desc(LabOrder.completed_at)).limit(5)
            )
            orders = orders_result.scalars().unique().all()
            
            if not orders:
                await message.answer("📭 У вас пока нет готовых анализов.")
                logger.info(f"No completed orders for patient {patient.id}")
                return
            
            # Build response message
            text_lines = ["📂 **Ваша история анализов (последние 5):**\n"]
            
            for order in orders:
                # Format date
                order_date = order.completed_at or order.created_at
                date_str = order_date.strftime("%d.%m.%Y") if order_date else "—"
                
                # Get test names
                test_names = []
                for result in order.results:
                    if result.test and result.test.name:
                        test_names.append(result.test.name)
                test_str = ", ".join(test_names) if test_names else "Анализ"
                
                # Doctor name
                doctor_str = order.doctor.full_name if order.doctor else "Врач не указан"
                
                # Add order header
                text_lines.append(f"📅 **{date_str} — {test_str}**")
                text_lines.append(f"👨‍⚕️ Врач: {doctor_str}")
                
                # Add results
                for result in order.results:
                    if result.test:
                        test_name = result.test.name
                        value = result.value
                        units = result.test.units or ""
                        
                        # Mark abnormal results
                        if result.is_abnormal:
                            text_lines.append(f"⚠️ **{test_name}: {value} {units}**")
                        else:
                            text_lines.append(f"• {test_name}: {value} {units}")
                
                text_lines.append("")  # Empty line between orders
            
            # Send message
            response_text = "\n".join(text_lines)
            await message.answer(response_text, parse_mode="MarkdownV2")
            logger.info(f"Sent history to patient {patient.id}: {len(orders)} orders")
            
    except Exception as e:
        logger.error(f"Error in /my_history: {e}", exc_info=True)
        await message.answer(
            "❌ Произошла ошибка при загрузке истории.\n\n"
            "Пожалуйста, попробуйте позже."
        )


@router.message(Command("observer"))
async def cmd_observer(message: types.Message):
    """Observer: show doctor selection for queue management (staff only)."""
    chat_id = message.chat.id
    try:
        async with SessionLocal() as db:
            from backend.modules.users.models import User, UserRole

            result = await db.execute(
                select(User).where(
                    User.telegram_chat_id == chat_id,
                    User.deleted_at.is_(None),
                    User.is_active == True,
                )
            )
            user = result.scalars().first()
            if not user or user.role not in (
                UserRole.ADMIN,
                UserRole.RECEPTIONIST,
                UserRole.OWNER,
                UserRole.DOCTOR,
            ):
                await message.answer(
                    "❌ Только для сотрудников. Укажите ваш Telegram в настройках системы."
                )
                return

            doctors_result = await db.execute(
                select(Doctor).where(Doctor.deleted_at.is_(None), Doctor.is_active == True)
            )
            doctors = doctors_result.scalars().all()
            if not doctors:
                await message.answer("Нет активных врачей.")
                return

            from backend.core.keyboards import get_observer_doctors_keyboard

            text = "👨‍⚕️ Выберите врача для просмотра очереди:"
            await message.answer(text, reply_markup=get_observer_doctors_keyboard(doctors))
    except Exception as e:
        logger.error(f"Error in /observer: {e}", exc_info=True)
        await message.answer("❌ Ошибка. Попробуйте позже.")


@router.callback_query(lambda q: q.data == "observer:back")
async def handle_observer_back(callback: types.CallbackQuery):
    """Return to doctor selection."""
    await callback.answer()
    try:
        async with SessionLocal() as db:
            doctors_result = await db.execute(
                select(Doctor).where(Doctor.deleted_at.is_(None), Doctor.is_active == True)
            )
            doctors = doctors_result.scalars().all()
        if not doctors:
            await callback.message.edit_text("Нет активных врачей.")
        else:
            from backend.core.keyboards import get_observer_doctors_keyboard
            await callback.message.edit_text(
                "👨‍⚕️ Выберите врача:",
                reply_markup=get_observer_doctors_keyboard(doctors),
            )
    except Exception as e:
        logger.error(f"Error in observer:back: {e}", exc_info=True)
        try:
            await callback.message.answer("❌ Ошибка")
        except Exception:
            pass


@router.callback_query(lambda q: q.data.startswith("observer:doctor:"))
async def handle_observer_doctor(callback: types.CallbackQuery):
    """Show queue for selected doctor."""
    await callback.answer()
    try:
        parts = callback.data.split(":")
        doctor_id = int(parts[2])
        page = int(parts[3]) if len(parts) > 3 else 0
        logger.info("Observer: doctor %s selected by chat_id=%s", doctor_id, callback.from_user.id)
        today = date.today()
        async with SessionLocal() as db:
            items_result = await db.execute(
                select(QueueItem)
                .options(joinedload(QueueItem.patient), joinedload(QueueItem.doctor))
                .where(
                    QueueItem.doctor_id == doctor_id,
                    QueueItem.queue_date == today,
                    QueueItem.deleted_at.is_(None),
                    QueueItem.status.in_(("WAITING", "COMPLETED", "PAID", "IN_PROGRESS", "FINISHED")),
                )
                .order_by(
                    case(
                        (QueueItem.status == "IN_PROGRESS", 0),
                        (QueueItem.status.in_(["COMPLETED", "PAID"]), 1),
                        (QueueItem.status == "WAITING", 2),
                        else_=3,
                    ).asc(),
                    nulls_last(QueueItem.sort_order.asc()),
                    QueueItem.created_at.asc(),
                )
            )
            items = items_result.scalars().unique().all()
            doctor = items[0].doctor if items else None
            doctor_name = doctor.full_name if doctor else f"Врач {doctor_id}"

        if not items:
            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="◀️ К врачам", callback_data="observer:back")],
            ])
            ts = _now_local()
            await callback.message.edit_text(
                f"📋 Очередь {doctor_name}:\n\nПусто.\n\nОбновлено {ts}",
                reply_markup=kb,
            )
            return

        from backend.core.keyboards import get_observer_queue_keyboard, PAGE_SIZE

        start = page * PAGE_SIZE
        page_items = items[start : start + PAGE_SIZE]
        lines = [f"📋 Очередь {doctor_name}:\n"]
        for i, q in enumerate(page_items, start=start + 1):
            pname = q.patient.full_name if q.patient else "—"
            if q.status == "IN_PROGRESS":
                status = "🔴"  # В приёме
            elif q.status in ("COMPLETED", "PAID"):
                status = "✅"  # Оплачен
            elif q.status == "FINISHED":
                status = "✔"  # Закончен
            else:
                status = "⏳"  # Ожидание
            entry = f"{i}. {status} {q.ticket_number or q.id} — {pname}"
            if q.status in ("IN_PROGRESS", "FINISHED"):
                entry += f" (вход {_format_time(q.entered_at)}, выход {_format_time(q.finished_at)})"
            lines.append(entry)

        ts = _now_local()
        text = "\n".join(lines) + f"\n\nОбновлено {ts}"
        try:
            await callback.message.edit_text(
                text,
                reply_markup=get_observer_queue_keyboard(items, doctor_id, page),
            )
        except Exception as edit_err:
            if "message is not modified" not in str(edit_err).lower():
                raise
    except Exception as e:
        logger.error(f"Error in observer:doctor: {e}", exc_info=True)
        try:
            await callback.message.answer("❌ Ошибка")
        except Exception:
            pass


def _parse_observer_callback(data: str) -> tuple[int, int] | None:
    """Parse observer:enter:item_id:doctor_id or observer:late:item_id:doctor_id."""
    parts = data.split(":")
    if len(parts) >= 4:
        return int(parts[2]), int(parts[3])
    if len(parts) == 3:
        return int(parts[2]), 0
    return None


async def _refresh_observer_queue(callback: types.CallbackQuery, doctor_id: int, page: int = 0):
    """Refresh queue message for doctor."""
    if doctor_id <= 0:
        return
    today = date.today()
    async with SessionLocal() as db:
        items_result = await db.execute(
            select(QueueItem)
            .options(joinedload(QueueItem.patient), joinedload(QueueItem.doctor))
            .where(
                QueueItem.doctor_id == doctor_id,
                QueueItem.queue_date == today,
                QueueItem.deleted_at.is_(None),
                QueueItem.status.in_(("WAITING", "COMPLETED", "PAID", "IN_PROGRESS", "FINISHED")),
            )
            .order_by(
                case(
                    (QueueItem.status == "IN_PROGRESS", 0),
                    (QueueItem.status.in_(["COMPLETED", "PAID"]), 1),
                    (QueueItem.status == "WAITING", 2),
                    else_=3,
                ).asc(),
                nulls_last(QueueItem.sort_order.asc()),
                QueueItem.created_at.asc(),
            )
        )
        items = items_result.scalars().unique().all()
        doctor = items[0].doctor if items else None
        doctor_name = doctor.full_name if doctor else f"Врач {doctor_id}"

    from backend.core.keyboards import get_observer_queue_keyboard

    if not items:
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="◀️ К врачам", callback_data="observer:back")],
        ])
        ts = _now_local()
        await callback.message.edit_text(
            f"📋 Очередь {doctor_name}:\n\nПусто.\n\nОбновлено {ts}",
            reply_markup=kb,
        )
        return
    from backend.core.keyboards import PAGE_SIZE

    start = page * PAGE_SIZE
    page_items = items[start : start + PAGE_SIZE]
    lines = [f"📋 Очередь {doctor_name}:\n"]
    for i, q in enumerate(page_items, start=start + 1):
        pname = q.patient.full_name if q.patient else "—"
        if q.status == "IN_PROGRESS":
            status = "🔴"  # В приёме
        elif q.status in ("COMPLETED", "PAID"):
            status = "✅"  # Оплачен
        elif q.status == "FINISHED":
            status = "✔"  # Закончен
        else:
            status = "⏳"  # Ожидание
        entry = f"{i}. {status} {q.ticket_number or q.id} — {pname}"
        if q.status in ("IN_PROGRESS", "FINISHED"):
            entry += f" (вход {_format_time(q.entered_at)}, выход {_format_time(q.finished_at)})"
        lines.append(entry)
    ts = _now_local()
    text = "\n".join(lines) + f"\n\nОбновлено {ts}"
    try:
        await callback.message.edit_text(
            text,
            reply_markup=get_observer_queue_keyboard(items, doctor_id, page),
        )
    except Exception as edit_err:
        if "message is not modified" not in str(edit_err).lower():
            raise


@router.callback_query(lambda q: q.data.startswith("observer:reception:"))
async def handle_observer_reception(callback: types.CallbackQuery):
    """Call patient to reception (Приём) — set IN_PROGRESS, notify patient."""
    await callback.answer("📞 Приём")
    try:
        parts = callback.data.split(":")
        if len(parts) < 4:
            return
        item_id, doctor_id = int(parts[2]), int(parts[3])
        patient_tg_id = None
        doctor_name = ""
        doctor_room = None
        async with SessionLocal() as db:
            from backend.modules.reception.queue_actions import set_in_progress_queue_item

            item = await set_in_progress_queue_item(db, item_id)
            if not item:
                try:
                    await callback.message.answer("Не найдено")
                except Exception:
                    pass
                return
            await db.refresh(item, ["patient", "doctor"])
            if item.patient:
                patient_tg_id = item.patient.telegram_chat_id
            if item.doctor:
                doctor_name = item.doctor.full_name or ""
                doctor_room = item.doctor.room_number
        if patient_tg_id and bot:
            room_str = f"Кабинет {doctor_room}" if doctor_room else "Кабинет"
            text = (
                f"🔔 Ваша очередь!\n\n"
                f"Врач: {doctor_name}\n{room_str}\n\nПожалуйста, проходите."
            )
            try:
                await bot.send_message(chat_id=patient_tg_id, text=text)
            except Exception as e:
                logger.warning("Failed to notify patient: %s", e)
        await _refresh_observer_queue(callback, doctor_id)
    except Exception as e:
        logger.error("Error in observer:reception: %s", e, exc_info=True)
        try:
            await callback.message.answer("❌ Ошибка")
        except Exception:
            pass


@router.callback_query(lambda q: q.data.startswith("observer:enter:"))
async def handle_observer_enter(callback: types.CallbackQuery):
    """Mark patient as finished (Вошёл)."""
    await callback.answer("✅ Вошёл")
    try:
        parsed = _parse_observer_callback(callback.data)
        if not parsed:
            await callback.answer("Ошибка", show_alert=True)
            return
        item_id, doctor_id = parsed
        async with SessionLocal() as db:
            from backend.modules.reception.queue_actions import enter_queue_item

            item = await enter_queue_item(db, item_id)
        if not item:
            try:
                await callback.message.answer("Не найдено")
            except Exception:
                pass
            return
        await _refresh_observer_queue(callback, doctor_id)
    except Exception as e:
        logger.error(f"Error in observer:enter: {e}", exc_info=True)
        try:
            await callback.message.answer("❌ Ошибка")
        except Exception:
            pass


@router.callback_query(lambda q: q.data.startswith("observer:need_pay:"))
async def handle_observer_need_pay(callback: types.CallbackQuery):
    """WAITING patient — show alert: need to pay first."""
    await callback.answer("Нужно оплатить", show_alert=True)


@router.callback_query(lambda q: q.data.startswith("observer:late:"))
async def handle_observer_late(callback: types.CallbackQuery):
    """Mark patient as late (move back)."""
    await callback.answer("⏰ Опоздал")
    try:
        parsed = _parse_observer_callback(callback.data)
        if not parsed:
            await callback.answer("Ошибка", show_alert=True)
            return
        item_id, doctor_id = parsed
        async with SessionLocal() as db:
            from backend.modules.reception.queue_actions import late_queue_item

            item = await late_queue_item(db, item_id)
        if not item:
            try:
                await callback.message.answer("Не найдено")
            except Exception:
                pass
            return
        await _refresh_observer_queue(callback, doctor_id)
    except Exception as e:
        logger.error(f"Error in observer:late: {e}", exc_info=True)
        try:
            await callback.message.answer("❌ Ошибка")
        except Exception:
            pass


@router.message(Command("queue"))
async def cmd_queue(message: types.Message):
    """Handle /queue command - show real-time queue status with ETA"""
    try:
        chat_id = message.from_user.id
        async with SessionLocal() as db:
            # Find patient by telegram_chat_id
            patient_result = await db.execute(
                select(Patient).where(
                    Patient.telegram_chat_id == chat_id,
                    Patient.deleted_at.is_(None),
                )
            )
            patient = patient_result.scalars().first()
            
            if not patient:
                await message.answer(
                    "❌ Вы не авторизованы.\n\n"
                    "Пожалуйста, нажмите /start и отправьте свой номер телефона."
                )
                logger.info(f"Queue check failed: patient not found for chat_id={chat_id}")
                return
            
            # Find active QueueItem for today
            from datetime import date
            from backend.modules.doctors.models import Doctor
            
            today = date.today()
            queue_result = await db.execute(
                select(QueueItem)
                .options(joinedload(QueueItem.doctor))
                .where(
                    and_(
                        QueueItem.patient_id == patient.id,
                        QueueItem.status == "WAITING",
                        QueueItem.queue_date == today,
                        QueueItem.deleted_at.is_(None),
                    )
                )
            )
            queue_item = queue_result.scalars().first()
            
            if not queue_item:
                await message.answer(
                    "✅ У вас нет активной очереди на сегодня."
                )
                logger.info(f"No queue item for patient {patient.id} on {today}")
                return
            
            # Count people ahead
            ahead_result = await db.execute(
                select(QueueItem)
                .where(
                    and_(
                        QueueItem.doctor_id == queue_item.doctor_id,
                        QueueItem.queue_date == today,
                        QueueItem.status == "WAITING",
                        QueueItem.sort_order < queue_item.sort_order,
                        QueueItem.deleted_at.is_(None),
                    )
                )
            )
            count_ahead = len(ahead_result.scalars().all())
            
            # Get doctor name
            doctor_name = queue_item.doctor.full_name if queue_item.doctor else "Врач"
            
            # Format ETA
            eta_text = "Расчет времени..."
            minutes_left = None
            
            if queue_item.estimated_start_time:
                # Convert UTC to local time (assume UTC+5 for MVP, could read from settings)
                eta_dt = queue_item.estimated_start_time
                # If it's naive or UTC, add UTC timezone info
                if eta_dt.tzinfo is None:
                    eta_dt = eta_dt.replace(tzinfo=timezone.utc)
                
                # Convert to UTC+5 (clinic timezone)
                local_tz = timezone(timedelta(hours=5))
                eta_local = eta_dt.astimezone(local_tz)
                eta_time_str = eta_local.strftime("%H:%M")
                
                # Calculate minutes left
                now_utc = datetime.now(timezone.utc)
                delta = queue_item.estimated_start_time - now_utc
                minutes_left = int(delta.total_seconds() / 60)
                
                # Handle past times
                if minutes_left < 0:
                    eta_text = "Сейчас ваша очередь!"
                    minutes_left = 0
                else:
                    eta_text = eta_time_str
            
            # Build response
            text_lines = [
                "🏥 **Статус очереди:**\n",
                f"👨\\-⚕️ Врач: {doctor_name}",
                f"🎫 Ваш талон: **{queue_item.ticket_number}**\n",
                f"👥 Перед вами: {count_ahead} чел\\.",
            ]
            
            if minutes_left is not None:
                text_lines.append(f"⏱ **Примерный вход:** {eta_text} \\(через {minutes_left} мин\\)")
            else:
                text_lines.append("⏱ **Примерный вход:** В порядке живой очереди")
            
            response_text = "\n".join(text_lines)
            await message.answer(response_text, parse_mode="MarkdownV2")
            logger.info(f"Sent queue status to patient {patient.id}: {count_ahead} ahead, ETA: {eta_text}")
    
    except Exception as e:
        logger.error(f"Error in /queue: {e}", exc_info=True)
        await message.answer(
            "❌ Произошла ошибка при получении статуса очереди.\n\n"
            "Пожалуйста, попробуйте позже."
        )


# Feedback functions and handlers
async def send_feedback_request(chat_id: int, visit_id: int, doctor_name: str) -> None:
    """Send feedback request to patient after visit"""
    if not bot:
        logger.warning("Bot not initialized, cannot send feedback request")
        return
    
    try:
        from backend.core.keyboards import get_rating_keyboard
        
        text = (
            f"👨‍⚕️ Прием у врача {doctor_name} завершен\\.\n\n"
            "Пожалуйста, оцените качество обслуживания:"
        )
        keyboard = get_rating_keyboard(visit_id)
        
        await bot.send_message(
            chat_id=chat_id,
            text=text,
            parse_mode="MarkdownV2",
            reply_markup=keyboard,
        )
        logger.info(f"Sent feedback request to chat_id={chat_id} for visit={visit_id}")
    except Exception as e:
        logger.error(f"Failed to send feedback request: {e}", exc_info=True)


@router.callback_query(lambda query: query.data.startswith("rate_visit:"))
async def handle_rating(callback_query: types.CallbackQuery):
    """Handle patient rating feedback"""
    try:
        # Parse callback data
        parts = callback_query.data.split(":")
        if len(parts) != 3:
            await callback_query.answer("Invalid callback data", show_alert=True)
            return
        
        visit_id = int(parts[1])
        score = int(parts[2])
        
        if not (1 <= score <= 5):
            await callback_query.answer("Invalid score", show_alert=True)
            return
        
        # Update visit with rating
        async with SessionLocal() as db:
            from backend.modules.visits.models import Visit
            
            visit = await db.get(Visit, visit_id)
            if not visit:
                await callback_query.answer("Visit not found", show_alert=True)
                return
            
            visit.rating = score
            await db.commit()
            logger.info(f"Recorded rating {score} stars for visit {visit_id}")

        # Edit message to show confirmation
        text = f"✅ Спасибо за вашу оценку \\({score} ⭐\\)\\!"
        try:
            await callback_query.message.edit_text(text, parse_mode="MarkdownV2")
        except Exception as e:
            logger.warning(f"Failed to edit message: {e}")

        # Send follow-up message asking for comment
        comment_text = (
            "Напишите отзыв \\(текстом\\), если хотите\\. "
            "Или нажмите /skip для пропуска\\."
        )
        try:
            await callback_query.message.answer(
                comment_text,
                parse_mode="MarkdownV2",
            )
        except Exception as e:
            logger.warning(f"Failed to send comment request: {e}")

        await callback_query.answer()
        
    except Exception as e:
        logger.error(f"Error in handle_rating: {e}", exc_info=True)
        await callback_query.answer("❌ Произошла ошибка", show_alert=True)


async def init_bot():
    """Initialize bot and dispatcher"""
    global bot, dp
    
    if not settings.PATIENT_BOT_TOKEN:
        logger.warning("PATIENT_BOT_TOKEN not set. Telegram bot disabled.")
        return
    
    try:
        logger.info(f"Initializing bot with token: {settings.PATIENT_BOT_TOKEN[:5]}***")
        bot = Bot(token=settings.PATIENT_BOT_TOKEN)
        dp = Dispatcher()
        
        # Register router
        dp.include_router(router)
        
        logger.info("Telegram bot initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize bot: {e}", exc_info=True)


async def start_bot_polling():
    """Start bot polling (for standalone run)"""
    if not bot or not dp:
        logger.warning("Bot not initialized. Skipping polling.")
        return
    
    try:
        logger.info("Starting bot polling...")
        await dp.start_polling(bot)
    except Exception as e:
        logger.error(f"Bot polling error: {e}")
    finally:
        await bot.session.close()
