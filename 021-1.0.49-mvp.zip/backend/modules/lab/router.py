from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload, joinedload
from datetime import datetime
import logging

from backend.core.database import get_db
from backend.modules.lab import schemas
from backend.modules.lab.models import LabTest, LabOrder, LabResult
from backend.modules.lab.notifications import send_result_notification
from backend.modules.auth import require_roles
from backend.modules.users.models import UserRole

logger = logging.getLogger("medx.lab")

router = APIRouter(tags=["laboratory"])


@router.get("/health")
async def lab_health():
    """Health check for lab module"""
    return {"status": "ok", "module": "lab"}


@router.get("/tests", response_model=list[schemas.LabTestRead])
async def list_lab_tests(db: AsyncSession = Depends(get_db)):
    """List all lab tests"""
    result = await db.execute(select(LabTest))
    return result.scalars().all()


@router.post("/tests", response_model=schemas.LabTestRead)
async def create_lab_test(test: schemas.LabTestCreate, db: AsyncSession = Depends(get_db)):
    """Create a new lab test in catalog"""
    db_test = LabTest(**test.dict())
    db.add(db_test)
    await db.commit()
    await db.refresh(db_test)
    return db_test


@router.put("/tests/{test_id}", response_model=schemas.LabTestRead)
async def update_lab_test(test_id: int, test: schemas.LabTestCreate, db: AsyncSession = Depends(get_db)):
    """Update a lab test"""
    result = await db.execute(select(LabTest).where(LabTest.id == test_id))
    db_test = result.scalars().first()
    if not db_test:
        raise ValueError(f"Test {test_id} not found")
    for key, value in test.dict().items():
        setattr(db_test, key, value)
    await db.commit()
    await db.refresh(db_test)
    return db_test


@router.delete("/tests/{test_id}")
async def delete_lab_test(test_id: int, db: AsyncSession = Depends(get_db)):
    """Delete a lab test"""
    result = await db.execute(select(LabTest).where(LabTest.id == test_id))
    db_test = result.scalars().first()
    if not db_test:
        raise ValueError(f"Test {test_id} not found")
    await db.delete(db_test)
    await db.commit()
    return {"deleted": True}


@router.get("/orders", response_model=list[schemas.LabOrderRead])
async def list_lab_orders(
    status: str = "PENDING",
    patient_id: int | None = None,
    db: AsyncSession = Depends(get_db)
):
    """List lab orders by status and optional patient_id"""
    try:
        query = select(LabOrder).options(
            joinedload(LabOrder.patient),
            joinedload(LabOrder.doctor),
            selectinload(LabOrder.results)
        ).where(LabOrder.deleted_at.is_(None))
        
        if status:
            query = query.where(LabOrder.status == status)
        
        if patient_id:
            query = query.where(LabOrder.patient_id == patient_id)
        
        result = await db.execute(query)
        return result.unique().scalars().all()
    except Exception as e:
        logger.error(f"Failed to fetch lab orders: {e}", exc_info=True)
        return []


@router.post("/orders", response_model=schemas.LabOrderRead)
async def create_lab_order(order: schemas.LabOrderCreate, db: AsyncSession = Depends(get_db)):
    """Create a new lab order for a patient"""
    db_order = LabOrder(**order.dict())
    db.add(db_order)
    await db.commit()
    await db.refresh(db_order)
    return db_order


@router.post("/results", response_model=schemas.LabResultRead)
async def create_lab_result(result: schemas.LabResultCreate, db: AsyncSession = Depends(get_db)):
    """Add a test result to a lab order"""
    db_result = LabResult(**result.dict())
    db.add(db_result)
    await db.commit()
    await db.refresh(db_result)
    return db_result


@router.get("/orders/{order_id}", response_model=schemas.LabOrderDetailRead)
async def get_lab_order_detail(
    order_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Get order details with results and test info"""
    result = await db.execute(
        select(LabOrder)
        .options(selectinload(LabOrder.results).selectinload(LabResult.test))
        .where(LabOrder.id == order_id, LabOrder.deleted_at.is_(None))
    )
    order = result.scalars().first()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order


@router.put("/orders/{order_id}/complete")
async def complete_lab_order(
    order_id: int,
    updates: list[schemas.LabResultUpdate],
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Update results and mark order as completed"""
    order = await db.get(LabOrder, order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    for upd in updates:
        result = await db.get(LabResult, upd.result_id)
        if not result:
            continue
        result.value = upd.value
        result.is_abnormal = upd.is_abnormal
        result.comment = upd.comment

    order.status = "COMPLETED"
    order.completed_at = datetime.now()
    await db.commit()
    
    # Deduct inventory for this order (non-blocking)
    try:
        from backend.modules.inventory.services import deduct_stock_for_test
        for lab_result in order.results:
            await deduct_stock_for_test(db, lab_result.test_id, order_id)
        await db.commit()
        logger.info(f"[LAB] Inventory deducted for order {order_id}")
    except Exception as e:
        logger.error(f"[LAB] Inventory deduction failed: {e}", exc_info=True)
    
    # Send Telegram notification (non-blocking)
    try:
        await send_result_notification(order, db)
    except Exception as e:
        logger.error(f"Failed to send notification: {e}")
    
    return {"status": "completed", "order_id": order_id}
