import logging
from datetime import datetime, timedelta, date
from typing import Optional
from sqlalchemy import select, func, desc, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from fastapi import APIRouter, Depends, HTTPException
from backend.core.database import get_db
from backend.modules.auth import require_roles
from backend.modules.users.models import UserRole
from backend.modules.visits.models import Visit
from backend.modules.doctors.models import Doctor
from backend.modules.analytics.schemas import DoctorRatingStats, RecentFeedback, RatingsResponse

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/ratings", response_model=RatingsResponse)
async def get_ratings(
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Get doctor ratings and recent feedback for a date range"""
    
    # Set default date range (last 30 days)
    if not end_date:
        end_date = date.today()
    if not start_date:
        start_date = end_date - timedelta(days=30)
    
    try:
        # 1. Get doctor stats with ratings
        stats_query = await db.execute(
            select(
                Visit.doctor_id,
                Doctor.full_name,
                func.avg(Visit.rating).label("avg_rating"),
                func.count(Visit.id).label("count"),
            )
            .join(Doctor, Visit.doctor_id == Doctor.id)
            .where(
                and_(
                    Visit.rating.is_not(None),
                    Visit.visit_date >= start_date,
                    Visit.visit_date <= end_date,
                    Visit.deleted_at.is_(None),
                )
            )
            .group_by(Visit.doctor_id, Doctor.full_name)
            .order_by(desc(func.avg(Visit.rating)))
        )
        
        stats = []
        for row in stats_query.all():
            stats.append(
                DoctorRatingStats(
                    doctor_id=row.doctor_id,
                    doctor_name=row.full_name,
                    average_rating=round(float(row.avg_rating or 0), 1),
                    review_count=int(row.count or 0),
                )
            )
        
        # 2. Get recent feedback comments
        feedback_query = await db.execute(
            select(Visit)
            .options(selectinload(Visit.doctor))
            .where(
                and_(
                    Visit.rating.is_not(None),
                    Visit.feedback_comment.is_not(None),
                    Visit.visit_date >= start_date,
                    Visit.visit_date <= end_date,
                    Visit.deleted_at.is_(None),
                )
            )
            .order_by(desc(Visit.visit_date))
            .limit(10)
        )
        
        recent_feedback = []
        for visit in feedback_query.scalars().all():
            recent_feedback.append(
                RecentFeedback(
                    visit_id=visit.id,
                    visit_date=visit.visit_date,
                    doctor_id=visit.doctor_id,
                    doctor_name=visit.doctor.full_name if visit.doctor else "Unknown",
                    rating=visit.rating or 0,
                    comment=visit.feedback_comment or "",
                )
            )
        
        return RatingsResponse(stats=stats, recent_feedback=recent_feedback)
    
    except Exception as e:
        logger.error(f"Error fetching ratings: {e}", exc_info=True)
        # Return empty response instead of error
        return RatingsResponse(stats=[], recent_feedback=[])
