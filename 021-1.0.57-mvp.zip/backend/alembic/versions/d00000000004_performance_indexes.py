"""Add performance indexes for queue and transactions

Revision ID: d00000000004
Revises: c00000000003
Create Date: 2026-02-15

"""
from typing import Sequence, Union

from alembic import op


revision: str = "d00000000004"
down_revision: Union[str, None] = "c00000000003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # queue_items: filter by queue_date + deleted_at (get_queue)
    op.create_index(
        "ix_queue_items_queue_date_deleted",
        "queue_items",
        ["queue_date", "deleted_at"],
        unique=False,
    )
    # queue_items: filter by created_at for range queries (today, 2days)
    op.create_index(
        "ix_queue_items_created_at_deleted",
        "queue_items",
        ["created_at", "deleted_at"],
        unique=False,
    )
    # transactions: filter by shift_id (recent-transactions, totals)
    op.create_index(
        "ix_transactions_shift_id_deleted",
        "transactions",
        ["shift_id", "deleted_at"],
        unique=False,
    )
    # transactions: order by created_at (recent-transactions)
    op.create_index(
        "ix_transactions_created_at",
        "transactions",
        ["created_at"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index("ix_transactions_created_at", table_name="transactions")
    op.drop_index("ix_transactions_shift_id_deleted", table_name="transactions")
    op.drop_index("ix_queue_items_created_at_deleted", table_name="queue_items")
    op.drop_index("ix_queue_items_queue_date_deleted", table_name="queue_items")
