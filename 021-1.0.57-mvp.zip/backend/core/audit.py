"""Enterprise action audit log service.

Logs critical user actions across modules. Failures are logged but never crash the main app.
"""
import logging
from typing import Any

from backend.core.database import SessionLocal
from backend.modules.system.models import ActionLog

logger = logging.getLogger("medx.audit")


async def log_action(
    *,
    user_id: int | None = None,
    action: str,
    module: str,
    entity_id: str | None = None,
    details: dict[str, Any] | str | None = None,
    ip_address: str | None = None,
) -> None:
    """Log an audit action. Failures are caught and logged; never raise."""
    try:
        async with SessionLocal() as session:
            entry = ActionLog(
                user_id=user_id,
                action=action.upper()[:32],
                module=module.upper()[:32],
                entity_id=str(entity_id)[:64] if entity_id is not None else None,
                details=details if isinstance(details, dict) else {"message": str(details)} if details else None,
                ip_address=ip_address[:45] if ip_address else None,
            )
            session.add(entry)
            await session.commit()
    except Exception as e:
        logger.warning("Audit log failed (non-fatal): %s", e, exc_info=True)
