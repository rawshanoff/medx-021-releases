"""initial_schema - single migration for clean install

Revision ID: a00000000001
Revises: None
Create Date: 2026-02-12

Combines all schema changes into one migration for fresh installation.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "a00000000001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Enums
    userrole = sa.Enum("ADMIN", "OWNER", "DOCTOR", "RECEPTIONIST", "CASHIER", name="userrole")
    userrole.create(op.get_bind(), checkfirst=True)

    laborderstatus = sa.Enum(
        "CREATED", "PAID", "SAMPLED", "PROCESSING", "COMPLETED", "CANCELLED",
        "PENDING", "IN_PROGRESS",  # legacy
        name="laborderstatus",
    )
    laborderstatus.create(op.get_bind(), checkfirst=True)

    stockmovementreason = sa.Enum("PURCHASE", "USAGE", "ADJUSTMENT", name="stockmovementreason")
    stockmovementreason.create(op.get_bind(), checkfirst=True)

    # Core tables
    op.create_table(
        "audit_logs",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("action", sa.String(), nullable=False),
        sa.Column("details", sa.String(), nullable=True),
        sa.Column("timestamp", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_audit_logs_id"), "audit_logs", ["id"], unique=False)

    op.create_table(
        "doctors",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("full_name", sa.String(), nullable=False),
        sa.Column("specialty", sa.String(), nullable=True),
        sa.Column("room_number", sa.String(), nullable=True),
        sa.Column("queue_prefix", sa.String(length=1), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_doctors_deleted_at"), "doctors", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_doctors_full_name"), "doctors", ["full_name"], unique=False)
    op.create_index(op.f("ix_doctors_id"), "doctors", ["id"], unique=False)

    op.create_table(
        "patients",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("full_name", sa.String(), nullable=False),
        sa.Column("phone", sa.String(), nullable=False),
        sa.Column("birth_date", sa.Date(), nullable=True),
        sa.Column("gender", sa.String(length=10), nullable=True),
        sa.Column("address", sa.Text(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("category", sa.String(), nullable=True),
        sa.Column("balance", sa.Integer(), nullable=True),
        sa.Column("telegram_chat_id", sa.BigInteger(), nullable=True),
        sa.Column("telegram_username", sa.String(), nullable=True),
        sa.Column("is_blacklisted", sa.Boolean(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_patients_deleted_at"), "patients", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_patients_full_name"), "patients", ["full_name"], unique=False)
    op.create_index(op.f("ix_patients_id"), "patients", ["id"], unique=False)
    op.create_index(op.f("ix_patients_phone"), "patients", ["phone"], unique=False)

    op.create_table(
        "shifts",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("cashier_id", sa.String(), nullable=False),
        sa.Column("start_time", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("end_time", sa.DateTime(timezone=True), nullable=True),
        sa.Column("total_cash", sa.Integer(), nullable=True),
        sa.Column("total_card", sa.Integer(), nullable=True),
        sa.Column("total_transfer", sa.Integer(), nullable=True),
        sa.Column("is_closed", sa.Boolean(), nullable=True),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.CheckConstraint("total_card >= 0", name="ck_shifts_total_card_nonnegative"),
        sa.CheckConstraint("total_cash >= 0", name="ck_shifts_total_cash_nonnegative"),
        sa.CheckConstraint("total_transfer >= 0", name="ck_shifts_total_transfer_nonnegative"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_shifts_deleted_at"), "shifts", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_shifts_id"), "shifts", ["id"], unique=False)

    op.create_table(
        "users",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("username", sa.String(length=50), nullable=False),
        sa.Column("password_hash", sa.String(length=255), nullable=False),
        sa.Column("full_name", sa.String(length=100), nullable=True),
        sa.Column("role", userrole, nullable=False),
        sa.Column("permissions", sa.JSON(), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("last_login", sa.DateTime(timezone=True), nullable=True),
        sa.Column("telegram_chat_id", sa.BigInteger(), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_users_deleted_at"), "users", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_users_id"), "users", ["id"], unique=False)
    op.create_index(op.f("ix_users_username"), "users", ["username"], unique=True)
    op.create_index(op.f("ix_users_telegram_chat_id"), "users", ["telegram_chat_id"], unique=True)

    op.create_table(
        "lab_categories",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_lab_categories_id"), "lab_categories", ["id"], unique=False)
    op.create_index(op.f("ix_lab_categories_name"), "lab_categories", ["name"], unique=False)

    op.create_table(
        "lab_tests",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("code", sa.String(), nullable=True),
        sa.Column("price", sa.Integer(), nullable=True),
        sa.Column("units", sa.String(), nullable=True),
        sa.Column("reference_min", sa.Float(), nullable=True),
        sa.Column("reference_max", sa.Float(), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=True),
        sa.Column("category_id", sa.Integer(), nullable=True),
        sa.Column("duration_minutes", sa.Integer(), nullable=True),
        sa.Column("template_values", sa.JSON(), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["category_id"], ["lab_categories.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("code"),
    )
    op.create_index(op.f("ix_lab_tests_deleted_at"), "lab_tests", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_lab_tests_id"), "lab_tests", ["id"], unique=False)
    op.create_index(op.f("ix_lab_tests_name"), "lab_tests", ["name"], unique=False)

    op.create_table(
        "doctor_services",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("doctor_id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("price", sa.Integer(), nullable=True),
        sa.Column("average_duration_minutes", sa.Integer(), nullable=True),
        sa.Column("priority", sa.Integer(), nullable=True),
        sa.Column("linked_lab_test_id", sa.Integer(), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["doctor_id"], ["doctors.id"]),
        sa.ForeignKeyConstraint(["linked_lab_test_id"], ["lab_tests.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_doctor_services_deleted_at"), "doctor_services", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_doctor_services_id"), "doctor_services", ["id"], unique=False)

    op.create_table(
        "appointments",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=True),
        sa.Column("doctor_id", sa.String(), nullable=True),
        sa.Column("start_time", sa.DateTime(timezone=True), nullable=False),
        sa.Column("end_time", sa.DateTime(timezone=True), nullable=False),
        sa.Column("status", sa.String(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_appointments_deleted_at"), "appointments", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_appointments_id"), "appointments", ["id"], unique=False)

    op.create_table(
        "visits",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("doctor_id", sa.Integer(), nullable=False),
        sa.Column("visit_date", sa.Date(), nullable=False),
        sa.Column("complaints", sa.Text(), nullable=True),
        sa.Column("diagnosis", sa.Text(), nullable=True),
        sa.Column("recommendations", sa.Text(), nullable=True),
        sa.Column("rating", sa.Integer(), nullable=True),
        sa.Column("feedback_comment", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["doctor_id"], ["doctors.id"]),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_visits_deleted_at"), "visits", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_visits_doctor_id"), "visits", ["doctor_id"], unique=False)
    op.create_index(op.f("ix_visits_id"), "visits", ["id"], unique=False)
    op.create_index(op.f("ix_visits_patient_id"), "visits", ["patient_id"], unique=False)
    op.create_index(op.f("ix_visits_visit_date"), "visits", ["visit_date"], unique=False)

    op.create_table(
        "prescribed_services",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("visit_id", sa.Integer(), nullable=False),
        sa.Column("service_id", sa.Integer(), nullable=False),
        sa.Column("quantity", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["service_id"], ["doctor_services.id"]),
        sa.ForeignKeyConstraint(["visit_id"], ["visits.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_prescribed_services_deleted_at"), "prescribed_services", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_prescribed_services_id"), "prescribed_services", ["id"], unique=False)
    op.create_index(op.f("ix_prescribed_services_visit_id"), "prescribed_services", ["visit_id"], unique=False)

    op.create_table(
        "visit_attachments",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("visit_id", sa.Integer(), nullable=False),
        sa.Column("file_path", sa.String(), nullable=False),
        sa.Column("filename", sa.String(), nullable=False),
        sa.Column("file_type", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["visit_id"], ["visits.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_visit_attachments_deleted_at"), "visit_attachments", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_visit_attachments_id"), "visit_attachments", ["id"], unique=False)
    op.create_index(op.f("ix_visit_attachments_visit_id"), "visit_attachments", ["visit_id"], unique=False)

    op.create_table(
        "lab_orders",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("doctor_id", sa.Integer(), nullable=True),
        sa.Column("status", laborderstatus, nullable=False),
        sa.Column("total_amount", sa.Integer(), server_default="0", nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["doctor_id"], ["doctors.id"]),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_lab_orders_deleted_at"), "lab_orders", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_lab_orders_id"), "lab_orders", ["id"], unique=False)
    op.create_index(op.f("ix_lab_orders_patient_id"), "lab_orders", ["patient_id"], unique=False)

    op.create_table(
        "inventory_items",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("unit", sa.String(), nullable=True),
        sa.Column("current_stock", sa.Float(), nullable=True),
        sa.Column("low_stock_threshold", sa.Float(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_inventory_items_deleted_at"), "inventory_items", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_inventory_items_id"), "inventory_items", ["id"], unique=False)
    op.create_index(op.f("ix_inventory_items_name"), "inventory_items", ["name"], unique=False)

    op.create_table(
        "finance_audit_log",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("action", sa.String(), nullable=False),
        sa.Column("details", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_finance_audit_log_deleted_at"), "finance_audit_log", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_finance_audit_log_id"), "finance_audit_log", ["id"], unique=False)

    op.create_table(
        "transactions",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("shift_id", sa.Integer(), nullable=True),
        sa.Column("patient_id", sa.Integer(), nullable=True),
        sa.Column("amount", sa.Integer(), nullable=False),
        sa.Column("quantity", sa.Integer(), server_default="1", nullable=False),
        sa.Column("doctor_id", sa.String(), nullable=True),
        sa.Column("payment_method", sa.String(), nullable=True),
        sa.Column("cash_amount", sa.Integer(), nullable=True),
        sa.Column("card_amount", sa.Integer(), nullable=True),
        sa.Column("transfer_amount", sa.Integer(), nullable=True),
        sa.Column("description", sa.String(), nullable=True),
        sa.Column("idempotency_key", sa.String(), nullable=True),
        sa.Column("related_transaction_id", sa.Integer(), nullable=True),
        sa.Column("created_by_user_id", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.CheckConstraint("amount <> 0", name="ck_transactions_amount_nonzero"),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"]),
        sa.ForeignKeyConstraint(["related_transaction_id"], ["transactions.id"]),
        sa.ForeignKeyConstraint(["shift_id"], ["shifts.id"]),
        sa.ForeignKeyConstraint(["created_by_user_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("shift_id", "idempotency_key", name="uq_shift_idempotency_key"),
    )
    op.create_index(op.f("ix_transactions_deleted_at"), "transactions", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_transactions_id"), "transactions", ["id"], unique=False)
    op.create_index(op.f("ix_transactions_idempotency_key"), "transactions", ["idempotency_key"], unique=False)
    op.create_index(op.f("ix_transactions_created_by_user_id"), "transactions", ["created_by_user_id"], unique=False)

    op.create_table(
        "expenses",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("shift_id", sa.Integer(), nullable=False),
        sa.Column("amount", sa.Integer(), nullable=False),
        sa.Column("category", sa.String(), nullable=False),
        sa.Column("comment", sa.String(), nullable=True),
        sa.Column("created_by", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["shift_id"], ["shifts.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_expenses_deleted_at"), "expenses", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_expenses_id"), "expenses", ["id"], unique=False)
    op.create_index(op.f("ix_expenses_shift_id"), "expenses", ["shift_id"], unique=False)

    op.create_table(
        "patient_files",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("visit_id", sa.Integer(), nullable=True),
        sa.Column("file_type", sa.String(), nullable=False),
        sa.Column("original_filename", sa.String(), nullable=False),
        sa.Column("stored_filename", sa.String(), nullable=False),
        sa.Column("mime", sa.String(), nullable=True),
        sa.Column("size", sa.Integer(), nullable=False),
        sa.Column("sha256", sa.String(length=64), nullable=False),
        sa.Column("created_by_user_id", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["created_by_user_id"], ["users.id"]),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("stored_filename"),
    )
    op.create_index(op.f("ix_patient_files_deleted_at"), "patient_files", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_patient_files_id"), "patient_files", ["id"], unique=False)
    op.create_index(op.f("ix_patient_files_patient_id"), "patient_files", ["patient_id"], unique=False)
    op.create_index(op.f("ix_patient_files_visit_id"), "patient_files", ["visit_id"], unique=False)

    op.create_table(
        "stock_movements",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("item_id", sa.Integer(), nullable=False),
        sa.Column("change_amount", sa.Float(), nullable=False),
        sa.Column("reason", stockmovementreason, nullable=False),
        sa.Column("order_id", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["item_id"], ["inventory_items.id"]),
        sa.ForeignKeyConstraint(["order_id"], ["lab_orders.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_stock_movements_deleted_at"), "stock_movements", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_stock_movements_id"), "stock_movements", ["id"], unique=False)
    op.create_index(op.f("ix_stock_movements_item_id"), "stock_movements", ["item_id"], unique=False)

    op.create_table(
        "lab_test_consumables",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("lab_test_id", sa.Integer(), nullable=False),
        sa.Column("inventory_item_id", sa.Integer(), nullable=False),
        sa.Column("quantity_per_test", sa.Float(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["inventory_item_id"], ["inventory_items.id"]),
        sa.ForeignKeyConstraint(["lab_test_id"], ["lab_tests.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_lab_test_consumables_deleted_at"), "lab_test_consumables", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_lab_test_consumables_id"), "lab_test_consumables", ["id"], unique=False)
    op.create_index(op.f("ix_lab_test_consumables_lab_test_id"), "lab_test_consumables", ["lab_test_id"], unique=False)

    op.create_table(
        "lab_results",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("order_id", sa.Integer(), nullable=False),
        sa.Column("test_id", sa.Integer(), nullable=False),
        sa.Column("value", sa.Text(), nullable=False),
        sa.Column("is_abnormal", sa.Boolean(), nullable=True),
        sa.Column("comment", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("performed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["order_id"], ["lab_orders.id"]),
        sa.ForeignKeyConstraint(["test_id"], ["lab_tests.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_lab_results_deleted_at"), "lab_results", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_lab_results_id"), "lab_results", ["id"], unique=False)
    op.create_index(op.f("ix_lab_results_order_id"), "lab_results", ["order_id"], unique=False)

    op.create_table(
        "system_audit_log",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=False),
        sa.Column("action", sa.String(), nullable=False),
        sa.Column("setting_key", sa.String(), nullable=False),
        sa.Column("old_value", sa.JSON(), nullable=True),
        sa.Column("new_value", sa.JSON(), nullable=True),
        sa.Column("details", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_system_audit_log_created_at", "system_audit_log", ["created_at"], unique=False)
    op.create_index(op.f("ix_system_audit_log_deleted_at"), "system_audit_log", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_system_audit_log_id"), "system_audit_log", ["id"], unique=False)
    op.create_index(op.f("ix_system_audit_log_user_id"), "system_audit_log", ["user_id"], unique=False)

    op.create_table(
        "system_settings",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=False),
        sa.Column("key", sa.String(), nullable=False),
        sa.Column("value", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("user_id", "key", name="uq_user_setting_key"),
    )
    op.create_index(op.f("ix_system_settings_deleted_at"), "system_settings", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_system_settings_id"), "system_settings", ["id"], unique=False)
    op.create_index(op.f("ix_system_settings_key"), "system_settings", ["key"], unique=False)
    op.create_index(op.f("ix_system_settings_user_id"), "system_settings", ["user_id"], unique=False)
    op.create_index("ix_system_settings_user_id_key", "system_settings", ["user_id", "key"], unique=False)

    op.create_table(
        "telegram_link_tokens",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("code", sa.String(length=64), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("used", sa.Boolean(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_telegram_link_tokens_code"), "telegram_link_tokens", ["code"], unique=True)
    op.create_index(op.f("ix_telegram_link_tokens_deleted_at"), "telegram_link_tokens", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_telegram_link_tokens_id"), "telegram_link_tokens", ["id"], unique=False)
    op.create_index(op.f("ix_telegram_link_tokens_patient_id"), "telegram_link_tokens", ["patient_id"], unique=False)

    op.create_table(
        "queue_items",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("ticket_number", sa.String(length=10), nullable=False),
        sa.Column("manual_queue_number", sa.String(length=20), nullable=True),
        sa.Column("queue_date", sa.Date(), server_default=sa.text("CURRENT_DATE"), nullable=False),
        sa.Column("sequence", sa.Integer(), server_default="1", nullable=False),
        sa.Column("sort_order", sa.Integer(), nullable=True),
        sa.Column("patient_name", sa.String(), nullable=False),
        sa.Column("custom_name", sa.String(), nullable=True),
        sa.Column("patient_phone_snapshot", sa.String(length=32), nullable=True),
        sa.Column("quantity", sa.Integer(), server_default="1", nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=True),
        sa.Column("doctor_id", sa.Integer(), nullable=True),
        sa.Column("transaction_id", sa.Integer(), nullable=True),
        sa.Column("status", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("estimated_start_time", sa.DateTime(timezone=True), nullable=True),
        sa.Column("entered_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["doctor_id"], ["doctors.id"]),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"]),
        sa.ForeignKeyConstraint(["transaction_id"], ["transactions.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("doctor_id", "queue_date", "sequence", name="uq_queue_doctor_date_seq"),
    )
    op.create_index(op.f("ix_queue_items_deleted_at"), "queue_items", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_queue_items_id"), "queue_items", ["id"], unique=False)

    op.create_table(
        "file_delivery_log",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("file_id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("channel", sa.String(), nullable=False),
        sa.Column("status", sa.String(), nullable=False),
        sa.Column("sent_by_user_id", sa.Integer(), nullable=True),
        sa.Column("sent_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.Column("error", sa.String(), nullable=True),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["file_id"], ["patient_files.id"]),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"]),
        sa.ForeignKeyConstraint(["sent_by_user_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_file_delivery_log_deleted_at"), "file_delivery_log", ["deleted_at"], unique=False)
    op.create_index(op.f("ix_file_delivery_log_file_id"), "file_delivery_log", ["file_id"], unique=False)
    op.create_index(op.f("ix_file_delivery_log_id"), "file_delivery_log", ["id"], unique=False)
    op.create_index(op.f("ix_file_delivery_log_patient_id"), "file_delivery_log", ["patient_id"], unique=False)

    op.create_table(
        "action_logs",
        sa.Column("id", sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=True),
        sa.Column("action", sa.String(length=32), nullable=False),
        sa.Column("module", sa.String(length=32), nullable=False),
        sa.Column("entity_id", sa.String(length=64), nullable=True),
        sa.Column("details", sa.JSON(), nullable=True),
        sa.Column("ip_address", sa.String(length=45), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=True),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_action_logs_id"), "action_logs", ["id"], unique=False)
    op.create_index(op.f("ix_action_logs_action"), "action_logs", ["action"], unique=False)
    op.create_index(op.f("ix_action_logs_module"), "action_logs", ["module"], unique=False)
    op.create_index(op.f("ix_action_logs_user_id"), "action_logs", ["user_id"], unique=False)
    op.create_index(op.f("ix_action_logs_created_at"), "action_logs", ["created_at"], unique=False)

    # Default patient for queue items without data
    op.execute("""
        INSERT INTO patients (id, full_name, phone, category, balance, is_blacklisted)
        SELECT 1, 'Бемор', '+998000000000', 'standard', 0, false
        WHERE NOT EXISTS (SELECT 1 FROM patients WHERE id = 1)
    """)
    op.execute("""
        SELECT setval(
            pg_get_serial_sequence('patients', 'id'),
            (SELECT COALESCE(MAX(id), 1) FROM patients)
        )
    """)


def downgrade() -> None:
    op.execute("DELETE FROM patients WHERE id = 1")

    op.drop_index(op.f("ix_action_logs_created_at"), table_name="action_logs")
    op.drop_index(op.f("ix_action_logs_user_id"), table_name="action_logs")
    op.drop_index(op.f("ix_action_logs_module"), table_name="action_logs")
    op.drop_index(op.f("ix_action_logs_action"), table_name="action_logs")
    op.drop_index(op.f("ix_action_logs_id"), table_name="action_logs")
    op.drop_table("action_logs")

    op.drop_index(op.f("ix_file_delivery_log_patient_id"), table_name="file_delivery_log")
    op.drop_index(op.f("ix_file_delivery_log_id"), table_name="file_delivery_log")
    op.drop_index(op.f("ix_file_delivery_log_file_id"), table_name="file_delivery_log")
    op.drop_index(op.f("ix_file_delivery_log_deleted_at"), table_name="file_delivery_log")
    op.drop_table("file_delivery_log")

    op.drop_index(op.f("ix_queue_items_id"), table_name="queue_items")
    op.drop_index(op.f("ix_queue_items_deleted_at"), table_name="queue_items")
    op.drop_table("queue_items")

    op.drop_index(op.f("ix_telegram_link_tokens_patient_id"), table_name="telegram_link_tokens")
    op.drop_index(op.f("ix_telegram_link_tokens_id"), table_name="telegram_link_tokens")
    op.drop_index(op.f("ix_telegram_link_tokens_deleted_at"), table_name="telegram_link_tokens")
    op.drop_index(op.f("ix_telegram_link_tokens_code"), table_name="telegram_link_tokens")
    op.drop_table("telegram_link_tokens")

    op.drop_index("ix_system_settings_user_id_key", table_name="system_settings")
    op.drop_index(op.f("ix_system_settings_user_id"), table_name="system_settings")
    op.drop_index(op.f("ix_system_settings_key"), table_name="system_settings")
    op.drop_index(op.f("ix_system_settings_id"), table_name="system_settings")
    op.drop_index(op.f("ix_system_settings_deleted_at"), table_name="system_settings")
    op.drop_table("system_settings")

    op.drop_index(op.f("ix_system_audit_log_user_id"), table_name="system_audit_log")
    op.drop_index(op.f("ix_system_audit_log_id"), table_name="system_audit_log")
    op.drop_index(op.f("ix_system_audit_log_deleted_at"), table_name="system_audit_log")
    op.drop_index("ix_system_audit_log_created_at", table_name="system_audit_log")
    op.drop_table("system_audit_log")

    op.drop_index(op.f("ix_lab_results_order_id"), table_name="lab_results")
    op.drop_index(op.f("ix_lab_results_id"), table_name="lab_results")
    op.drop_index(op.f("ix_lab_results_deleted_at"), table_name="lab_results")
    op.drop_table("lab_results")

    op.drop_index(op.f("ix_lab_test_consumables_lab_test_id"), table_name="lab_test_consumables")
    op.drop_index(op.f("ix_lab_test_consumables_id"), table_name="lab_test_consumables")
    op.drop_index(op.f("ix_lab_test_consumables_deleted_at"), table_name="lab_test_consumables")
    op.drop_table("lab_test_consumables")

    op.drop_index(op.f("ix_stock_movements_item_id"), table_name="stock_movements")
    op.drop_index(op.f("ix_stock_movements_id"), table_name="stock_movements")
    op.drop_index(op.f("ix_stock_movements_deleted_at"), table_name="stock_movements")
    op.drop_table("stock_movements")

    op.drop_index(op.f("ix_patient_files_visit_id"), table_name="patient_files")
    op.drop_index(op.f("ix_patient_files_patient_id"), table_name="patient_files")
    op.drop_index(op.f("ix_patient_files_id"), table_name="patient_files")
    op.drop_index(op.f("ix_patient_files_deleted_at"), table_name="patient_files")
    op.drop_table("patient_files")

    op.drop_index(op.f("ix_expenses_shift_id"), table_name="expenses")
    op.drop_index(op.f("ix_expenses_id"), table_name="expenses")
    op.drop_index(op.f("ix_expenses_deleted_at"), table_name="expenses")
    op.drop_table("expenses")

    op.drop_index(op.f("ix_transactions_created_by_user_id"), table_name="transactions")
    op.drop_index(op.f("ix_transactions_idempotency_key"), table_name="transactions")
    op.drop_index(op.f("ix_transactions_id"), table_name="transactions")
    op.drop_index(op.f("ix_transactions_deleted_at"), table_name="transactions")
    op.drop_table("transactions")

    op.drop_index(op.f("ix_finance_audit_log_id"), table_name="finance_audit_log")
    op.drop_index(op.f("ix_finance_audit_log_deleted_at"), table_name="finance_audit_log")
    op.drop_table("finance_audit_log")

    op.drop_index(op.f("ix_visit_attachments_visit_id"), table_name="visit_attachments")
    op.drop_index(op.f("ix_visit_attachments_id"), table_name="visit_attachments")
    op.drop_index(op.f("ix_visit_attachments_deleted_at"), table_name="visit_attachments")
    op.drop_table("visit_attachments")

    op.drop_index(op.f("ix_prescribed_services_visit_id"), table_name="prescribed_services")
    op.drop_index(op.f("ix_prescribed_services_id"), table_name="prescribed_services")
    op.drop_index(op.f("ix_prescribed_services_deleted_at"), table_name="prescribed_services")
    op.drop_table("prescribed_services")

    op.drop_index(op.f("ix_visits_visit_date"), table_name="visits")
    op.drop_index(op.f("ix_visits_patient_id"), table_name="visits")
    op.drop_index(op.f("ix_visits_id"), table_name="visits")
    op.drop_index(op.f("ix_visits_doctor_id"), table_name="visits")
    op.drop_index(op.f("ix_visits_deleted_at"), table_name="visits")
    op.drop_table("visits")

    op.drop_index(op.f("ix_lab_orders_patient_id"), table_name="lab_orders")
    op.drop_index(op.f("ix_lab_orders_id"), table_name="lab_orders")
    op.drop_index(op.f("ix_lab_orders_deleted_at"), table_name="lab_orders")
    op.drop_table("lab_orders")

    op.drop_index(op.f("ix_inventory_items_name"), table_name="inventory_items")
    op.drop_index(op.f("ix_inventory_items_id"), table_name="inventory_items")
    op.drop_index(op.f("ix_inventory_items_deleted_at"), table_name="inventory_items")
    op.drop_table("inventory_items")

    op.drop_index(op.f("ix_doctor_services_deleted_at"), table_name="doctor_services")
    op.drop_index(op.f("ix_doctor_services_id"), table_name="doctor_services")
    op.drop_table("doctor_services")

    op.drop_index(op.f("ix_appointments_id"), table_name="appointments")
    op.drop_index(op.f("ix_appointments_deleted_at"), table_name="appointments")
    op.drop_table("appointments")

    op.drop_index(op.f("ix_users_telegram_chat_id"), table_name="users")
    op.drop_index(op.f("ix_users_username"), table_name="users")
    op.drop_index(op.f("ix_users_id"), table_name="users")
    op.drop_index(op.f("ix_users_deleted_at"), table_name="users")
    op.drop_table("users")

    op.drop_index(op.f("ix_shifts_id"), table_name="shifts")
    op.drop_index(op.f("ix_shifts_deleted_at"), table_name="shifts")
    op.drop_table("shifts")

    op.drop_index(op.f("ix_patients_phone"), table_name="patients")
    op.drop_index(op.f("ix_patients_id"), table_name="patients")
    op.drop_index(op.f("ix_patients_full_name"), table_name="patients")
    op.drop_index(op.f("ix_patients_deleted_at"), table_name="patients")
    op.drop_table("patients")

    op.drop_index(op.f("ix_doctors_id"), table_name="doctors")
    op.drop_index(op.f("ix_doctors_full_name"), table_name="doctors")
    op.drop_index(op.f("ix_doctors_deleted_at"), table_name="doctors")
    op.drop_table("doctors")

    op.drop_index(op.f("ix_audit_logs_id"), table_name="audit_logs")
    op.drop_table("audit_logs")

    op.drop_index(op.f("ix_lab_tests_name"), table_name="lab_tests")
    op.drop_index(op.f("ix_lab_tests_id"), table_name="lab_tests")
    op.drop_index(op.f("ix_lab_tests_deleted_at"), table_name="lab_tests")
    op.drop_table("lab_tests")

    op.drop_index(op.f("ix_lab_categories_name"), table_name="lab_categories")
    op.drop_index(op.f("ix_lab_categories_id"), table_name="lab_categories")
    op.drop_table("lab_categories")

    stockmovementreason.drop(op.get_bind(), checkfirst=True)
    laborderstatus.drop(op.get_bind(), checkfirst=True)
    userrole.drop(op.get_bind(), checkfirst=True)
