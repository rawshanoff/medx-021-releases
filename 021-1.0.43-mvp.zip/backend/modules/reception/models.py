import enum

from backend.core.database import Base, SoftDeleteMixin
from sqlalchemy import (
    Column,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func


class QueueStatus(str, enum.Enum):
    WAITING = "WAITING"
    COMPLETED = "COMPLETED"
    IN_PROGRESS = "IN_PROGRESS"
    FINISHED = "FINISHED"
    CANCELLED = "CANCELLED"
    REFUNDED = "REFUNDED"


class QueueItem(SoftDeleteMixin, Base):
    __tablename__ = "queue_items"
    __table_args__ = (
        UniqueConstraint(
            "doctor_id", "queue_date", "sequence", name="uq_queue_doctor_date_seq"
        ),
    )

    id = Column(Integer, primary_key=True, index=True)
    ticket_number = Column(String(10), nullable=False)  # e.g., "A-001", "B-042"
    manual_queue_number = Column(String(20), nullable=True)
    queue_date = Column(Date, nullable=False, server_default=func.current_date())
    sequence = Column(Integer, nullable=False, server_default="1")
    sort_order = Column(Integer, nullable=True)
    patient_name = Column(
        String, nullable=False
    )  # Snapshot name in case patient deleted? Or just link.
    custom_name = Column(String, nullable=True)
    patient_phone_snapshot = Column(String(32), nullable=True)  # Per-row phone, doesn't affect Patient
    quantity = Column(Integer, nullable=False, server_default="1")
    # We can link specifically to a patient or keep it simple. Linking is better.
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=True)
    doctor_id = Column(Integer, ForeignKey("doctors.id"), nullable=True)
    transaction_id = Column(Integer, ForeignKey("transactions.id"), nullable=True)

    status = Column(String, default=QueueStatus.WAITING)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    estimated_start_time = Column(DateTime(timezone=True), nullable=True)
    entered_at = Column(DateTime(timezone=True), nullable=True)  # время входа (приём)
    finished_at = Column(DateTime(timezone=True), nullable=True)  # время выхода (завершение)

    # Relationships
    patient = relationship("Patient")
    doctor = relationship("Doctor")
    transaction = relationship("Transaction")
