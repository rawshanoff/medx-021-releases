# ruff: noqa: E402

import logging
import os
import sys
from contextlib import asynccontextmanager
from logging.handlers import RotatingFileHandler
from pathlib import Path
from starlette.staticfiles import StaticFiles
from starlette.exceptions import HTTPException
from starlette.responses import FileResponse

# Ensure `backend` package is importable even when running from `backend/` folder:
#   cd backend && python -m uvicorn main:app ...
_repo_root = Path(__file__).resolve().parents[1]
if str(_repo_root) not in sys.path:
    sys.path.insert(0, str(_repo_root))


# IMPORTANT:
# Always import via the `backend.*` package to avoid loading the same models twice
# (e.g., `backend.modules.users.models` and `modules.users.models`) which breaks
# SQLAlchemy metadata with "Table 'users' is already defined".
from datetime import datetime, timezone

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded

from backend.core.config import settings
from backend.core.backup import backup_scheduler
from backend.core.database import init_db, SessionLocal
import asyncio
from backend.core.exceptions import AppException
from backend.core.rate_limit import limiter
from backend.core.update_artifacts import cleanup_update_artifacts
from backend.core.telegram_bot import init_bot
import backend.core.telegram_bot as telegram_bot_module
from backend.modules.appointments.router import router as appointments_router
from backend.modules.auth import router as auth_router
from backend.modules.auth.telegram import router as telegram_auth_router
from backend.modules.doctors.router import router as doctors_router
from backend.modules.files.router import router as files_router
from backend.modules.finance.router import router as finance_router
from backend.modules.lab.router import router as lab_router
from backend.modules.inventory.router import router as inventory_router
from backend.modules.licenses.router import router as licenses_router
from backend.modules.patients.router import router as patients_router
from backend.modules.reception.router import router as reception_router
from backend.modules.system.router import router as system_router
from backend.modules.users.router import router as users_router
from backend.modules.analytics.router import router as analytics_router
from backend.modules.users.models import User, UserRole
from sqlalchemy import select
import bcrypt


def _configure_logging() -> None:
    level_name = str(getattr(settings, "LOG_LEVEL", "INFO") or "INFO").upper()
    level = getattr(logging, level_name, logging.INFO)

    handlers: list[logging.Handler] = [logging.StreamHandler()]

    log_file = getattr(settings, "LOG_FILE", None)
    if log_file:
        path = Path(log_file)
        path.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(
            RotatingFileHandler(
                filename=str(path),
                maxBytes=int(getattr(settings, "LOG_MAX_BYTES", 5_000_000)),
                backupCount=int(getattr(settings, "LOG_BACKUP_COUNT", 3)),
                encoding="utf-8",
            )
        )

    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=handlers,
    )


_configure_logging()


@asynccontextmanager
async def lifespan(_app: FastAPI):
    await init_db()
    # Desktop: cleanup update leftovers after a restart.
    # This is safe for server too (no-op unless files exist).
    try:
        cleanup_update_artifacts()
    except Exception:
        logger.exception("Failed to cleanup update artifacts")
    
    # Initialize Telegram bot
    bot_task = None
    try:
        await init_bot()
        
        # Enable aiogram debug logging
        aiogram_logger = logging.getLogger("aiogram")
        aiogram_logger.setLevel(logging.INFO)
        
        # Access bot and dp from module (they're updated in init_bot)
        # MEDX_DISABLE_BOT=1 — отключить polling в main (если бот запущен отдельно)
        if (
            not os.getenv("MEDX_DISABLE_BOT")
            and settings.PATIENT_BOT_TOKEN
            and telegram_bot_module.bot
            and telegram_bot_module.dp
        ):
            logger.info(f"🚀 Starting Telegram Bot polling with token: {settings.PATIENT_BOT_TOKEN[:5]}***")
            bot_task = asyncio.create_task(telegram_bot_module.dp.start_polling(telegram_bot_module.bot))
            logger.info("✅ Telegram Bot polling task created")
        else:
            logger.warning("⚠️  Bot token missing or bot not initialized, skipping Telegram Bot polling")
    except Exception as e:
        logger.exception("❌ Failed to initialize Telegram bot")
    
    # Auto-seed default admin user if users table is empty
    try:
        async with SessionLocal() as session:
            result = await session.execute(select(User))
            if not result.scalars().first():
                logger.warning("⚠️  Users table is empty. Creating default user...")
                default_pwd = os.getenv("ADMIN_INITIAL_PASSWORD", "ChangeMe_123!")
                pwd_hash = bcrypt.hashpw(
                    default_pwd.encode(), bcrypt.gensalt(rounds=12)
                ).decode()
                default_user = User(
                    username="admin",
                    password_hash=pwd_hash,
                    full_name="System Administrator",
                    role=UserRole.OWNER,
                    is_active=True,
                )
                session.add(default_user)
                await session.commit()
                logger.warning(
                    "Created default admin. PLEASE CHANGE PASSWORD IMMEDIATELY."
                )
    except Exception:
        logger.exception("Failed to auto-seed default user")
    
    stop_event = asyncio.Event()
    backup_task = asyncio.create_task(backup_scheduler(stop_event))
    try:
        yield
    finally:
        stop_event.set()
        backup_task.cancel()
        
        # Cancel bot polling task
        if bot_task:
            bot_task.cancel()
            try:
                await bot_task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
        
        # Close bot session
        if telegram_bot_module.bot:
            try:
                await telegram_bot_module.bot.session.close()
            except Exception:
                pass
        
        # Cancel backup task
        try:
            await backup_task
        except Exception:
            pass


app = FastAPI(title="021 API", version="1.0.0", lifespan=lifespan)
logger = logging.getLogger("medx")

# Rate Limiting
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# CORS Configuration
# Разрешаем только указанные origins из настроек
cors_origins = [
    origin.strip() for origin in settings.CORS_ORIGINS.split(",") if origin.strip()
]
# Если origins не указаны, используем безопасные дефолты для разработки
if not cors_origins:
    cors_origins = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:3005",
        "http://127.0.0.1:3005",
    ]

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=["*"],
)


@app.exception_handler(AppException)
async def app_exception_handler(_request: Request, exc: AppException):
    content: dict = {"detail": exc.detail}
    if exc.code:
        content["code"] = exc.code
    return JSONResponse(status_code=exc.status_code, content=content)


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    # Keep FastAPI default shape
    return JSONResponse(status_code=422, content={"detail": exc.errors()})


@app.exception_handler(Exception)
async def unhandled_exception_handler(_request: Request, exc: Exception):
    # Log full stack trace server-side, but avoid leaking internals to client.
    logger.exception("Unhandled exception", exc_info=exc)
    return JSONResponse(status_code=500, content={"detail": "Internal Server Error"})


app.include_router(auth_router, prefix="/api")
app.include_router(telegram_auth_router, prefix="/api")
app.include_router(users_router, prefix="/api")
app.include_router(patients_router, prefix="/api/patients", tags=["Patients"])
app.include_router(finance_router, prefix="/api/finance", tags=["Finance"])
app.include_router(doctors_router, prefix="/api/doctors", tags=["Doctors"])
app.include_router(
    appointments_router, prefix="/api/appointments", tags=["Appointments"]
)
app.include_router(system_router, prefix="/api/system", tags=["System"])
app.include_router(reception_router, prefix="/api/reception", tags=["Reception"])
app.include_router(lab_router, prefix="/api/lab", tags=["Laboratory"])
app.include_router(inventory_router, prefix="/api/inventory", tags=["Inventory"])
app.include_router(analytics_router, prefix="/api/analytics", tags=["Analytics"])
app.include_router(files_router, prefix="/api")
app.include_router(licenses_router, prefix="/api")

# Mount static files for uploads
uploads_path = Path("uploads")
uploads_path.mkdir(exist_ok=True)
app.mount("/api/uploads", StaticFiles(directory="uploads"), name="uploads")

# Health check (must be before frontend mount to take precedence)
@app.get("/health")
async def health():
    return {
        "status": "running",
        "version": settings.CURRENT_VERSION,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }

# Serve frontend SPA (for Cloudflare Tunnel / production)
# Mount("/") в Starlette перехватывает запросы раньше явных маршрутов — поэтому
# раздаём assets отдельно, а SPA — через catch-all.
_frontend_dist = _repo_root / "frontend" / "dist"
_index_html = _frontend_dist / "index.html"
_assets_dir = _frontend_dist / "assets"

if _frontend_dist.exists():
    logger.info("Frontend dist found at %s, registering SPA routes", _frontend_dist)
    # 1. Assets — JS, CSS (иначе index.html не загрузит скрипты)
    if _assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(_assets_dir)), name="assets")

    # 2. SPA fallback — всё остальное (кроме /api) — index.html
    @app.get("/")
    async def serve_root():
        if _index_html.exists():
            return FileResponse(str(_index_html))
        raise HTTPException(status_code=404)

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        if full_path.startswith("api/") or full_path.startswith("assets/"):
            raise HTTPException(status_code=404)
        if _index_html.exists():
            return FileResponse(str(_index_html))
        raise HTTPException(status_code=404)
else:
    logger.warning("Frontend dist NOT found at %s, SPA routes not registered", _frontend_dist)
