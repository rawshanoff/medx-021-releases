from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict


class VersionResponse(BaseModel):
    version: str
    status: str


class UpdateCheckResponse(BaseModel):
    update_available: bool
    latest_version: str
    current_version: str
    release_notes: str
    download_url: str | None = None


class DoctorInfo(BaseModel):
    id: str
    name: str
    specialty: str


# System Settings Schemas


class SystemSettingCreate(BaseModel):
    value: Any  # Can be any JSON-serializable value


class SystemSettingUpdate(BaseModel):
    value: Any


class SettingsRestoreBody(BaseModel):
    """Body for POST /api/system/settings/restore. Accepts exportedAt, version for metadata."""

    settings: dict[str, Any]
    exportedAt: Optional[str] = None
    version: Optional[str] = None


class SystemSettingRead(BaseModel):
    id: int
    user_id: int
    key: str
    value: Any
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class PrintSettingsValue(BaseModel):
    """Detailed schema for print_config setting value."""

    clinicName: str = "021"
    clinicPhone: str = ""
    clinicAddress: str = ""
    footerNote: str = ""
    underQrText: str = ""
    logoDataUrl: str = ""
    autoPrint: bool = False
    preferredPrinterName: str = ""
    preferredPrinterDeviceName: str = ""
    boldAllText: bool = True
    showTotalAmount: bool = True
    showPaymentType: bool = True
    showLogo: bool = True
    showClinicName: bool = True
    showClinicPhone: bool = True
    showClinicAddress: bool = True
    showDate: bool = True
    showTime: bool = True
    showDateTime: bool = True
    showQueue: bool = True
    showPatientName: bool = True
    showDoctor: bool = True
    showDoctorRoom: bool = True
    showServices: bool = True
    showQr: bool = True
    showUnderQrText: bool = True
    showFooterNote: bool = True
    silentPrintMode: str = "html"
    silentScalePercent: int = 100
    logoMaxMm: int = 20
    logoWidthMm: int = 40
    fontScalePercent: int = 100
    receiptFontFamily: str = "mono"
    receiptTopPaddingMm: int = 0
    receiptWidthMode: str = "standard"
    receiptTemplateId: str = "check-6"
    paperSize: str = "80"
    qrUrl: str = ""
    qrImageDataUrl: str = ""
    queueNumberSize: int = 32
    queueNumberBold: bool = True
    queueLabelSize: int = 11
    queueLabelBold: bool = True
    qrSize: int = 140
    qrBold: bool = False
    clinicNameFontSize: int = 14
    clinicNameBold: bool = True
    clinicAddressFontSize: int = 10
    clinicAddressBold: bool = False
    clinicPhoneFontSize: int = 10
    clinicPhoneBold: bool = False
    dateFontSize: int = 11
    dateBold: bool = False
    timeFontSize: int = 11
    timeBold: bool = False
    patientFontSize: int = 11
    patientBold: bool = True
    doctorFontSize: int = 12
    doctorBold: bool = True
    doctorRoomFontSize: int = 11
    doctorRoomBold: bool = False
    servicesFontSize: int = 11
    servicesBold: bool = False
    totalFontSize: int = 14
    totalBold: bool = True
    paymentFontSize: int = 10
    paymentBold: bool = False
    underQrFontSize: int = 10
    underQrBold: bool = False
    footerFontSize: int = 10
    footerBold: bool = False


class SystemAuditUserRead(BaseModel):
    """Minimal user info for audit timeline."""

    id: int
    username: str
    full_name: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class SystemAuditLogRead(BaseModel):
    """Schema for audit log entries."""

    id: int
    user_id: int
    user: Optional[SystemAuditUserRead] = None
    action: str  # "create", "update", "delete", "rollback"
    setting_key: str
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    details: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)


class ActionLogRead(BaseModel):
    """Schema for enterprise action audit log."""

    id: int
    user_id: Optional[int] = None
    user: Optional[SystemAuditUserRead] = None
    action: str
    module: str
    entity_id: Optional[str] = None
    details: Optional[Any] = None
    ip_address: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = ConfigDict(from_attributes=True)
