from datetime import datetime, date
from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field


class PrescribedServiceCreate(BaseModel):
    service_id: int
    quantity: int = Field(default=1, ge=1)


class PrescribedServiceRead(BaseModel):
    id: int
    visit_id: int
    service_id: int
    quantity: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class VisitAttachmentRead(BaseModel):
    id: int
    file_path: str
    filename: str
    file_type: Optional[str]
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class DoctorNameOnly(BaseModel):
    id: int
    full_name: str

    model_config = ConfigDict(from_attributes=True)


class VisitCreate(BaseModel):
    patient_id: int
    doctor_id: int
    visit_date: date
    complaints: Optional[str] = None
    diagnosis: Optional[str] = None
    recommendations: Optional[str] = None
    prescribed_services: List[PrescribedServiceCreate] = []


class VisitRead(BaseModel):
    id: int
    patient_id: int
    doctor_id: int
    visit_date: date
    complaints: Optional[str]
    diagnosis: Optional[str]
    recommendations: Optional[str]
    rating: Optional[int] = None
    feedback_comment: Optional[str] = None
    created_at: datetime
    doctor: Optional[DoctorNameOnly] = None
    prescribed_services: List[PrescribedServiceRead] = []
    attachments: List[VisitAttachmentRead] = []

    model_config = ConfigDict(from_attributes=True)


class CompleteVisitRequest(BaseModel):
    queue_id: int
    complaints: Optional[str] = None
    diagnosis: Optional[str] = None
    recommendations: Optional[str] = None
    service_ids: List[int] = []
