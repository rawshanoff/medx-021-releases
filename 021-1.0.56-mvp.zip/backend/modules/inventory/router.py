import logging
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from sqlalchemy.orm import joinedload

from backend.core.database import get_db
from backend.modules.inventory import schemas
from backend.modules.inventory.models import InventoryItem, StockMovement, LabTestConsumable
from backend.modules.inventory.services import add_stock, StockMovementReason
from backend.modules.auth import require_roles
from backend.modules.users.models import UserRole

logger = logging.getLogger("medx.inventory")

router = APIRouter(tags=["inventory"])


@router.get("/", response_model=list[schemas.InventoryItemRead])
async def list_inventory(
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """List all inventory items with current stock levels"""
    result = await db.execute(
        select(InventoryItem).where(InventoryItem.deleted_at.is_(None))
    )
    return result.scalars().all()


@router.post("/items", response_model=schemas.InventoryItemRead)
async def create_inventory_item(
    item: schemas.InventoryItemCreate,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Create a new inventory item"""
    db_item = InventoryItem(**item.dict())
    db.add(db_item)
    await db.commit()
    await db.refresh(db_item)
    logger.info(f"[INVENTORY] Created item: {db_item.name}")
    return db_item


@router.get("/items/{item_id}", response_model=schemas.InventoryItemRead)
async def get_inventory_item(
    item_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Get a specific inventory item"""
    item = await db.get(InventoryItem, item_id)
    if not item or item.deleted_at:
        raise HTTPException(status_code=404, detail="Item not found")
    return item


@router.post("/items/{item_id}/restock", response_model=schemas.InventoryItemRead)
async def restock_item(
    item_id: int,
    request: schemas.RestockRequest,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Add stock to an inventory item (Purchase)"""
    item = await db.get(InventoryItem, item_id)
    if not item or item.deleted_at:
        raise HTTPException(status_code=404, detail="Item not found")

    await add_stock(db, item_id, request.amount, StockMovementReason.PURCHASE)
    await db.commit()
    await db.refresh(item)
    logger.info(f"[INVENTORY] Restocked {item.name} with {request.amount} {item.unit}")
    return item


@router.get("/movements", response_model=list[schemas.StockMovementRead])
async def get_stock_movements(
    limit: int = 100,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Get all stock movements history (last N records)"""
    result = await db.execute(
        select(StockMovement).options(
            joinedload(StockMovement.item)
        ).where(
            StockMovement.deleted_at.is_(None)
        ).order_by(desc(StockMovement.created_at)).limit(limit)
    )
    return result.scalars().unique().all()


@router.post("/test-consumables", response_model=schemas.LabTestConsumableRead)
async def link_test_consumable(
    link: schemas.LabTestConsumableCreate,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Define consumables needed for a lab test"""
    db_link = LabTestConsumable(**link.dict())
    db.add(db_link)
    await db.commit()
    await db.refresh(db_link)
    logger.info(f"[INVENTORY] Linked consumable {link.inventory_item_id} to test {link.lab_test_id}")
    return db_link


@router.get("/test-consumables/{test_id}", response_model=list[schemas.LabTestConsumableRead])
async def get_test_consumables(
    test_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Get consumables needed for a lab test"""
    result = await db.execute(
        select(LabTestConsumable).where(
            LabTestConsumable.lab_test_id == test_id,
            LabTestConsumable.deleted_at.is_(None),
        )
    )
    return result.scalars().all()


# Recipe endpoints (aliases for better semantic meaning)
@router.get("/recipes/{lab_test_id}", response_model=list[schemas.LabTestConsumableRead])
async def get_recipe(
    lab_test_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Get recipe (consumables) for a lab test"""
    result = await db.execute(
        select(LabTestConsumable).where(
            LabTestConsumable.lab_test_id == lab_test_id,
            LabTestConsumable.deleted_at.is_(None),
        )
    )
    return result.scalars().all()


@router.post("/recipes", response_model=schemas.LabTestConsumableRead)
async def add_recipe_ingredient(
    ingredient: schemas.LabTestConsumableCreate,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Add a consumable ingredient to a lab test recipe"""
    # Check if already exists
    result = await db.execute(
        select(LabTestConsumable).where(
            LabTestConsumable.lab_test_id == ingredient.lab_test_id,
            LabTestConsumable.inventory_item_id == ingredient.inventory_item_id,
            LabTestConsumable.deleted_at.is_(None),
        )
    )
    if result.scalars().first():
        raise HTTPException(status_code=409, detail="Ingredient already linked to this test")
    
    db_link = LabTestConsumable(**ingredient.dict())
    db.add(db_link)
    await db.commit()
    await db.refresh(db_link)
    logger.info(f"[INVENTORY] Added recipe ingredient {ingredient.inventory_item_id} to test {ingredient.lab_test_id}")
    return db_link


@router.delete("/recipes/{lab_test_id}/{inventory_item_id}")
async def remove_recipe_ingredient(
    lab_test_id: int,
    inventory_item_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Remove a consumable ingredient from a lab test recipe"""
    result = await db.execute(
        select(LabTestConsumable).where(
            LabTestConsumable.lab_test_id == lab_test_id,
            LabTestConsumable.inventory_item_id == inventory_item_id,
            LabTestConsumable.deleted_at.is_(None),
        )
    )
    link = result.scalars().first()
    if not link:
        raise HTTPException(status_code=404, detail="Recipe ingredient not found")
    
    # Soft delete
    link.deleted_at = datetime.now()
    await db.commit()
    logger.info(f"[INVENTORY] Removed recipe ingredient {inventory_item_id} from test {lab_test_id}")
    return {"status": "removed"}
