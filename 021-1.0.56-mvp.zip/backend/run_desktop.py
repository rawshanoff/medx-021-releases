import logging
import os
import sys
import subprocess

import uvicorn

# Import explicitly so PyInstaller includes the package.
from backend.main import app

logger = logging.getLogger("medx")


def main() -> None:
    # --migrate-only: run migration in subprocess, exit. Used to isolate crashes.
    if "--migrate-only" in sys.argv:
        from backend.core.database import run_migration_standalone
        sys.exit(0 if run_migration_standalone() else 1)

    # Desktop packaged: run migration in subprocess first to capture crashes.
    frozen = bool(getattr(sys, "frozen", False))
    if frozen and os.getenv("MEDX_AUTO_MIGRATE", "").strip() == "1":
        exe = sys.executable
        result = subprocess.run(
            [exe, "--migrate-only"],
            capture_output=True,
            text=True,
            timeout=120,
            cwd=os.getenv("MEDX_APP_DIR", os.getcwd()),
            env={**os.environ, "MEDX_AUTO_MIGRATE": "1"},
        )
        if result.returncode != 0:
            err = (result.stderr or "").strip() + "\n" + (result.stdout or "").strip()
            logger.error("Migration subprocess failed (exit %s): %s", result.returncode, err)
            print(f"Migration failed (exit {result.returncode}):\n{err}", file=sys.stderr)
            sys.exit(3)

    host = os.getenv("MEDX_HOST", "127.0.0.1")
    port = int(os.getenv("MEDX_PORT", "8000"))
    uvicorn.run(app, host=host, port=port, reload=False, log_level="info")


if __name__ == "__main__":
    main()
