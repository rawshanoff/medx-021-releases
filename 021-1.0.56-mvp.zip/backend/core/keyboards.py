"""Telegram keyboard templates and utilities."""

from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def get_observer_doctors_keyboard(doctors: list) -> InlineKeyboardMarkup:
    """Doctor selection for observer queue."""
    buttons = [
        [
            InlineKeyboardButton(
                text=d.full_name or f"Врач {d.id}",
                callback_data=f"observer:doctor:{d.id}",
            )
        ]
        for d in doctors
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)


PAGE_SIZE = 10


def get_observer_queue_keyboard(
    items: list, doctor_id: int, page: int = 0
) -> InlineKeyboardMarkup:
    """Queue items: Приём + Опоздал for paid, Вошёл for in_reception, WAITING → Нужно оплатить.
    Pagination: 10 items per page."""
    total = len(items)
    start = page * PAGE_SIZE
    page_items = items[start : start + PAGE_SIZE]
    buttons = []
    for item in page_items:
        label = f"{item.ticket_number or item.id}"
        if item.status == "FINISHED":
            continue  # Законченные — без кнопок
        if item.status == "IN_PROGRESS":
            buttons.append(
                [
                    InlineKeyboardButton(
                        text=f"✅ Вошёл {label}",
                        callback_data=f"observer:enter:{item.id}:{doctor_id}",
                    ),
                ]
            )
        elif item.status in ("COMPLETED", "PAID"):
            buttons.append(
                [
                    InlineKeyboardButton(
                        text=f"📞 Приём {label}",
                        callback_data=f"observer:reception:{item.id}:{doctor_id}",
                    ),
                    InlineKeyboardButton(
                        text=f"Опоздал {label}",
                        callback_data=f"observer:late:{item.id}:{doctor_id}",
                    ),
                ]
            )
        elif item.status == "WAITING":
            buttons.append(
                [
                    InlineKeyboardButton(
                        text=f"⚠️ Нужно оплатить {label}",
                        callback_data=f"observer:need_pay:{item.id}:{doctor_id}",
                    ),
                    InlineKeyboardButton(
                        text=f"Опоздал {label}",
                        callback_data=f"observer:late:{item.id}:{doctor_id}",
                    ),
                ]
            )
    nav_buttons = []
    if page > 0:
        nav_buttons.append(
            InlineKeyboardButton(
                text="◀️ Пред. страница",
                callback_data=f"observer:doctor:{doctor_id}:{page - 1}",
            )
        )
    nav_buttons.append(
        InlineKeyboardButton(text="🔄 Обновить", callback_data=f"observer:doctor:{doctor_id}:{page}")
    )
    if start + PAGE_SIZE < total:
        nav_buttons.append(
            InlineKeyboardButton(
                text="След. страница ▶️",
                callback_data=f"observer:doctor:{doctor_id}:{page + 1}",
            )
        )
    buttons.append(nav_buttons)
    buttons.append(
        [InlineKeyboardButton(text="◀️ К врачам", callback_data="observer:back")],
    )
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def get_rating_keyboard(visit_id: int) -> InlineKeyboardMarkup:
    """Create a rating keyboard with 1-5 stars."""
    buttons = [
        [
            InlineKeyboardButton(text="⭐ 1", callback_data=f"rate_visit:{visit_id}:1"),
            InlineKeyboardButton(text="⭐ 2", callback_data=f"rate_visit:{visit_id}:2"),
            InlineKeyboardButton(text="⭐ 3", callback_data=f"rate_visit:{visit_id}:3"),
            InlineKeyboardButton(text="⭐ 4", callback_data=f"rate_visit:{visit_id}:4"),
            InlineKeyboardButton(text="⭐ 5", callback_data=f"rate_visit:{visit_id}:5"),
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=buttons)
