from pydantic import BaseModel, ConfigDict
from datetime import datetime
from typing import Optional, List, Any


class LabCategoryCreate(BaseModel):
    name: str


class LabCategoryRead(BaseModel):
    id: int
    name: str

    model_config = ConfigDict(from_attributes=True)


class LabTestBase(BaseModel):
    name: str
    category_id: Optional[int] = None
    code: Optional[str] = None
    price: int = 0
    duration_minutes: Optional[int] = None
    units: Optional[str] = None
    reference_min: Optional[float] = None
    reference_max: Optional[float] = None
    template_values: Optional[dict[str, Any]] = None
    is_active: bool = True


class LabTestCreate(LabTestBase):
    pass


class LabTestRead(LabTestBase):
    id: int

    model_config = ConfigDict(from_attributes=True)


class LabOrderBase(BaseModel):
    patient_id: int
    doctor_id: Optional[int] = None
    status: str = "PENDING"
    total_amount: int = 0


class LabOrderCreate(LabOrderBase):
    pass


class PatientNameOnly(BaseModel):
    id: int
    full_name: str

    class Config:
        from_attributes = True


class DoctorNameOnly(BaseModel):
    id: int
    full_name: str

    class Config:
        from_attributes = True


class LabOrderRead(LabOrderBase):
    id: int
    created_at: datetime
    completed_at: Optional[datetime] = None
    patient: Optional[PatientNameOnly] = None
    doctor: Optional[DoctorNameOnly] = None
    results: list["LabResultRead"] = []

    class Config:
        from_attributes = True


class LabResultBase(BaseModel):
    order_id: int
    test_id: int
    value: str
    is_abnormal: bool = False
    comment: Optional[str] = None
    performed_at: Optional[datetime] = None


class LabResultCreate(LabResultBase):
    pass


class LabResultRead(LabResultBase):
    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class LabOrderDetailRead(BaseModel):
    id: int
    patient_id: int
    doctor_id: Optional[int] = None
    status: str
    created_at: datetime
    completed_at: Optional[datetime] = None
    results: list["LabResultWithTest"]

    class Config:
        from_attributes = True


class LabResultWithTest(BaseModel):
    id: int
    value: str
    is_abnormal: bool
    comment: Optional[str]
    test: LabTestRead

    class Config:
        from_attributes = True


class LabResultUpdate(BaseModel):
    result_id: int
    value: str
    is_abnormal: bool = False
    comment: Optional[str] = None
