"""Queue actions (enter, late) — shared by API and Telegram bot."""

from datetime import date, datetime, timedelta, timezone

from sqlalchemy import nulls_last, select

from sqlalchemy import nulls_last, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.modules.doctors.models import DoctorService
from backend.modules.reception.models import QueueItem


async def _get_avg_duration_map(
    db: AsyncSession, doctor_ids: list[int]
) -> dict[int, int]:
    if not doctor_ids:
        return {}
    res = await db.execute(
        select(DoctorService)
        .where(
            DoctorService.doctor_id.in_(doctor_ids),
            DoctorService.deleted_at.is_(None),
        )
        .order_by(DoctorService.doctor_id.asc(), DoctorService.priority.desc())
    )
    out: dict[int, int] = {}
    for svc in res.scalars().all():
        if svc.doctor_id not in out:
            out[svc.doctor_id] = max(1, int(svc.average_duration_minutes or 15))
    return out


async def recalculate_queue_eta(db: AsyncSession, queue_date: date) -> None:
    res = await db.execute(
        select(QueueItem)
        .where(
            QueueItem.queue_date == queue_date,
            QueueItem.status == "WAITING",
        )
        .order_by(
            nulls_last(QueueItem.sort_order.asc()),
            QueueItem.created_at.asc(),
            QueueItem.id.asc(),
        )
    )
    items = list(res.scalars().all())
    doctor_ids = [int(i.doctor_id) for i in items if i.doctor_id]
    durations = await _get_avg_duration_map(db, doctor_ids)
    doctor_base_times: dict[int, datetime] = {}
    for doctor_id in doctor_ids:
        in_progress_res = await db.execute(
            select(QueueItem).where(
                QueueItem.doctor_id == doctor_id,
                QueueItem.queue_date == queue_date,
                QueueItem.status == "IN_PROGRESS",
                QueueItem.deleted_at.is_(None),
            )
        )
        in_progress = in_progress_res.scalars().first()
        if in_progress:
            avg_duration = durations.get(doctor_id, 15)
            base = in_progress.created_at or datetime.now(timezone.utc)
            doctor_base_times[doctor_id] = base + timedelta(minutes=avg_duration)
        else:
            doctor_base_times[doctor_id] = datetime.now(timezone.utc)
    for item in items:
        doctor_id = int(item.doctor_id) if item.doctor_id else 0
        if doctor_id not in doctor_base_times:
            doctor_base_times[doctor_id] = datetime.now(timezone.utc)
        item.estimated_start_time = doctor_base_times[doctor_id]
        avg_duration = durations.get(doctor_id, 15)
        doctor_base_times[doctor_id] += timedelta(minutes=avg_duration)
    await db.commit()


async def set_in_progress_queue_item(db: AsyncSession, item_id: int) -> QueueItem | None:
    """Mark patient as in reception (в приёме). Auto-complete any other IN_PROGRESS for same doctor."""
    item = await db.get(QueueItem, item_id)
    if not item:
        return None
    if item.status not in ("COMPLETED", "PAID"):
        return None
    # Auto-complete current IN_PROGRESS for same doctor (№1 вышел → статус Завершено)
    if item.doctor_id and item.queue_date:
        res = await db.execute(
            select(QueueItem).where(
                QueueItem.doctor_id == item.doctor_id,
                QueueItem.queue_date == item.queue_date,
                QueueItem.status == "IN_PROGRESS",
                QueueItem.id != item.id,
                QueueItem.deleted_at.is_(None),
            )
        )
        for prev in res.scalars().all():
            prev.status = "FINISHED"
            prev.finished_at = datetime.now(timezone.utc)
    item.status = "IN_PROGRESS"
    item.entered_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(item)
    await recalculate_queue_eta(db, item.queue_date)
    return item


async def enter_queue_item(db: AsyncSession, item_id: int) -> QueueItem | None:
    """Mark patient as entered/finished. Returns item or None if not found."""
    item = await db.get(QueueItem, item_id)
    if not item:
        return None
    if item.status not in ("WAITING", "IN_PROGRESS"):
        return None
    item.status = "FINISHED"
    item.finished_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(item)
    await recalculate_queue_eta(db, item.queue_date)
    return item


async def late_queue_item(db: AsyncSession, item_id: int) -> QueueItem | None:
    """Mark patient as late (move back 3 spots). Returns item or None."""
    item = await db.get(QueueItem, item_id)
    if not item:
        return None
    if item.status == "IN_PROGRESS":
        item.status = "WAITING"
        await db.flush()
    return await move_back_queue_item(db, item_id)


def _queue_status_can_move_back(status: str) -> bool:
    """WAITING, PAID, COMPLETED can be moved back (Опоздал)."""
    return status in ("WAITING", "PAID", "COMPLETED")


async def move_back_queue_item(db: AsyncSession, item_id: int) -> QueueItem | None:
    item = await db.get(QueueItem, item_id)
    if not item or not _queue_status_can_move_back(item.status):
        return None
    res = await db.execute(
        select(QueueItem)
        .where(
            QueueItem.queue_date == item.queue_date,
            QueueItem.deleted_at.is_(None),
            QueueItem.status.in_(("WAITING", "COMPLETED", "PAID", "IN_PROGRESS")),
        )
        .order_by(
            nulls_last(QueueItem.sort_order.asc()),
            QueueItem.created_at.asc(),
            QueueItem.id.asc(),
        )
    )
    all_items = list(res.scalars().all())
    movable_items = [q for q in all_items if _queue_status_can_move_back(q.status)]
    try:
        idx = next(i for i, q in enumerate(movable_items) if q.id == item.id)
    except StopIteration:
        return None
    move_by = 3
    new_idx = min(idx + move_by, len(movable_items) - 1)
    if new_idx != idx:
        moved = movable_items.pop(idx)
        movable_items.insert(new_idx, moved)
    movable_iter = iter(movable_items)
    reordered: list[QueueItem] = []
    for q in all_items:
        if _queue_status_can_move_back(q.status):
            reordered.append(next(movable_iter))
        else:
            reordered.append(q)
    for order, q in enumerate(reordered, start=1):
        q.sort_order = order
    await db.commit()
    await recalculate_queue_eta(db, item.queue_date)
    await db.refresh(item)
    return item
