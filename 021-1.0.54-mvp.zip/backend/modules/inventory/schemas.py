from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class InventoryItemBase(BaseModel):
    name: str
    unit: str = "pcs"
    low_stock_threshold: float = 0.0


class InventoryItemCreate(InventoryItemBase):
    pass


class InventoryItemRead(InventoryItemBase):
    id: int
    current_stock: float
    created_at: datetime

    class Config:
        from_attributes = True


class StockMovementBase(BaseModel):
    item_id: int
    change_amount: float
    reason: str


class StockMovementCreate(StockMovementBase):
    order_id: Optional[int] = None


class StockMovementRead(StockMovementBase):
    id: int
    order_id: Optional[int] = None
    created_at: datetime

    class Config:
        from_attributes = True


class LabTestConsumableBase(BaseModel):
    lab_test_id: int
    inventory_item_id: int
    quantity_per_test: float


class LabTestConsumableCreate(LabTestConsumableBase):
    pass


class LabTestConsumableRead(LabTestConsumableBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True


class RestockRequest(BaseModel):
    amount: float
