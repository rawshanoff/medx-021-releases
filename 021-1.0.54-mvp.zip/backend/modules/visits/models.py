from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Date
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from backend.core.database import Base, SoftDeleteMixin


class Visit(SoftDeleteMixin, Base):
    """Medical visit record with complaints, diagnosis, recommendations"""
    __tablename__ = "visits"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False, index=True)
    doctor_id = Column(Integer, ForeignKey("doctors.id"), nullable=False, index=True)
    visit_date = Column(Date, nullable=False, index=True)
    
    complaints = Column(Text, nullable=True)
    diagnosis = Column(Text, nullable=True)
    recommendations = Column(Text, nullable=True)
    
    # Feedback fields
    rating = Column(Integer, nullable=True)  # 1-5 stars
    feedback_comment = Column(Text, nullable=True)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    patient = relationship("Patient")
    doctor = relationship("Doctor")
    prescribed_services = relationship(
        "PrescribedService",
        back_populates="visit",
        cascade="all, delete-orphan",
    )
    attachments = relationship(
        "VisitAttachment",
        back_populates="visit",
        cascade="all, delete-orphan",
    )


class PrescribedService(SoftDeleteMixin, Base):
    """Service (Lab test, ultrasound, etc.) prescribed during a visit"""
    __tablename__ = "prescribed_services"

    id = Column(Integer, primary_key=True, index=True)
    visit_id = Column(Integer, ForeignKey("visits.id"), nullable=False, index=True)
    service_id = Column(Integer, ForeignKey("doctor_services.id"), nullable=False)
    quantity = Column(Integer, default=1, nullable=False)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    visit = relationship("Visit", back_populates="prescribed_services")
    service = relationship("DoctorService")


class VisitAttachment(SoftDeleteMixin, Base):
    """File attachments for a visit (images, PDFs, etc.)"""
    __tablename__ = "visit_attachments"

    id = Column(Integer, primary_key=True, index=True)
    visit_id = Column(Integer, ForeignKey("visits.id"), nullable=False, index=True)
    file_path = Column(String, nullable=False)  # Relative path to uploaded file
    filename = Column(String, nullable=False)   # Original filename
    file_type = Column(String, nullable=True)   # MIME type
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    visit = relationship("Visit", back_populates="attachments")
