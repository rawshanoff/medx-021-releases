#!/usr/bin/env python
"""
Standalone Telegram bot runner.
Run this in a separate process/container to handle bot polling.
Usage: python run_telegram_bot.py
"""
import asyncio
import logging
import sys
from pathlib import Path

# Ensure `backend` package is importable
_repo_root = Path(__file__).resolve().parents[0]
if str(_repo_root) not in sys.path:
    sys.path.insert(0, str(_repo_root))

from backend.core.config import settings
from backend.core.telegram_bot import init_bot, start_bot_polling

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)

logger = logging.getLogger("telegram_bot_runner")


async def main():
    """Initialize and start bot polling"""
    logger.info("Starting Telegram bot polling...")
    
    if not settings.PATIENT_BOT_TOKEN:
        logger.error("PATIENT_BOT_TOKEN not set. Cannot start bot.")
        sys.exit(1)
    
    await init_bot()
    await start_bot_polling()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)
