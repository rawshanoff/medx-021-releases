
import asyncio
import os
import sys
from datetime import date

# Disable logs before importing
os.environ["DB_ECHO"] = "false"
sys.path.insert(0, "g:\\Projects\\021")

from backend.core.database import engine, get_db
from backend.modules.reception.models import QueueItem
from backend.modules.doctors.models import Doctor
from sqlalchemy import select, func, text, desc

async def test_add_queue():
    try:
        async with engine.connect() as conn:
             # Verify table access first
             print("Checking table access...")
             await conn.execute(text("SELECT count(*) FROM queue_items"))
             print("Table access OK.")
             
             # Find a doctor
             print("Finding a doctor...")
             res = await conn.execute(text("SELECT id, full_name, queue_prefix FROM doctors LIMIT 1"))
             doctor = res.fetchone()
             if not doctor:
                 print("No doctors found!")
                 return
             print(f"Found doctor: {doctor}")
             
             # Try to insert a queue item manually
             print("Inserting queue item...")
             QUEUE_INSERT = text("""
                INSERT INTO queue_items 
                (ticket_number, patient_name, queue_date, sequence, doctor_id, quantity, status, created_at)
                VALUES 
                (:ticket, :pname, :qdate, :seq, :doc_id, 1, 'WAITING', now())
                RETURNING id
             """)
             
             params = {
                 "ticket": f"{doctor[2]}-999",
                 "pname": "Test Patient",
                 "qdate": date.today(),
                 "seq": 999,
                 "doc_id": doctor[0]
             }
             
             res_insert = await conn.execute(QUEUE_INSERT, params)
             new_id = res_insert.scalar()
             print(f"Inserted QueueItem ID: {new_id}")
             
             # Cleanup
             await conn.execute(text(f"DELETE FROM queue_items WHERE id = {new_id}"))
             await conn.commit()
             print("Test successful!")

    except Exception as e:
         print(f"TEST FAILED: {e}")
         import traceback
         traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_add_queue())
