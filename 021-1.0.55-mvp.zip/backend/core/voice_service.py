"""Voice notification service for patients without Telegram"""
import re
import logging
from typing import Optional

logger = logging.getLogger(__name__)


class VoiceService:
    """Service for sending voice notifications to patients"""
    
    # Phone number pattern (basic international format)
    PHONE_PATTERN = re.compile(r'^\+?[1-9]\d{1,14}$')
    
    @staticmethod
    def validate_phone_number(phone_number: str) -> bool:
        """Validate phone number format"""
        if not phone_number:
            return False
        # Remove spaces, dashes, parentheses for validation
        cleaned = re.sub(r'[\s\-\(\)]+', '', phone_number)
        return bool(VoiceService.PHONE_PATTERN.match(cleaned))
    
    @staticmethod
    def make_call(phone_number: str, text: str) -> bool:
        """
        Make a voice call to the patient.
        
        Args:
            phone_number: Patient phone number (any format, will be cleaned)
            text: Text to say in the call
            
        Returns:
            True if call was initiated successfully, False otherwise
        """
        try:
            # Validate phone number
            if not VoiceService.validate_phone_number(phone_number):
                logger.warning(f"Invalid phone number format: {phone_number}")
                return False
            
            # Clean phone number
            cleaned_phone = re.sub(r'[\s\-\(\)]+', '', phone_number)
            
            # Mock implementation: Log the call
            logger.info(
                f"📞 [MOCK VOICE CALL] Initiating call to {cleaned_phone}...\n"
                f"   Message: \"{text}\""
            )
            
            # TODO: Integrate with real provider (Twilio, Asterisk, etc.)
            # Example future implementation:
            # from twilio.rest import Client
            # client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
            # call = client.calls.create(
            #     to=cleaned_phone,
            #     from_=TWILIO_PHONE_NUMBER,
            #     url=TTS_URL  # URL to TTS service for voice generation
            # )
            
            return True
        
        except Exception as e:
            logger.error(f"Failed to make voice call to {phone_number}: {e}", exc_info=True)
            return False
    
    @staticmethod
    def make_call_async(phone_number: str, text: str) -> bool:
        """
        Async-compatible wrapper for make_call.
        Currently just wraps the sync version, but allows for async implementation.
        
        Args:
            phone_number: Patient phone number
            text: Text to say in the call
            
        Returns:
            True if call was initiated successfully, False otherwise
        """
        return VoiceService.make_call(phone_number, text)
