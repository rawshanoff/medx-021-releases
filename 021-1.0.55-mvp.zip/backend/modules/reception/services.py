import logging
from datetime import datetime, timezone, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from backend.modules.reception.models import QueueItem, QueueStatus
from backend.modules.doctors.models import Doctor

logger = logging.getLogger(__name__)


async def recalculate_queue_etas(doctor_id: str, db: AsyncSession) -> None:
    """
    Recalculate estimated start times for all WAITING patients for a doctor.
    
    Algorithm:
    1. Get doctor's average_duration_minutes (default 15).
    2. Find the currently IN_PROGRESS visit (if any).
    3. Calculate base_time:
       - If IN_PROGRESS exists: started_at + avg_minutes
       - Otherwise: now()
    4. Iterate through WAITING items sorted by position/id
    5. Set estimated_start_time and increment base_time for each
    """
    try:
        # 1. Fetch doctor and get avg_minutes
        doctor_result = await db.execute(
            select(Doctor).where(Doctor.id == int(doctor_id))
        )
        doctor = doctor_result.scalars().first()
        if not doctor:
            logger.warning(f"Doctor {doctor_id} not found")
            return

        # For now, use a default of 15 minutes (could also fetch from doctor's primary service)
        avg_minutes = 15

        # 2. Find IN_PROGRESS visit for this doctor
        in_progress_result = await db.execute(
            select(QueueItem).where(
                and_(
                    QueueItem.doctor_id == int(doctor_id),
                    QueueItem.status == "IN_PROGRESS",
                    QueueItem.deleted_at.is_(None),
                )
            )
        )
        in_progress = in_progress_result.scalars().first()

        # 3. Calculate base_time
        now_utc = datetime.now(timezone.utc)
        if in_progress and in_progress.started_at:
            base_time = in_progress.started_at + timedelta(minutes=avg_minutes)
        else:
            base_time = now_utc

        # 4. Fetch all WAITING items for this doctor
        waiting_result = await db.execute(
            select(QueueItem)
            .where(
                and_(
                    QueueItem.doctor_id == int(doctor_id),
                    QueueItem.status == "WAITING",
                    QueueItem.deleted_at.is_(None),
                )
            )
            .order_by(QueueItem.position, QueueItem.id)
        )
        waiting_items = waiting_result.scalars().all()

        # 5. Update estimated_start_time for each WAITING item
        for item in waiting_items:
            item.estimated_start_time = base_time
            base_time += timedelta(minutes=avg_minutes)

        await db.commit()
        logger.info(
            f"Recalculated ETA for {len(waiting_items)} WAITING items for doctor {doctor_id}"
        )

    except Exception as e:
        logger.exception(f"Error recalculating queue ETAs for doctor {doctor_id}: {e}")
        await db.rollback()
