import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from backend.modules.inventory.models import (
    InventoryItem,
    StockMovement,
    StockMovementReason,
    LabTestConsumable,
)

logger = logging.getLogger("medx.inventory")


async def add_stock(
    db: AsyncSession,
    item_id: int,
    amount: float,
    reason: StockMovementReason = StockMovementReason.PURCHASE,
) -> None:
    """Add stock and create movement record"""
    item = await db.get(InventoryItem, item_id)
    if not item:
        logger.warning(f"[INVENTORY] Item {item_id} not found")
        return

    item.current_stock += amount
    
    movement = StockMovement(
        item_id=item_id,
        change_amount=amount,
        reason=reason,
    )
    db.add(movement)
    logger.info(f"[INVENTORY] Added {amount} {item.unit} to {item.name}")


async def deduct_stock_for_test(
    db: AsyncSession,
    lab_test_id: int,
    order_id: int,
) -> bool:
    """Deduct consumables for a completed test"""
    # Get consumables for this test
    result = await db.execute(
        select(LabTestConsumable).where(
            LabTestConsumable.lab_test_id == lab_test_id,
            LabTestConsumable.deleted_at.is_(None),
        )
    )
    consumables = result.scalars().all()

    if not consumables:
        logger.info(f"[INVENTORY] No consumables defined for test {lab_test_id}")
        return True

    for consumable in consumables:
        item = await db.get(InventoryItem, consumable.inventory_item_id)
        if not item:
            logger.warning(f"[INVENTORY] Item {consumable.inventory_item_id} not found")
            continue

        if item.current_stock < consumable.quantity_per_test:
            logger.warning(
                f"[INVENTORY] Insufficient stock: {item.name} "
                f"(available: {item.current_stock}, needed: {consumable.quantity_per_test})"
            )
            return False

        item.current_stock -= consumable.quantity_per_test

        movement = StockMovement(
            item_id=consumable.inventory_item_id,
            change_amount=-consumable.quantity_per_test,
            reason=StockMovementReason.USAGE,
            order_id=order_id,
        )
        db.add(movement)
        logger.info(
            f"[INVENTORY] Deducted {consumable.quantity_per_test} {item.unit} "
            f"of {item.name} for test {lab_test_id}, order {order_id}"
        )

    return True
