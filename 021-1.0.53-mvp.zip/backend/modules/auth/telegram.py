"""
Telegram Mini App authentication for Observer.
Validates initData from Telegram WebApp and issues JWT for staff users.
"""

import json
import hmac
import hashlib
from urllib.parse import parse_qs, unquote

from backend.core.config import settings
from backend.core.database import get_db
from backend.modules.auth import create_access_token
from backend.modules.users.models import User
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/auth", tags=["Authentication"])


class TelegramInitDataRequest(BaseModel):
    initData: str


class TelegramInitDataResponse(BaseModel):
    token: str
    role: str


def _validate_telegram_init_data(init_data: str, bot_token: str) -> dict | None:
    """
    Validate Telegram WebApp initData using HMAC-SHA256.
    Returns parsed user dict if valid, None otherwise.
    """
    if not init_data or not bot_token:
        return None

    try:
        parsed = parse_qs(init_data, keep_blank_values=True)
        hash_val = parsed.get("hash", [None])[0]
        if not hash_val:
            return None

        # Build data check string: sorted key=value pairs, exclude hash
        data_pairs = []
        for key, vals in parsed.items():
            if key == "hash":
                continue
            if vals:
                data_pairs.append(f"{key}={unquote(str(vals[0]))}")

        data_check_string = "\n".join(sorted(data_pairs))

        # secret_key = HMAC-SHA256("WebAppData", bot_token)
        secret_key = hmac.new(
            b"WebAppData",
            bot_token.encode(),
            hashlib.sha256,
        ).digest()

        # data_check = HMAC-SHA256(secret_key, data_check_string)
        computed_hash = hmac.new(
            secret_key,
            data_check_string.encode(),
            hashlib.sha256,
        ).hexdigest()

        if not hmac.compare_digest(computed_hash, hash_val):
            return None

        # Extract user
        user_str = parsed.get("user", [None])[0]
        if not user_str:
            return None

        user_data = json.loads(unquote(str(user_str)))
        return user_data

    except Exception:
        return None


@router.post("/telegram-miniapp", response_model=TelegramInitDataResponse)
async def telegram_miniapp_auth(
    body: TelegramInitDataRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Authenticate staff user via Telegram WebApp initData.
    User must be pre-registered with telegram_chat_id (set by Admin).
    """
    bot_token = settings.OBSERVER_BOT_TOKEN
    if not bot_token:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Telegram auth not configured",
        )

    user_data = _validate_telegram_init_data(body.initData, bot_token)
    if not user_data:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid initData",
        )

    telegram_id = user_data.get("id")
    if telegram_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid initData: missing user id",
        )

    result = await db.execute(
        select(User).where(
            User.telegram_chat_id == int(telegram_id),
            User.deleted_at.is_(None),
        )
    )
    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User not found. Admin must add your Telegram account first.",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User is inactive",
        )

    token = create_access_token(
        data={"sub": user.username, "role": user.role.value, "user_id": user.id}
    )
    return TelegramInitDataResponse(token=token, role=user.role.value)
