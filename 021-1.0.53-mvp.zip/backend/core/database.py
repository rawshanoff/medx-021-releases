import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from backend.core.config import settings
from sqlalchemy import Column, DateTime, text
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import declarative_base, sessionmaker

engine = create_async_engine(settings.DATABASE_URL, echo=settings.DB_ECHO)

SessionLocal = sessionmaker(bind=engine, class_=AsyncSession, expire_on_commit=False)

Base = declarative_base()

logger = logging.getLogger("medx.db")


def _flush_logs() -> None:
    """Flush all log handlers so output appears before process exit."""
    for h in logging.root.handlers:
        try:
            h.flush()
        except Exception:
            pass
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass


class SoftDeleteMixin:
    deleted_at = Column(DateTime(timezone=True), nullable=True, index=True)

    def soft_delete(self) -> None:
        # Use UTC timestamp to avoid timezone drift.
        self.deleted_at = datetime.now(timezone.utc)


async def get_db():
    async with SessionLocal() as session:
        yield session


async def _check_db_version():
    """Проверка версии БД через Alembic.

    Проверяет, что таблица alembic_version существует и содержит версию.
    Детальная проверка соответствия последней миграции выполняется через команду alembic.
    """
    try:
        async with engine.begin() as conn:
            # Проверяем, существует ли таблица alembic_version
            result = await conn.execute(text("""
                    SELECT EXISTS (
                        SELECT FROM information_schema.tables 
                        WHERE table_name = 'alembic_version'
                    )
                    """))
            table_exists = result.scalar()

            if not table_exists:
                logger.warning(
                    "⚠️  Таблица alembic_version не найдена. "
                    "Возможно, миграции не применены. Запустите: alembic upgrade head"
                )
                return True  # Не блокируем запуск, но предупреждаем

            # Получаем текущую версию БД
            result = await conn.execute(text("SELECT version_num FROM alembic_version"))
            current_rev = result.scalar_one_or_none()

            if not current_rev:
                logger.warning(
                    "⚠️  База данных не имеет версии Alembic. "
                    "Возможно, миграции не применены. Запустите: alembic upgrade head"
                )
                return True

            logger.info(f"✅ Версия БД: {current_rev}")
            logger.info(
                "💡 Для проверки соответствия последней миграции выполните: alembic current"
            )
            return True
    except Exception as e:
        logger.warning(f"⚠️  Не удалось проверить версию БД: {e}. Продолжаем запуск...")
        # Не блокируем запуск, если проверка не удалась (например, в тестах)
        return True


async def _auto_migrate_if_enabled() -> None:
    """Desktop helper: auto-apply Alembic migrations if enabled.

    On target machines the DB can be empty. For MVP desktop we want a smooth first-run:
    if MEDX_AUTO_MIGRATE=1, run `alembic upgrade head` using Alembic API.

    We rely on external migration files shipped with Electron extraResources:
      <MEDX_APP_DIR>/backend/alembic.ini
      <MEDX_APP_DIR>/backend/alembic/versions/...
    """
    env_flag = os.getenv("MEDX_AUTO_MIGRATE", "").strip() == "1"
    # In packaged desktop backend we want migrations on first run even if env vars were lost.
    frozen = bool(getattr(sys, "frozen", False))
    if not (env_flag or frozen):
        return

    # Prefer explicit app dir from Electron, otherwise fallback to current working directory.
    app_dir = os.getenv("MEDX_APP_DIR", "").strip() or os.getcwd()

    root = Path(app_dir)
    cfg_path = root / "backend" / "alembic.ini"
    script_location = root / "backend" / "alembic"
    if not cfg_path.exists() or not script_location.exists():
        logger.warning(
            "Auto-migrate skipped: alembic files not found. "
            f"cfg={cfg_path} script_location={script_location}"
        )
        return

    # Check if migrations needed: either alembic_version or users table missing.
    async with engine.begin() as conn:
        result = await conn.execute(text("""
                SELECT
                  EXISTS (
                    SELECT FROM information_schema.tables
                    WHERE table_name = 'alembic_version'
                  ) AS has_alembic,
                  EXISTS (
                    SELECT FROM information_schema.tables
                    WHERE table_name = 'users'
                  ) AS has_users
                """))
        row = result.first()
        has_alembic = bool(row[0]) if row is not None else False
        has_users = bool(row[1]) if row is not None else False

    if has_alembic and has_users:
        return

    logger.info(
        "БД пустая: применяем миграции Alembic автоматически (app_dir=%s)...",
        root,
    )
    _flush_logs()

    def _run_migration() -> None:
        from alembic.config import Config

        from alembic import command

        # Ensure Alembic uses the same DATABASE_URL as the engine (critical for packaged app).
        db_url = str(settings.DATABASE_URL)
        os.environ["DATABASE_URL"] = db_url

        cfg = Config(str(cfg_path))
        cfg.set_main_option("script_location", str(script_location).replace("\\", "/"))
        command.upgrade(cfg, "head")

    try:
        import asyncio

        await asyncio.wait_for(asyncio.to_thread(_run_migration), timeout=120.0)
        logger.info("✅ Миграции применены (alembic upgrade head)")
        _flush_logs()
    except asyncio.TimeoutError:
        logger.error("❌ Миграция не завершилась за 120 сек (timeout)")
        _flush_logs()
        raise
    except Exception:
        logger.exception("❌ Не удалось применить миграции автоматически")
        _flush_logs()
        raise


def _stamp_via_sql() -> None:
    """Force alembic_version to head via direct SQL (when Alembic stamp fails)."""
    from sqlalchemy import create_engine, text

    raw = str(settings.DATABASE_URL)
    if raw.startswith("postgresql+asyncpg://"):
        raw = raw.replace("postgresql+asyncpg://", "postgresql+psycopg2://", 1)
    engine = create_engine(raw)
    with engine.connect() as conn:
        conn.execute(text("""
            CREATE TABLE IF NOT EXISTS alembic_version (
                version_num VARCHAR(32) NOT NULL PRIMARY KEY
            )
        """))
        conn.execute(text("DELETE FROM alembic_version"))
        conn.execute(text("INSERT INTO alembic_version (version_num) VALUES ('a00000000001')"))
        conn.commit()


def run_migration_standalone() -> bool:
    """Sync migration for --migrate-only subprocess. Returns True on success."""
    env_flag = os.getenv("MEDX_AUTO_MIGRATE", "").strip() == "1"
    frozen = bool(getattr(sys, "frozen", False))
    if not (env_flag or frozen):
        return True

    app_dir = os.getenv("MEDX_APP_DIR", "").strip() or os.getcwd()
    root = Path(app_dir)
    cfg_path = root / "backend" / "alembic.ini"
    script_location = root / "backend" / "alembic"
    if not cfg_path.exists() or not script_location.exists():
        logger.warning("Migration skipped: alembic files not found")
        return True

    os.environ["DATABASE_URL"] = str(settings.DATABASE_URL)
    from alembic.config import Config
    from alembic import command

    cfg = Config(str(cfg_path))
    cfg.set_main_option("script_location", str(script_location).replace("\\", "/"))

    try:
        command.upgrade(cfg, "head")
        return True
    except Exception as e:
        import traceback
        err_msg = str(e).lower()
        tb = traceback.format_exc()
        print(f"Migration error: {e}\n{tb}", file=sys.stderr)
        # DB has unknown revision (e.g. f8a9b0c1d2e3 from old install) — stamp to head
        is_unknown_rev = (
            "can't locate revision" in err_msg
            or "no such revision" in err_msg
            or "resolutionerror" in err_msg
        )
        # DB has partial schema (types/tables exist, alembic_version empty) — stamp to head
        is_partial_schema = (
            "duplicate_object" in err_msg
            or "duplicate_object" in tb.lower()
            or "already exists" in err_msg
        )
        if is_unknown_rev or is_partial_schema:
            logger.info("DB has unknown revision, stamping to head")
            try:
                command.stamp(cfg, "head")
                return True
            except Exception:
                # Fallback: direct SQL update (Alembic stamp may fail with same error)
                try:
                    _stamp_via_sql()
                    return True
                except Exception:
                    logger.exception("Stamp failed")
                    return False
        logger.exception("Migration failed")
        return False


def _schema_likely_exists() -> bool:
    """Check if users table exists (schema was applied by old migration)."""
    try:
        from sqlalchemy import create_engine, text

        raw = str(settings.DATABASE_URL)
        if raw.startswith("postgresql+asyncpg://"):
            raw = raw.replace("postgresql+asyncpg://", "postgresql+psycopg2://", 1)
        engine = create_engine(raw)
        with engine.connect() as conn:
            r = conn.execute(text(
                "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'users')"
            ))
            return bool(r.scalar())
    except Exception:
        return False


async def init_db():
    """Проверка доступности БД и версии схемы.

    Важно: схемой БД управляем через Alembic миграции, а не через create_all().
    """
    logger.info("init_db: checking DB connection...")
    _flush_logs()
    async with engine.begin() as conn:
        await conn.execute(text("SELECT 1"))

    # Desktop: create schema automatically on first run (when DB is empty).
    await _auto_migrate_if_enabled()

    # Проверяем версию БД
    await _check_db_version()
    logger.info("init_db: done")
    _flush_logs()
