import logging
import re
from datetime import datetime, timezone
from typing import List

from backend.core.database import get_db
from backend.core.schemas import MessageResponse
from backend.modules.appointments.models import Appointment
from backend.modules.auth import require_roles
from backend.modules.finance.models import Transaction
from backend.modules.patients.models import Patient
from backend.modules.patients.schemas import (
    PatientAppointmentHistoryRead,
    PatientCreate,
    PatientHistoryRead,
    PatientQueueHistoryRead,
    PatientRead,
    PatientTransactionRead,
    PatientUpdate,
    _normalize_phone,
)
from backend.modules.patients.text import (
    contains_cyrillic,
    contains_latin,
    cyrillic_to_latin,
    latin_to_cyrillic,
    normalize_full_name,
)
from backend.modules.reception.models import QueueItem
from backend.modules.users.models import UserRole
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()
logger = logging.getLogger("medx.patients")

_NON_DIGITS = re.compile(r"\D+")


def _phone_variants_for_uniqueness(raw: str) -> list[str]:
    """Generate phone variants to prevent duplicates from legacy formats.

    We store canonical values like +998XXXXXXXXX, but old records may have:
    - 9 digits (local)
    - 998XXXXXXXXX (no plus)
    - 0XXXXXXXXX
    """
    try:
        canon = _normalize_phone(raw)
    except Exception:
        canon = str(raw or "").strip()
    digits = _NON_DIGITS.sub("", canon)
    out: list[str] = []
    for v in [canon, digits, canon[1:] if canon.startswith("+") else ""]:
        v = (v or "").strip()
        if v and v not in out:
            out.append(v)
    # Uzbekistan: add local formats too
    if digits.startswith("998") and len(digits) == 12:
        local9 = digits[3:]
        for v in [local9, "0" + local9]:
            if v not in out:
                out.append(v)
    return out


@router.post("/", response_model=PatientRead, status_code=201)
async def create_patient(
    patient: PatientCreate,
    db: AsyncSession = Depends(get_db),
    _user=Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.OWNER,
            UserRole.RECEPTIONIST,
            UserRole.DOCTOR,
            UserRole.CASHIER,
        )
    ),
):
    # Check phone uniqueness (including legacy formats)
    variants = _phone_variants_for_uniqueness(patient.phone)
    result = await db.execute(select(Patient).where(Patient.phone.in_(variants)))
    if result.scalars().first():
        raise HTTPException(
            status_code=400, detail="Patient with this phone already exists"
        )

    payload = patient.model_dump()
    if payload.get("full_name"):
        payload["full_name"] = normalize_full_name(payload["full_name"])
    if payload.get("phone"):
        # Ensure canonical phone even if schema validators were bypassed.
        payload["phone"] = _normalize_phone(payload["phone"])

    new_patient = Patient(**payload)
    db.add(new_patient)
    await db.commit()
    await db.refresh(new_patient)
    return new_patient


@router.get("/", response_model=List[PatientRead])
async def search_patients(
    q: str = "",  # Legacy global search
    phone: str = None,
    full_name: str = None,
    birth_date: str = None,  # Expect ISO string YYYY-MM-DD
    skip: int = 0,
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
    _user=Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.OWNER,
            UserRole.RECEPTIONIST,
            UserRole.DOCTOR,
            UserRole.CASHIER,
        )
    ),
):
    query = select(Patient).where(Patient.deleted_at.is_(None))

    # Granular filters (AND logic)
    if phone:
        query = query.where(Patient.phone.ilike(f"%{phone}%"))
    if full_name:
        # Multi-script search: if user types Latin, also match Cyrillic and vice versa.
        variants = [full_name.strip()]
        if contains_latin(full_name):
            variants.append(latin_to_cyrillic(full_name))
        if contains_cyrillic(full_name):
            variants.append(cyrillic_to_latin(full_name))
        # remove duplicates / empties
        uniq = []
        for v in variants:
            v = (v or "").strip()
            if v and v not in uniq:
                uniq.append(v)
        query = query.where(or_(*[Patient.full_name.ilike(f"%{v}%") for v in uniq]))
    if birth_date:
        # Assuming birth_date in DB is Date object. comparing with string might need casting or parsing
        # simple exact match
        from datetime import date

        try:
            # handle potential format issues casually
            bd = date.fromisoformat(birth_date)
            query = query.where(Patient.birth_date == bd)
        except ValueError as err:
            logger.debug("Invalid birth_date filter: %r", birth_date)
            raise HTTPException(
                status_code=400,
                detail="Invalid birth_date format. Expected YYYY-MM-DD.",
            ) from err

    # Fallback to global search if no specific filters provided but 'q' is there
    if not (phone or full_name or birth_date) and q:
        query = query.where(
            or_(Patient.full_name.ilike(f"%{q}%"), Patient.phone.ilike(f"%{q}%"))
        )

    query = query.offset(skip).limit(limit).order_by(Patient.full_name)
    result = await db.execute(query)
    return result.scalars().all()


@router.get("/archived", response_model=List[PatientRead])
@router.get("/archived/", response_model=List[PatientRead])
async def list_archived_patients(
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    result = await db.execute(
        select(Patient)
        .where(Patient.deleted_at.is_not(None))
        .order_by(Patient.full_name)
        .limit(500)
    )
    return result.scalars().all()


@router.post("/{patient_id}/restore", response_model=MessageResponse)
async def restore_patient(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    result = await db.execute(select(Patient).where(Patient.id == patient_id))
    patient = result.scalars().first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    if patient.deleted_at is None:
        return {"message": "Patient is already active"}

    patient.deleted_at = None
    await db.commit()
    return {"message": "Patient restored successfully"}


@router.get("/{patient_id}", response_model=PatientRead)
async def get_patient(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.OWNER,
            UserRole.RECEPTIONIST,
            UserRole.DOCTOR,
            UserRole.CASHIER,
        )
    ),
):
    result = await db.execute(
        select(Patient).where(Patient.id == patient_id, Patient.deleted_at.is_(None))
    )
    patient = result.scalars().first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")
    return patient


@router.put("/{patient_id}", response_model=PatientRead)
async def update_patient(
    patient_id: int,
    patient_update: PatientUpdate,
    db: AsyncSession = Depends(get_db),
    _user=Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.OWNER,
            UserRole.RECEPTIONIST,
            UserRole.DOCTOR,
            UserRole.CASHIER,
        )
    ),
):
    result = await db.execute(
        select(Patient).where(Patient.id == patient_id, Patient.deleted_at.is_(None))
    )
    patient = result.scalars().first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    update_data = patient_update.model_dump(exclude_unset=True)
    if "full_name" in update_data and update_data["full_name"]:
        update_data["full_name"] = normalize_full_name(update_data["full_name"])
    if "phone" in update_data and update_data["phone"]:
        update_data["phone"] = _normalize_phone(update_data["phone"])
        variants = _phone_variants_for_uniqueness(update_data["phone"])
        # Exclude self
        dup = await db.execute(
            select(Patient).where(Patient.id != patient_id, Patient.phone.in_(variants))
        )
        if dup.scalars().first():
            raise HTTPException(
                status_code=400, detail="Patient with this phone already exists"
            )
    for key, value in update_data.items():
        setattr(patient, key, value)

    await db.commit()
    await db.refresh(patient)
    return patient


@router.post("/deduplicate", response_model=MessageResponse)
async def deduplicate_patients(
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.OWNER)),
):
    """Normalize names/phones and merge duplicates by phone.

    Keeps the smallest patient.id as canonical for each normalized phone.
    Moves related records (transactions, queue, appointments, files) to canonical.
    Soft-deletes duplicates and makes their phone unique to satisfy DB constraint.
    """
    res = await db.execute(select(Patient).order_by(Patient.id.asc()))
    patients = list(res.scalars().all())

    by_phone: dict[str, int] = {}
    merged = 0
    normalized = 0

    for p in patients:
        # Skip already deleted patients (keep as-is)
        if getattr(p, "deleted_at", None) is not None:
            continue

        norm_phone = _normalize_phone(p.phone)
        norm_name = normalize_full_name(p.full_name)

        # If first time seeing this phone, set canonical id.
        canonical_id = by_phone.get(norm_phone)
        if canonical_id is None:
            by_phone[norm_phone] = p.id
            canonical_id = p.id

        if canonical_id == p.id:
            # Canonical: normalize fields in-place.
            if p.phone != norm_phone:
                p.phone = norm_phone
                normalized += 1
            if p.full_name != norm_name:
                p.full_name = norm_name
                normalized += 1
            continue

        # Duplicate: move references to canonical, then soft-delete.
        await db.execute(
            update(Transaction)
            .where(Transaction.patient_id == p.id)
            .values(patient_id=canonical_id)
        )
        await db.execute(
            update(QueueItem)
            .where(QueueItem.patient_id == p.id)
            .values(patient_id=canonical_id)
        )
        await db.execute(
            update(Appointment)
            .where(Appointment.patient_id == p.id)
            .values(patient_id=canonical_id)
        )

        try:
            from backend.modules.files.models import (
                FileDeliveryLog,
                PatientFile,
                TelegramLinkToken,
            )

            await db.execute(
                update(PatientFile)
                .where(PatientFile.patient_id == p.id)
                .values(patient_id=canonical_id)
            )
            await db.execute(
                update(FileDeliveryLog)
                .where(FileDeliveryLog.patient_id == p.id)
                .values(patient_id=canonical_id)
            )
            await db.execute(
                update(TelegramLinkToken)
                .where(TelegramLinkToken.patient_id == p.id)
                .values(patient_id=canonical_id)
            )
        except Exception:
            # files module may be absent in some deployments; ignore
            logger.debug(
                "Skipping files tables updates during deduplicate (files module unavailable)",
                exc_info=True,
            )

        # Make phone unique to avoid constraint collision with canonical.
        p.phone = f"{norm_phone}__DUP_{p.id}"
        p.full_name = norm_name
        try:
            # Soft delete marker (if mixin exists)
            if hasattr(p, "deleted_at"):
                p.deleted_at = datetime.now(timezone.utc)
        except Exception:
            logger.warning(
                "Failed to set deleted_at during deduplicate for patient_id=%s",
                getattr(p, "id", None),
                exc_info=True,
            )
        merged += 1

    await db.commit()
    return {"message": f"Deduplicate done. normalized={normalized}, merged={merged}"}


@router.delete("/{patient_id}", response_model=MessageResponse)
async def delete_patient(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.OWNER,
            UserRole.RECEPTIONIST,
        )
    ),
):
    """Archive patient (soft delete)"""
    result = await db.execute(
        select(Patient).where(Patient.id == patient_id, Patient.deleted_at.is_(None))
    )
    patient = result.scalars().first()
    if not patient:
        raise HTTPException(status_code=404, detail="Patient not found")

    # Cancel active queue items to avoid orphaned active queue rows.
    await db.execute(
        update(QueueItem)
        .where(QueueItem.patient_id == patient_id, QueueItem.status == "WAITING")
        .values(status="CANCELLED")
    )
    patient.soft_delete()
    await db.commit()
    return {"message": "Patient archived successfully"}


@router.get("/{patient_id}/history", response_model=PatientHistoryRead)
async def get_patient_history(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(
        require_roles(
            UserRole.ADMIN,
            UserRole.OWNER,
            UserRole.RECEPTIONIST,
            UserRole.DOCTOR,
            UserRole.CASHIER,
        )
    ),
):
    patient = await db.get(Patient, patient_id)
    if not patient or patient.deleted_at is not None:
        raise HTTPException(status_code=404, detail="Patient not found")

    tx_res = await db.execute(
        select(Transaction)
        .where(Transaction.patient_id == patient_id)
        .order_by(Transaction.created_at.desc())
        .limit(50)
    )
    q_res = await db.execute(
        select(QueueItem)
        .where(QueueItem.patient_id == patient_id)
        .order_by(QueueItem.created_at.desc())
        .limit(50)
    )
    a_res = await db.execute(
        select(Appointment)
        .where(Appointment.patient_id == patient_id)
        .order_by(Appointment.start_time.desc())
        .limit(50)
    )

    return PatientHistoryRead(
        transactions=[
            PatientTransactionRead.model_validate(x) for x in tx_res.scalars().all()
        ],
        queue=[
            PatientQueueHistoryRead.model_validate(x) for x in q_res.scalars().all()
        ],
        appointments=[
            PatientAppointmentHistoryRead.model_validate(x)
            for x in a_res.scalars().all()
        ],
    )
