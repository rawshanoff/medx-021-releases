#!/usr/bin/env python3
"""
Restore essential data after database hard reset.

This script:
1. Restores essential data from backup_data.json if it exists
2. Creates default Admin/Owner user if no backup found
3. Prepares the database for operation

Usage:
    python scripts/seed_essential_data.py

Input:
    backup_data.json - Optional backup file from dump_essential_data.py
"""

import asyncio
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

# Ensure backend package is importable
repo_root = Path(__file__).resolve().parents[1]
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from backend.core.config import settings
from backend.core.database import SessionLocal
from backend.modules.users.models import User, UserRole
from backend.modules.doctors.models import Doctor, DoctorService
from backend.modules.system.models import SystemSetting
from sqlalchemy import select
import bcrypt


async def seed_essential_data():
    """Restore essential data from backup or create defaults"""
    backup_file = repo_root / "backup_data.json"
    
    if backup_file.exists():
        print(f"[*] Found backup file: {backup_file}")
        await restore_from_backup(backup_file)
    else:
        print("[*] No backup found. Creating default admin/owner users...")
        await create_default_users()


async def restore_from_backup(backup_file: Path):
    """Restore data from backup_data.json"""
    print("[*] Restoring from backup...")
    
    try:
        with open(backup_file, "r", encoding="utf-8") as f:
            backup_data = json.load(f)
    except Exception as e:
        print(f"[ERROR] Could not read backup file: {e}")
        await create_default_users()
        return
    
    async with SessionLocal() as session:
        # Restore Users
        if backup_data.get("users"):
            print(f"  - Restoring {len(backup_data['users'])} users...")
            for user_data in backup_data["users"]:
                try:
                    # Check if user already exists (by username)
                    existing = await session.execute(
                        select(User).where(User.username == user_data["username"])
                    )
                    if existing.scalars().first():
                        print(f"    SKIP User {user_data['username']} already exists")
                        continue
                    
                    user = User(
                        username=user_data["username"],
                        password_hash=user_data["password_hash"],
                        full_name=user_data.get("full_name"),
                        role=UserRole[user_data["role"].upper()] if isinstance(user_data["role"], str) else user_data["role"],
                        permissions=user_data.get("permissions"),
                        is_active=user_data.get("is_active", True),
                    )
                    session.add(user)
                    print(f"    OK Restored user: {user_data['username']}")
                except Exception as e:
                    print(f"    ERROR Error restoring user {user_data.get('username')}: {e}")
            
            await session.commit()
        
        # Restore Doctors
        if backup_data.get("doctors"):
            print(f"  - Restoring {len(backup_data['doctors'])} doctors...")
            for doctor_data in backup_data["doctors"]:
                try:
                    doctor = Doctor(
                        full_name=doctor_data["full_name"],
                        specialty=doctor_data.get("specialty"),
                        room_number=doctor_data.get("room_number"),
                        queue_prefix=doctor_data.get("queue_prefix", "A"),
                        is_active=doctor_data.get("is_active", True),
                    )
                    session.add(doctor)
                except Exception as e:
                    print(f"    ERROR Error restoring doctor {doctor_data.get('full_name')}: {e}")
            
            await session.commit()
            print(f"    OK Restored doctors")
        
        # Restore Doctor Services (need to re-link to restored doctors)
        if backup_data.get("doctor_services"):
            print(f"  - Restoring {len(backup_data['doctor_services'])} doctor services...")
            for service_data in backup_data["doctor_services"]:
                try:
                    service = DoctorService(
                        doctor_id=service_data["doctor_id"],
                        name=service_data["name"],
                        price=service_data.get("price", 0),
                        average_duration_minutes=service_data.get("average_duration_minutes", 15),
                        priority=service_data.get("priority", 0),
                    )
                    session.add(service)
                except Exception as e:
                    print(f"    ERROR Error restoring service {service_data.get('name')}: {e}")
            
            await session.commit()
            print(f"    OK Restored doctor services")
        
        # Restore System Settings
        if backup_data.get("system_settings"):
            print(f"  - Restoring {len(backup_data['system_settings'])} system settings...")
            for setting_data in backup_data["system_settings"]:
                try:
                    setting = SystemSetting(
                        user_id=setting_data.get("user_id"),
                        key=setting_data["key"],
                        value=setting_data["value"],
                    )
                    session.add(setting)
                except Exception as e:
                    print(f"    ERROR Error restoring setting {setting_data.get('key')}: {e}")
            
            await session.commit()
            print(f"    OK Restored system settings")
    
    print("[OK] Backup restore complete!")


async def create_default_users():
    """Create default admin and owner users"""
    async with SessionLocal() as session:
        print("  - Creating default users...")
        
        # Check if admin already exists
        existing_admin = await session.execute(
            select(User).where(User.username == "admin")
        )
        if existing_admin.scalars().first():
            print("    SKIP Default admin user already exists")
            return
        
        # Create default admin (password: admin123)
        admin_pwd_hash = bcrypt.hashpw(b"admin123", bcrypt.gensalt(rounds=12)).decode()
        admin = User(
            username="admin",
            password_hash=admin_pwd_hash,
            full_name="System Administrator",
            role=UserRole.ADMIN,
            is_active=True,
            permissions=None,
        )
        session.add(admin)
        print("    OK Created admin user (username: admin, password: admin123)")
        
        # Create default owner (password: owner123)
        owner_pwd_hash = bcrypt.hashpw(b"owner123", bcrypt.gensalt(rounds=12)).decode()
        owner = User(
            username="owner",
            password_hash=owner_pwd_hash,
            full_name="Clinic Owner",
            role=UserRole.OWNER,
            is_active=True,
            permissions=None,
        )
        session.add(owner)
        print("    OK Created owner user (username: owner, password: owner123)")
        
        await session.commit()
    
    print("[OK] Default users created!")


if __name__ == "__main__":
    asyncio.run(seed_essential_data())
