#!/usr/bin/env python3
"""
Dump essential data before hard database reset.

This script exports critical configuration data (Users, Doctors, Services, System Settings)
to a JSON file for safekeeping. Transactional data (Queue, Finance) is intentionally skipped
for a fresh start.

Usage:
    python scripts/dump_essential_data.py

Output:
    backup_data.json - Safe backup of essential data
"""

import asyncio
import json
import sys
from datetime import datetime
from pathlib import Path

# Ensure backend package is importable
repo_root = Path(__file__).resolve().parents[1]
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from backend.core.config import settings
from backend.core.database import SessionLocal
from backend.modules.users.models import User, UserRole
from backend.modules.doctors.models import Doctor, DoctorService
from backend.modules.system.models import SystemSetting
from sqlalchemy import select, func


async def dump_essential_data():
    """Export essential data to backup_data.json"""
    print("[*] Starting data export...")
    
    backup_data = {
        "export_date": datetime.now().isoformat(),
        "database_url": settings.DATABASE_URL.replace(settings.DATABASE_URL.split("@")[0].split("://")[1], "***"),
        "users": [],
        "doctors": [],
        "doctor_services": [],
        "system_settings": [],
    }
    
    async with SessionLocal() as session:
        # Export Users
        print("  - Exporting users...")
        try:
            users = await session.execute(select(User))
            for user in users.scalars().all():
                backup_data["users"].append({
                    "id": user.id,
                    "username": user.username,
                    "password_hash": user.password_hash,  # Keep hashes for re-import
                    "full_name": user.full_name,
                    "role": user.role.value if isinstance(user.role, UserRole) else user.role,
                    "permissions": user.permissions,
                    "is_active": user.is_active,
                    "created_at": user.created_at.isoformat() if user.created_at else None,
                })
            print(f"    OK Exported {len(backup_data['users'])} users")
        except Exception as e:
            print(f"    WARN Could not export users: {e}")
        
        # Export Doctors
        print("  - Exporting doctors...")
        try:
            doctors = await session.execute(select(Doctor))
            for doctor in doctors.scalars().all():
                backup_data["doctors"].append({
                    "id": doctor.id,
                    "full_name": doctor.full_name,
                    "specialty": doctor.specialty,
                    "room_number": doctor.room_number,
                    "queue_prefix": doctor.queue_prefix,
                    "is_active": doctor.is_active,
                })
            print(f"    OK Exported {len(backup_data['doctors'])} doctors")
        except Exception as e:
            print(f"    WARN Could not export doctors: {e}")
        
        # Export Doctor Services
        print("  - Exporting doctor services...")
        try:
            services = await session.execute(select(DoctorService))
            for service in services.scalars().all():
                backup_data["doctor_services"].append({
                    "id": service.id,
                    "doctor_id": service.doctor_id,
                    "name": service.name,
                    "price": service.price,
                    "average_duration_minutes": service.average_duration_minutes,
                    "priority": service.priority,
                })
            print(f"    OK Exported {len(backup_data['doctor_services'])} doctor services")
        except Exception as e:
            print(f"    WARN Could not export doctor services: {e}")
        
        # Export System Settings
        print("  - Exporting system settings...")
        try:
            settings_items = await session.execute(select(SystemSetting))
            for setting in settings_items.scalars().all():
                backup_data["system_settings"].append({
                    "id": setting.id,
                    "user_id": setting.user_id,
                    "key": setting.key,
                    "value": setting.value,
                })
            print(f"    OK Exported {len(backup_data['system_settings'])} system settings")
        except Exception as e:
            print(f"    WARN Could not export system settings: {e}")
    
    # Write to file
    output_file = repo_root / "backup_data.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(backup_data, f, indent=2, ensure_ascii=False)
    
    print(f"\n[OK] Backup saved to: {output_file}")
    return backup_data


if __name__ == "__main__":
    asyncio.run(dump_essential_data())
