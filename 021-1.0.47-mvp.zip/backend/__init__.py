"""
021 backend package.

We keep this file to make `backend.*` imports work reliably in packaged builds
(e.g. PyInstaller) and to avoid implicit namespace-package edge cases.
"""
