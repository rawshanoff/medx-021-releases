
import asyncio
import os
import sys

# Disable logs before importing
os.environ["DB_ECHO"] = "false"
sys.path.insert(0, "g:\\Projects\\021")

from backend.core.database import engine
from sqlalchemy import text

async def inspect_table():
    try:
        async with engine.connect() as conn:
            # Get columns
            cols_result = await conn.execute(text("SELECT column_name, data_type, is_nullable FROM information_schema.columns WHERE table_name = 'queue_items'"))
            cols = cols_result.fetchall()
            print("Queue Items Columns:")
            for c in cols:
                print(f" - {c[0]}: {c[1]} (Nullable: {c[2]})")

            # Drop table if it looks broken (e.g. missing ticket_number)
            col_names = [c[0] for c in cols]
            if "ticket_number" not in col_names:
                print("Table 'queue_items' is missing 'ticket_number'. DROPPING table to allow clean recreation.")
                await conn.execute(text("DROP TABLE queue_items CASCADE"))
                print("Table dropped.")
                
                # Also we need to potentially fix alembic_version if we want to re-run the migration
                # But if we just drop it, and the migration is already 'done', we need to create a NEW migration to create it?
                # Or we can just manual create it here? 
                # Let's just drop it here and I will instruct the user to downgrade/upgrade or I will make a new migration.
            else:
                print("Table looks correct.")

            await conn.commit()
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(inspect_table())
