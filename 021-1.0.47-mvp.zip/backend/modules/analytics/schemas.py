from datetime import datetime, date
from typing import List, Optional
from pydantic import BaseModel, ConfigDict


class DoctorRatingStats(BaseModel):
    doctor_id: int
    doctor_name: str
    average_rating: float
    review_count: int

    model_config = ConfigDict(from_attributes=True)


class RecentFeedback(BaseModel):
    visit_id: int
    visit_date: date
    doctor_id: int
    doctor_name: str
    rating: int
    comment: str

    model_config = ConfigDict(from_attributes=True)


class RatingsResponse(BaseModel):
    stats: List[DoctorRatingStats]
    recent_feedback: List[RecentFeedback]
