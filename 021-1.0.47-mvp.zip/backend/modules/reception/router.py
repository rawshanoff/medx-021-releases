import logging
from datetime import date, datetime, timedelta, timezone

from backend.core.audit import log_action
from backend.core.database import get_db
from backend.core.telegram_bot import bot
from backend.core.voice_service import VoiceService
from backend.modules.auth import get_current_user, require_roles
from backend.modules.doctors.models import Doctor, DoctorService
from backend.modules.finance.models import PaymentMethod, Shift, Transaction
from backend.modules.patients.models import Patient
from backend.modules.reception.models import QueueItem
from backend.modules.reception.schemas import (
    QueueItemCreate,
    QueueItemRead,
    QueueItemUpdate,
)
from backend.modules.users.models import User, UserRole
from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks
from sqlalchemy import func, nulls_last, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

logger = logging.getLogger("medx.reception")
router = APIRouter()


async def send_telegram_notification(chat_id: int, message: str):
    """Send a Telegram notification (non-blocking)"""
    if not bot:
        logger.warning(f"Bot not initialized, cannot send notification to {chat_id}")
        return
    
    try:
        await bot.send_message(chat_id=chat_id, text=message)
        logger.info(f"Sent Telegram notification to chat_id={chat_id}")
    except Exception as e:
        logger.error(f"Failed to send Telegram notification to {chat_id}: {e}")


async def notify_patient_called(queue_item: QueueItem, doctor: Doctor, patient: Patient):
    """Notify patient that they are called (IN_PROGRESS)"""
    room_str = f"Кабинет {doctor.room_number}" if doctor.room_number else "Кабинет не указан"
    
    if patient.telegram_chat_id:
        # Send Telegram notification
        message = (
            f"🔔 **Ваша очередь\\!**\n\n"
            f"Врач: {doctor.full_name}\n"
            f"{room_str}\n\n"
            f"Пожалуйста, проходите."
        )
        await send_telegram_notification(patient.telegram_chat_id, message)
        logger.debug(f"Sent Telegram notification to patient {patient.id}")
    elif patient.phone:
        # Fallback: Send voice call for patients without Telegram
        text = f"Здравствуйте! Это клиника MedX. Ваша очередь подошла. Пожалуйста, пройдите в {room_str} к врачу {doctor.full_name}."
        success = VoiceService.make_call(patient.phone, text)
        if success:
            logger.info(f"Voice call initiated to patient {patient.id} at {patient.phone}")
        else:
            logger.warning(f"Failed to initiate voice call to patient {patient.id} at {patient.phone}")
    else:
        logger.warning(f"Patient {patient.id} has no telegram_chat_id or phone number, cannot notify")


async def notify_patient_next_in_line(queue_item: QueueItem, patient: Patient):
    """Notify next patient in line"""
    if patient.telegram_chat_id:
        # Send Telegram notification
        message = "⏳ Вы следующий в очереди\\. Приготовьтесь\\."
        await send_telegram_notification(patient.telegram_chat_id, message)
        logger.debug(f"Sent Telegram notification to patient {patient.id}")
    elif patient.phone:
        # Fallback: Send voice call for patients without Telegram
        text = "Внимание! Вы следующий в очереди. Приготовьтесь к приёму."
        success = VoiceService.make_call(patient.phone, text)
        if success:
            logger.info(f"Voice call initiated to patient {patient.id} at {patient.phone}")
        else:
            logger.warning(f"Failed to initiate voice call to patient {patient.id} at {patient.phone}")
    else:
        logger.debug(f"Patient {patient.id} has no telegram_chat_id or phone number, cannot notify")


async def _get_avg_duration_map(
    db: AsyncSession, doctor_ids: list[int]
) -> dict[int, int]:
    if not doctor_ids:
        return {}
    res = await db.execute(
        select(DoctorService)
        .where(
            DoctorService.doctor_id.in_(doctor_ids),
            DoctorService.deleted_at.is_(None),
        )
        .order_by(DoctorService.doctor_id.asc(), DoctorService.priority.desc())
    )
    out: dict[int, int] = {}
    for svc in res.scalars().all():
        if svc.doctor_id not in out:
            out[svc.doctor_id] = max(1, int(svc.average_duration_minutes or 15))
    return out


async def _recalculate_queue_eta(db: AsyncSession, queue_date: date) -> None:
    res = await db.execute(
        select(QueueItem)
        .where(
            QueueItem.queue_date == queue_date,
            QueueItem.status == "WAITING",
        )
        .order_by(
            nulls_last(QueueItem.sort_order.asc()),
            QueueItem.created_at.asc(),
            QueueItem.id.asc(),
        )
    )
    items = list(res.scalars().all())
    doctor_ids = [int(i.doctor_id) for i in items if i.doctor_id]
    durations = await _get_avg_duration_map(db, doctor_ids)
    
    # Calculate base_time from IN_PROGRESS visits per doctor
    doctor_base_times: dict[int, datetime] = {}
    for doctor_id in doctor_ids:
        in_progress_res = await db.execute(
            select(QueueItem).where(
                QueueItem.doctor_id == doctor_id,
                QueueItem.queue_date == queue_date,
                QueueItem.status == "IN_PROGRESS",
                QueueItem.deleted_at.is_(None),
            )
        )
        in_progress = in_progress_res.scalars().first()
        
        if in_progress:
            # Patient is being served; use created_at as proxy for started (QueueItem has no started_at)
            avg_duration = durations.get(doctor_id, 15)
            base = in_progress.created_at or datetime.now(timezone.utc)
            doctor_base_times[doctor_id] = base + timedelta(minutes=avg_duration)
        else:
            # No one being served, base time is now
            doctor_base_times[doctor_id] = datetime.now(timezone.utc)
    
    # Update estimated_start_time for each WAITING item
    for item in items:
        doctor_id = int(item.doctor_id) if item.doctor_id else 0
        if doctor_id not in doctor_base_times:
            doctor_base_times[doctor_id] = datetime.now(timezone.utc)
        
        item.estimated_start_time = doctor_base_times[doctor_id]
        avg_duration = durations.get(doctor_id, 15)
        doctor_base_times[doctor_id] += timedelta(minutes=avg_duration)
    
    await db.commit()


@router.post("/queue", response_model=QueueItemRead, status_code=201)
async def add_to_queue(
    item: QueueItemCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_roles(UserRole.ADMIN, UserRole.RECEPTIONIST, UserRole.OWNER, UserRole.DOCTOR)),
):
    """Add patient to queue with doctor-specific prefix (A-001, B-001, etc.)"""
    today = date.today()

    # Require active shift before adding to queue
    shift_result = await db.execute(
        select(Shift).where(Shift.is_closed == False, Shift.deleted_at.is_(None))
    )
    if not shift_result.scalars().first():
        raise HTTPException(
            status_code=400,
            detail="Смена не открыта. Откройте смену для добавления в очередь.",
        )

    # Get doctor to fetch queue_prefix (must be active and not deleted)
    doctor_result = await db.execute(
        select(Doctor)
        .options(selectinload(Doctor.services))
        .where(
            Doctor.id == item.doctor_id,
            Doctor.deleted_at.is_(None),
            Doctor.is_active == True,
        )
    )
    doctor = doctor_result.scalar_one_or_none()

    if not doctor:
        raise HTTPException(status_code=404, detail="Doctor not found or inactive")

    # Resolve patient: use provided patient_id, or default to patient 1 (shared guest)
    patient_name = (item.patient_name or "").strip()
    custom_name = (item.custom_name or "").strip()
    if not patient_name and not custom_name:
        patient_name = "Бемор"
    if custom_name and not patient_name:
        patient_name = custom_name

    if not item.patient_id:
        # Use shared guest patient: Бемор, +998000000000 (id=1 from migration or find/create)
        default_patient = await db.get(Patient, 1)
        if not default_patient:
            guest_result = await db.execute(
                select(Patient).where(Patient.phone == "+998000000000").limit(1)
            )
            default_patient = guest_result.scalars().first()
            if not default_patient:
                default_patient = Patient(full_name="Бемор", phone="+998000000000")
                db.add(default_patient)
                await db.flush()
                await db.refresh(default_patient)
        item.patient_id = default_patient.id

    manual_number = (item.manual_queue_number or "").strip() or None

    # Check manual_queue_number uniqueness per doctor per day
    if manual_number:
        existing = await db.execute(
            select(QueueItem).where(
                QueueItem.doctor_id == item.doctor_id,
                QueueItem.queue_date == today,
                QueueItem.manual_queue_number == manual_number,
                QueueItem.deleted_at.is_(None),
            )
        )
        if existing.scalars().first():
            raise HTTPException(
                status_code=400,
                detail="Номер очереди занят",
            )

    # Auto-create transaction only when status is paid (COMPLETED)
    # WAITING/empty items must not create transaction until payment
    if item.patient_id and not item.transaction_id and item.status in ("COMPLETED", "PAID"):
        top_service = None
        if doctor.services:
            top_service = max(doctor.services, key=lambda s: s.priority or 0)
        auto_amount = int(top_service.price or 0) * int(item.quantity or 1) if top_service else 0
        manual_amount_val = int(item.manual_amount) if item.manual_amount is not None else 0
        effective_amount = auto_amount if auto_amount > 0 else manual_amount_val
        if effective_amount > 0:
            shift_result = await db.execute(
                select(Shift)
                .where(Shift.is_closed == False, Shift.deleted_at.is_(None))
                .with_for_update()
            )
            active_shift = shift_result.scalars().first()
            if active_shift:
                new_tx = Transaction(
                    shift_id=active_shift.id,
                    patient_id=item.patient_id,
                    amount=effective_amount,
                    quantity=int(item.quantity or 1),
                    doctor_id=str(doctor.id),
                    payment_method=PaymentMethod.CASH,
                    cash_amount=effective_amount,
                    description=f"{doctor.full_name} x{int(item.quantity or 1)}",
                    created_by_user_id=user.id,
                )
                db.add(new_tx)
                await db.flush()
                item.transaction_id = new_tx.id
                active_shift.total_cash = int(active_shift.total_cash or 0) + effective_amount
                await db.flush()

    # Generate sequential number atomically with retry on unique constraint.
    # This prevents collisions when two patients are registered at the same time.
    for _attempt in range(10):
        # Next sort order for today (global)
        order_res = await db.execute(
            select(func.coalesce(func.max(QueueItem.sort_order), 0) + 1).where(
                QueueItem.queue_date == today
            )
        )
        next_order = int(order_res.scalar_one())

        # Next seq for this doctor & date
        res = await db.execute(
            select(func.coalesce(func.max(QueueItem.sequence), 0) + 1).where(
                QueueItem.doctor_id == item.doctor_id, QueueItem.queue_date == today
            )
        )
        next_seq = int(res.scalar_one())

        ticket_number = (
            manual_number if manual_number else f"{doctor.queue_prefix}-{next_seq:03d}"
        )
        new_item = QueueItem(
            **item.model_dump(exclude={"patient_name"}),
            patient_name=patient_name,
            ticket_number=ticket_number,
            queue_date=today,
            sequence=next_seq,
            sort_order=next_order,
        )
        if item.patient_id:
            patient = await db.get(Patient, item.patient_id)
            if patient and patient.phone:
                new_item.patient_phone_snapshot = patient.phone

        db.add(new_item)
        try:
            should_update_tx = bool(
                item.transaction_id
                and (
                    item.manual_amount is not None
                    or item.custom_name
                    or manual_number
                    or int(item.quantity or 1) != 1
                )
            )
            if should_update_tx:
                tx = await db.get(Transaction, item.transaction_id)
                if not tx:
                    raise HTTPException(status_code=404, detail="Transaction not found")
                qty = int(item.quantity or 1)
                default_service_price = 0
                if doctor.services:
                    top_service = max(doctor.services, key=lambda s: s.priority or 0)
                    default_service_price = int(top_service.price or 0)
                computed_amount = (
                    int(item.manual_amount)
                    if item.manual_amount is not None
                    else default_service_price * qty
                )
                if computed_amount != tx.amount:
                    delta = computed_amount - int(tx.amount)
                    if tx.payment_method == "MIXED":
                        raise HTTPException(
                            status_code=400,
                            detail="Cannot change amount for mixed payment",
                        )
                    shift = await db.get(Shift, tx.shift_id) if tx.shift_id else None
                    if not shift:
                        raise HTTPException(
                            status_code=400,
                            detail="Shift not found for transaction update",
                        )
                    if tx.payment_method == "CASH":
                        tx.cash_amount = int(tx.cash_amount or 0) + delta
                        shift.total_cash = int(shift.total_cash or 0) + delta
                    elif tx.payment_method == "CARD":
                        tx.card_amount = int(tx.card_amount or 0) + delta
                        shift.total_card = int(shift.total_card or 0) + delta
                    elif tx.payment_method == "TRANSFER":
                        tx.transfer_amount = int(tx.transfer_amount or 0) + delta
                        shift.total_transfer = int(shift.total_transfer or 0) + delta
                    if (
                        int(shift.total_cash or 0) < 0
                        or int(shift.total_card or 0) < 0
                        or int(shift.total_transfer or 0) < 0
                    ):
                        raise HTTPException(
                            status_code=400,
                            detail="Shift totals cannot be negative",
                        )
                    tx.amount = computed_amount
                tx.quantity = qty
                tx.description = f"{doctor.full_name} x{qty}"
            await db.commit()
            await _recalculate_queue_eta(db, today)
            await db.refresh(new_item)
            resp = QueueItemRead.model_validate(new_item)
            resp.doctor_name = doctor.full_name
            if new_item.transaction_id:
                tx = await db.get(Transaction, new_item.transaction_id)
                resp.amount = int(tx.amount) if tx else None
            return resp
        except IntegrityError as e:
            await db.rollback()
            err_msg = str(e.orig) if hasattr(e, "orig") and e.orig else str(e)
            if "ix_queue_items_doctor_date_manual_unique" in err_msg or "manual_queue_number" in err_msg.lower():
                raise HTTPException(status_code=400, detail="Номер очереди занят")
            continue

    raise HTTPException(
        status_code=409, detail="Failed to allocate queue ticket (try again)"
    )


@router.get("/queue", response_model=list[QueueItemRead])
async def get_queue(
    range: str = "today",
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.RECEPTIONIST, UserRole.OWNER, UserRole.DOCTOR)),
):
    # Return queue items for selected range (incl. CANCELLED for analysis; only DELETE removes)
    now = datetime.now()
    start_of_today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if range == "2days":
        start = start_of_today - timedelta(days=1)
    elif range == "shift":
        shift_result = await db.execute(
            select(Shift)
            .where(Shift.is_closed.is_(False))
            .order_by(Shift.start_time.desc())
        )
        active_shift = shift_result.scalars().first()
        start = active_shift.start_time if active_shift else start_of_today
    else:
        start = start_of_today

    result = await db.execute(
        select(QueueItem)
        .options(
            selectinload(QueueItem.doctor).selectinload(Doctor.services),
            selectinload(QueueItem.patient),
        )
        .where(
            QueueItem.created_at >= start,
            QueueItem.deleted_at.is_(None),
        )
        .order_by(
            nulls_last(QueueItem.sort_order.asc()),
            QueueItem.created_at.asc(),
            QueueItem.id.asc(),
        )
    )
    items = result.scalars().all()

    # Enrichment
    response = []
    for i in items:
        # Convert to Pydantic and add doc name manually if needed or rely on relationship
        # Pydantic model has doctor_name, we can map it
        doc_name = i.doctor.full_name if i.doctor else "Unknown"
        # We need to create Read object
        resp_item = QueueItemRead.model_validate(i)
        resp_item.doctor_name = doc_name
        resp_item.patient_telegram_chat_id = i.patient.telegram_chat_id if i.patient else None
        resp_item.patient_phone = (
            i.patient_phone_snapshot
            if i.patient_phone_snapshot
            else (i.patient.phone if i.patient else None)
        )
        if i.transaction_id:
            tx = await db.get(Transaction, i.transaction_id)
            resp_item.amount = int(tx.amount) if tx else None
        elif i.status == "WAITING":
            if i.manual_amount is not None:
                resp_item.amount = int(i.manual_amount)
            elif i.doctor and i.doctor.services:
                top_svc = max(i.doctor.services, key=lambda s: s.priority or 0)
                resp_item.amount = int(top_svc.price or 0) * int(i.quantity or 1) or None
        response.append(resp_item)

    return response


@router.get("/queue/check-number")
async def check_queue_number(
    doctor_id: int,
    manual_queue_number: str,
    queue_date: str | None = None,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.RECEPTIONIST, UserRole.OWNER, UserRole.DOCTOR)),
):
    """Check if manual_queue_number is already taken for the doctor on the given date."""
    num = (manual_queue_number or "").strip().replace(" ", "")
    if not num or not num.isdigit():
        return {"available": True}
    qd = date.today()
    if queue_date:
        try:
            qd = datetime.strptime(queue_date, "%Y-%m-%d").date()
        except ValueError:
            pass
    result = await db.execute(
        select(QueueItem.id).where(
            QueueItem.doctor_id == doctor_id,
            QueueItem.queue_date == qd,
            QueueItem.manual_queue_number == num,
            QueueItem.deleted_at.is_(None),
        ).limit(1)
    )
    exists = result.scalar() is not None
    return {"available": not exists}


@router.patch("/queue/{item_id}", response_model=QueueItemRead)
async def update_queue_status(
    item_id: int,
    update: QueueItemUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(require_roles(UserRole.ADMIN, UserRole.RECEPTIONIST, UserRole.OWNER, UserRole.DOCTOR)),
):
    item_result = await db.execute(
        select(QueueItem)
        .options(
            selectinload(QueueItem.doctor),
            selectinload(QueueItem.patient),
        )
        .where(QueueItem.id == item_id)
    )
    item = item_result.scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Queue item not found")

    # Process quantity/amount before status so transaction creation uses updated values
    if update.quantity is not None:
        if update.quantity < 1:
            raise HTTPException(status_code=400, detail="quantity must be >= 1")
        item.quantity = update.quantity
        if not item.transaction_id:
            item.manual_amount = None
    if update.amount is not None and not item.transaction_id:
        if update.amount < 0:
            raise HTTPException(status_code=400, detail="amount must be >= 0")
        item.manual_amount = int(update.amount)

    if update.status is not None:
        old_status = item.status
        item.status = update.status
        if update.status == "IN_PROGRESS":
            item.entered_at = datetime.now(timezone.utc)
        elif update.status == "FINISHED":
            item.finished_at = datetime.now(timezone.utc)
        # Create refund transaction when status changes to REFUNDED (minus from cash, same doctor)
        if update.status == "REFUNDED" and item.transaction_id:
            original_tx = await db.get(Transaction, item.transaction_id)
            if original_tx and original_tx.deleted_at is None and int(original_tx.amount or 0) > 0:
                shift_result = await db.execute(
                    select(Shift).where(Shift.is_closed == False, Shift.deleted_at.is_(None)).with_for_update()
                )
                active_shift = shift_result.scalar_one_or_none()
                if active_shift:
                    refund_amount = -abs(int(original_tx.amount or 0))
                    delta_cash = (
                        -abs(int(original_tx.cash_amount or 0))
                        if original_tx.payment_method == PaymentMethod.MIXED
                        else (refund_amount if original_tx.payment_method == PaymentMethod.CASH else 0)
                    )
                    delta_card = (
                        -abs(int(original_tx.card_amount or 0))
                        if original_tx.payment_method == PaymentMethod.MIXED
                        else (refund_amount if original_tx.payment_method == PaymentMethod.CARD else 0)
                    )
                    delta_transfer = (
                        -abs(int(original_tx.transfer_amount or 0))
                        if original_tx.payment_method == PaymentMethod.MIXED
                        else (refund_amount if original_tx.payment_method == PaymentMethod.TRANSFER else 0)
                    )
                    new_cash = int(active_shift.total_cash or 0) + delta_cash
                    new_card = int(active_shift.total_card or 0) + delta_card
                    new_transfer = int(active_shift.total_transfer or 0) + delta_transfer
                    if new_cash >= 0 and new_card >= 0 and new_transfer >= 0:
                        refund_tx = Transaction(
                            shift_id=active_shift.id,
                            patient_id=original_tx.patient_id,
                            amount=refund_amount,
                            quantity=int(original_tx.quantity or 1),
                            doctor_id=original_tx.doctor_id,
                            payment_method=original_tx.payment_method,
                            cash_amount=-abs(int(original_tx.cash_amount or 0)),
                            card_amount=-abs(int(original_tx.card_amount or 0)),
                            transfer_amount=-abs(int(original_tx.transfer_amount or 0)),
                            description=f"Возврат (очередь #{item.ticket_number}, orig TX #{original_tx.id})",
                            related_transaction_id=original_tx.id,
                            created_by_user_id=user.id,
                        )
                        db.add(refund_tx)
                        await db.flush()
                        active_shift.total_cash = new_cash
                        active_shift.total_card = new_card
                        active_shift.total_transfer = new_transfer
                        await db.flush()
                    else:
                        raise HTTPException(
                            status_code=400,
                            detail="Возврат приведёт к отрицательным остаткам в кассе",
                        )
        # Re-payment when status changes from REFUNDED back to COMPLETED (income again)
        elif (
            old_status == "REFUNDED"
            and update.status in ("COMPLETED", "PAID")
            and item.transaction_id
        ):
            original_tx = await db.get(Transaction, item.transaction_id)
            if original_tx and original_tx.deleted_at is None and int(original_tx.amount or 0) > 0:
                shift_result = await db.execute(
                    select(Shift).where(Shift.is_closed == False, Shift.deleted_at.is_(None)).with_for_update()
                )
                active_shift = shift_result.scalar_one_or_none()
                if active_shift:
                    pay_amount = abs(int(original_tx.amount or 0))
                    cash_amt = abs(int(original_tx.cash_amount or 0))
                    card_amt = abs(int(original_tx.card_amount or 0))
                    transfer_amt = abs(int(original_tx.transfer_amount or 0))
                    repay_tx = Transaction(
                        shift_id=active_shift.id,
                        patient_id=original_tx.patient_id,
                        amount=pay_amount,
                        quantity=int(original_tx.quantity or 1),
                        doctor_id=original_tx.doctor_id,
                        payment_method=original_tx.payment_method,
                        cash_amount=cash_amt,
                        card_amount=card_amt,
                        transfer_amount=transfer_amt,
                        description=f"Повторная оплата (очередь #{item.ticket_number}, orig TX #{original_tx.id})",
                        created_by_user_id=user.id,
                    )
                    db.add(repay_tx)
                    await db.flush()
                    active_shift.total_cash = int(active_shift.total_cash or 0) + cash_amt
                    active_shift.total_card = int(active_shift.total_card or 0) + card_amt
                    active_shift.total_transfer = int(active_shift.total_transfer or 0) + transfer_amt
                    await db.flush()
        # Create transaction when status changes to paid (WAITING -> COMPLETED)
        elif update.status in ("COMPLETED", "PAID") and not item.transaction_id and item.patient_id and item.doctor_id:
            doctor_result = await db.execute(
                select(Doctor).options(selectinload(Doctor.services)).where(Doctor.id == item.doctor_id)
            )
            doctor = doctor_result.scalar_one_or_none()
            if doctor:
                top_service = max(doctor.services, key=lambda s: s.priority or 0) if doctor.services else None
                effective_amount = 0
                if update.amount is not None and int(update.amount) >= 0:
                    effective_amount = int(update.amount)
                elif item.manual_amount is not None and int(item.manual_amount) >= 0:
                    effective_amount = int(item.manual_amount)
                elif top_service:
                    effective_amount = int(top_service.price or 0) * int(item.quantity or 1)
                if effective_amount > 0:
                    shift_result = await db.execute(
                        select(Shift).where(Shift.is_closed == False, Shift.deleted_at.is_(None)).with_for_update()
                    )
                    active_shift = shift_result.scalar_one_or_none()
                    if active_shift:
                        new_tx = Transaction(
                            shift_id=active_shift.id,
                            patient_id=item.patient_id,
                            amount=effective_amount,
                            quantity=int(item.quantity or 1),
                            doctor_id=str(doctor.id),
                            payment_method=PaymentMethod.CASH,
                            cash_amount=effective_amount,
                            description=f"{doctor.full_name} x{int(item.quantity or 1)}",
                            created_by_user_id=user.id,
                        )
                        db.add(new_tx)
                        await db.flush()
                        item.transaction_id = new_tx.id
                        active_shift.total_cash = int(active_shift.total_cash or 0) + effective_amount
                        await db.flush()

    if update.patient_id is not None:
        # Link to existing patient (from autocomplete selection)
        linked_patient = await db.get(Patient, update.patient_id)
        if linked_patient and linked_patient.deleted_at is None:
            item.patient_id = linked_patient.id
            item.patient_name = linked_patient.full_name
            item.patient_phone_snapshot = linked_patient.phone

    elif update.patient_name is not None or update.patient_phone is not None:
        from backend.modules.patients.schemas import _normalize_phone

        patient = await db.get(Patient, item.patient_id) if item.patient_id else None
        new_name = (update.patient_name or "").strip() if update.patient_name is not None else None
        new_phone = (update.patient_phone or "").strip() if update.patient_phone is not None else None

        # Patient is shared if other queue items also reference this patient_id
        other_count_result = await db.execute(
            select(func.count()).select_from(QueueItem).where(
                QueueItem.patient_id == item.patient_id,
                QueueItem.id != item_id,
                QueueItem.deleted_at.is_(None),
            )
        )
        is_shared = (other_count_result.scalar() or 0) > 0

        if is_shared or not patient:
            # Shared by multiple items or orphaned: create new patient
            if new_phone:
                full_name = new_name or (patient.full_name if patient else "Бемор")
                new_patient = Patient(full_name=full_name, phone=_normalize_phone(new_phone))
                db.add(new_patient)
                await db.flush()
                item.patient_id = new_patient.id
                item.patient_name = full_name
                item.patient_phone_snapshot = new_patient.phone
            elif new_name:
                new_patient = Patient(full_name=new_name, phone="+998000000000")
                db.add(new_patient)
                await db.flush()
                item.patient_id = new_patient.id
                item.patient_name = new_name
        elif patient:
            # Specific patient: update existing (e.g. first edit FIO, second edit phone)
            if new_name is not None:
                patient.full_name = new_name or patient.full_name
                item.patient_name = patient.full_name
            if new_phone is not None:
                patient.phone = _normalize_phone(new_phone)
                item.patient_phone_snapshot = patient.phone

    if update.notes is not None:
        item.notes = update.notes

    needs_tx_update = (update.amount is not None and item.transaction_id) or (
        update.quantity is not None and item.transaction_id
    )
    if needs_tx_update:
        if not item.transaction_id:
            raise HTTPException(
                status_code=400, detail="Queue item is not linked to a transaction"
            )
        tx = await db.get(Transaction, item.transaction_id)
        if not tx:
            raise HTTPException(status_code=404, detail="Transaction not found")

        # Determine new amount: explicit update, or recalc from quantity change
        new_amount = None
        if update.amount is not None:
            if update.amount == 0:
                raise HTTPException(status_code=400, detail="amount must not be 0")
            new_amount = int(update.amount)
        elif update.quantity is not None and int(tx.quantity or 1) > 0:
            # Recalc total from price-per-unit * new quantity
            price_per_unit = int(tx.amount or 0) / int(tx.quantity or 1)
            new_amount = int(round(price_per_unit * int(update.quantity)))

        if new_amount is not None:
            delta = new_amount - int(tx.amount or 0)
            if tx.payment_method == "MIXED":
                raise HTTPException(
                    status_code=400,
                    detail="Cannot change amount for mixed payment",
                )
            shift = await db.get(Shift, tx.shift_id) if tx.shift_id else None
            if not shift:
                raise HTTPException(
                    status_code=400,
                    detail="Shift not found for transaction update",
                )
            if tx.payment_method == "CASH":
                shift.total_cash = int(shift.total_cash or 0) + delta
                tx.cash_amount = int(tx.cash_amount or 0) + delta
            elif tx.payment_method == "CARD":
                shift.total_card = int(shift.total_card or 0) + delta
                tx.card_amount = int(tx.card_amount or 0) + delta
            elif tx.payment_method == "TRANSFER":
                shift.total_transfer = int(shift.total_transfer or 0) + delta
                tx.transfer_amount = int(tx.transfer_amount or 0) + delta
            if (
                int(shift.total_cash or 0) < 0
                or int(shift.total_card or 0) < 0
                or int(shift.total_transfer or 0) < 0
            ):
                raise HTTPException(
                    status_code=400,
                    detail="Shift totals cannot be negative",
                )
            tx.amount = new_amount

        if update.quantity is not None:
            tx.quantity = int(update.quantity)

        if update.quantity is not None and item.doctor_id:
            doctor_result = await db.execute(
                select(Doctor).where(Doctor.id == item.doctor_id)
            )
            doctor = doctor_result.scalar_one_or_none()
            if doctor:
                tx.description = f"{doctor.full_name} x{item.quantity}"

    await db.commit()
    if update.status is not None:
        await _recalculate_queue_eta(db, item.queue_date)
        
        # Send Telegram notifications if status changed to IN_PROGRESS
        if update.status == "IN_PROGRESS":
            # Fetch patient and doctor
            patient = await db.get(Patient, item.patient_id)
            doctor = await db.get(Doctor, item.doctor_id) if item.doctor_id else None
            
            if patient and doctor:
                # Notify called patient
                await notify_patient_called(item, doctor, patient)
                logger.info(f"Notified patient {patient.id} they were called")
                
                # Find and notify next patient
                next_item_result = await db.execute(
                    select(QueueItem).where(
                        QueueItem.queue_date == item.queue_date,
                        QueueItem.doctor_id == item.doctor_id,
                        QueueItem.status == "WAITING",
                        QueueItem.id != item.id,
                    ).order_by(QueueItem.sort_order).limit(1)
                )
                next_item = next_item_result.scalar_one_or_none()
                if next_item:
                    next_patient = await db.get(Patient, next_item.patient_id)
                    if next_patient:
                        await notify_patient_next_in_line(next_item, next_patient)
                        logger.info(f"Notified patient {next_patient.id} they are next")
    
    await db.refresh(item)
    resp = QueueItemRead.model_validate(item)
    resp.doctor_name = item.doctor.full_name if item.doctor else None
    resp.patient_telegram_chat_id = item.patient.telegram_chat_id if item.patient else None
    resp.patient_phone = (
        item.patient_phone_snapshot
        or (item.patient.phone if item.patient else None)
    )
    if item.transaction_id:
        tx = await db.get(Transaction, item.transaction_id)
        resp.amount = int(tx.amount) if tx else None
    return resp


def _client_ip(request: Request) -> str | None:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    if request.client:
        return request.client.host
    return None


@router.delete("/queue/{item_id}")
async def delete_queue_item(
    request: Request,
    item_id: int,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(
        require_roles(UserRole.ADMIN, UserRole.RECEPTIONIST, UserRole.OWNER)
    ),
):
    """Soft-delete a queue item (remove from queue)."""
    item = await db.get(QueueItem, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Queue item not found")
    if item.deleted_at is not None:
        raise HTTPException(status_code=404, detail="Queue item already deleted")

    patient_name = item.patient_name or item.custom_name
    doctor_id = item.doctor_id
    ticket = item.ticket_number
    await log_action(
        user_id=user.id,
        action="DELETE",
        module="RECEPTION",
        entity_id=str(item_id),
        details={
            "patient_name": patient_name,
            "doctor_id": doctor_id,
            "ticket_number": ticket,
        },
        ip_address=_client_ip(request),
    )
    item.soft_delete()
    await db.commit()
    await _recalculate_queue_eta(db, item.queue_date)
    return {"message": "Queue item deleted"}


@router.post("/queue/{item_id}/enter", response_model=QueueItemRead)
async def enter_queue_item(
    item_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.RECEPTIONIST, UserRole.OWNER, UserRole.DOCTOR)),
):
    """Mark patient as entered (observer: patient walked into office)."""
    item = await db.get(QueueItem, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Queue item not found")
    if item.status not in ("WAITING", "IN_PROGRESS"):
        raise HTTPException(
            status_code=400,
            detail=f"Cannot mark as entered: status is {item.status}",
        )
    item.status = "FINISHED"
    item.finished_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(item)
    return item


@router.post("/queue/{item_id}/late", response_model=QueueItemRead)
async def late_queue_item(
    item_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.RECEPTIONIST, UserRole.OWNER, UserRole.DOCTOR)),
):
    """Mark patient as late (move back 3 spots). Same as move-back."""
    item = await db.get(QueueItem, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Queue item not found")
    if item.status == "IN_PROGRESS":
        item.status = "WAITING"
        await db.flush()
    return await move_back_queue_item(item_id, db, _user)


@router.post("/queue/{item_id}/move-back", response_model=QueueItemRead)
async def move_back_queue_item(
    item_id: int,
    db: AsyncSession = Depends(get_db),
    _user=Depends(require_roles(UserRole.ADMIN, UserRole.RECEPTIONIST, UserRole.OWNER, UserRole.DOCTOR)),
):
    item = await db.get(QueueItem, item_id)
    if not item:
        raise HTTPException(status_code=404, detail="Queue item not found")
    if item.status != "WAITING":
        raise HTTPException(status_code=400, detail="Queue item is not waiting")

    res = await db.execute(
        select(QueueItem)
        .where(
            QueueItem.queue_date == item.queue_date,
            QueueItem.status != "CANCELLED",
        )
        .order_by(
            nulls_last(QueueItem.sort_order.asc()),
            QueueItem.created_at.asc(),
            QueueItem.id.asc(),
        )
    )
    all_items = list(res.scalars().all())
    waiting_items = [q for q in all_items if q.status == "WAITING"]
    try:
        idx = next(i for i, q in enumerate(waiting_items) if q.id == item.id)
    except StopIteration:
        raise HTTPException(status_code=400, detail="Queue item not in waiting list")

    move_by = 3
    new_idx = min(idx + move_by, len(waiting_items) - 1)
    if new_idx != idx:
        moved = waiting_items.pop(idx)
        waiting_items.insert(new_idx, moved)

    # Rebuild list, preserving non-waiting order/positions
    waiting_iter = iter(waiting_items)
    reordered: list[QueueItem] = []
    for q in all_items:
        if q.status == "WAITING":
            reordered.append(next(waiting_iter))
        else:
            reordered.append(q)

    for order, q in enumerate(reordered, start=1):
        q.sort_order = order

    await db.commit()
    await _recalculate_queue_eta(db, item.queue_date)
    await db.refresh(item)
    return item
