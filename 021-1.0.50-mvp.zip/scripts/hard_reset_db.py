#!/usr/bin/env python3
"""
Hard reset database and migration history.

This is a destructive operation that:
1. Backs up essential data (users, doctors, settings)
2. Wipes ALL migrations from backend/alembic/versions/
3. Drops all tables from the database
4. Creates fresh initial migration (initial_schema_v2)
5. Applies migration to create clean schema
6. Seeds data from backup or creates defaults

WARNING: This deletes all data. Use with caution!

Usage:
    python scripts/hard_reset_db.py [--no-backup] [--skip-seed]

Options:
    --no-backup     Skip backing up data before reset
    --skip-seed     Skip seeding data after reset
"""

import asyncio
import shutil
import subprocess
import sys
from pathlib import Path
from datetime import datetime

# Ensure backend package is importable
repo_root = Path(__file__).resolve().parents[1]
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from backend.core.config import settings
from backend.core.database import engine
from sqlalchemy import text


async def drop_all_tables():
    """Drop all tables from the database"""
    print("[*] Dropping all tables from database...")
    
    async with engine.begin() as conn:
        # Simple approach: drop all tables using CASCADE
        # This works for PostgreSQL without needing inspect
        try:
            # Get all table names using raw SQL
            result = await conn.execute(text("""
                SELECT tablename FROM pg_tables 
                WHERE schemaname = 'public' 
                ORDER BY tablename DESC
            """))
            tables = [row[0] for row in result.fetchall()]
            
            # Drop alembic_version first (if exists)
            if "alembic_version" in tables:
                await conn.execute(text("DROP TABLE IF EXISTS alembic_version CASCADE"))
                print("  [OK] Dropped alembic_version")
            
            # Drop all other tables
            for table in tables:
                if table != "alembic_version":
                    try:
                        await conn.execute(text(f"DROP TABLE IF EXISTS \"{table}\" CASCADE"))
                        print(f"  [OK] Dropped table: {table}")
                    except Exception as e:
                        print(f"  [WARN] Could not drop {table}: {e}")
            
            # Drop all ENUM types
            result = await conn.execute(text("""
                SELECT typname FROM pg_type 
                WHERE typnamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'public')
                AND typtype = 'e'
            """))
            enum_types = [row[0] for row in result.fetchall()]
            
            for enum_type in enum_types:
                try:
                    await conn.execute(text(f"DROP TYPE IF EXISTS {enum_type} CASCADE"))
                    print(f"  [OK] Dropped ENUM type: {enum_type}")
                except Exception as e:
                    print(f"  [WARN] Could not drop ENUM {enum_type}: {e}")
            
            print("[OK] All tables and types dropped")
        except Exception as e:
            print(f"  [ERROR] {e}")
            raise


def wipe_migrations():
    """Delete all migration files from backend/alembic/versions/"""
    print("\n[*] Wiping migration history...")
    
    versions_dir = repo_root / "backend" / "alembic" / "versions"
    
    if not versions_dir.exists():
        print(f"  [WARN] Versions directory does not exist: {versions_dir}")
        return False
    
    # Keep __pycache__ and __init__.py, delete everything else
    for item in versions_dir.iterdir():
        if item.is_file() and item.name != "__init__.py":
            try:
                item.unlink()
                print(f"  [OK] Deleted: {item.name}")
            except Exception as e:
                print(f"  [ERROR] Could not delete {item.name}: {e}")
                return False
        elif item.is_dir() and item.name == "__pycache__":
            try:
                shutil.rmtree(item)
                print(f"  [OK] Deleted __pycache__")
            except Exception as e:
                print(f"  [WARN] Could not delete __pycache__: {e}")
    
    print("[OK] Migration history wiped")
    return True


def create_initial_migration():
    """Create initial migration with autogenerate"""
    print("\n[*] Creating fresh initial migration...")
    
    # Change to backend directory
    backend_dir = repo_root / "backend"
    
    try:
        result = subprocess.run(
            [sys.executable, "-m", "alembic", "revision", "--autogenerate", "-m", "initial_schema_v2"],
            cwd=backend_dir,
            capture_output=True,
            text=True,
            timeout=30,
        )
        
        if result.returncode != 0:
            print(f"[ERROR] Alembic revision failed:")
            print(result.stdout)
            print(result.stderr)
            return False
        
        print(f"[OK] Initial migration created")
        print(f"  Output: {result.stdout}")
        return True
    
    except subprocess.TimeoutExpired:
        print(f"[ERROR] Alembic command timed out")
        return False
    except Exception as e:
        print(f"[ERROR] Error creating migration: {e}")
        return False


def apply_migrations():
    """Apply all migrations (alembic upgrade head)"""
    print("\n[*] Applying migrations...")
    
    backend_dir = repo_root / "backend"
    
    try:
        result = subprocess.run(
            [sys.executable, "-m", "alembic", "upgrade", "head"],
            cwd=backend_dir,
            capture_output=True,
            text=True,
            timeout=60,
        )
        
        if result.returncode != 0:
            print(f"[ERROR] Alembic upgrade failed:")
            print(result.stdout)
            print(result.stderr)
            return False
        
        print(f"[OK] Migrations applied successfully")
        print(f"  Output: {result.stdout}")
        return True
    
    except subprocess.TimeoutExpired:
        print(f"[ERROR] Alembic command timed out")
        return False
    except Exception as e:
        print(f"[ERROR] Error applying migrations: {e}")
        return False


def seed_data():
    """Restore data from backup or create defaults"""
    print("\n[*] Seeding essential data...")
    
    try:
        result = subprocess.run(
            [sys.executable, "scripts/seed_essential_data.py"],
            cwd=repo_root,
            capture_output=True,
            text=True,
            timeout=30,
        )
        
        if result.returncode != 0:
            print(f"[ERROR] Seeding failed:")
            print(result.stdout)
            print(result.stderr)
            return False
        
        print(result.stdout)
        return True
    
    except subprocess.TimeoutExpired:
        print(f"[ERROR] Seeding command timed out")
        return False
    except Exception as e:
        print(f"[ERROR] Error seeding data: {e}")
        return False


async def main():
    """Main hard reset orchestration"""
    
    # Parse arguments
    skip_backup = "--no-backup" in sys.argv
    skip_seed = "--skip-seed" in sys.argv
    
    print("=" * 80)
    print("[!!!] HARD RESET DATABASE AND MIGRATION HISTORY")
    print("=" * 80)
    print()
    print(f"[DATE] Timestamp: {datetime.now().isoformat()}")
    print(f"[DB] Database: {settings.DATABASE_URL.split('@')[1] if '@' in settings.DATABASE_URL else 'Unknown'}")
    print(f"[PATH] Project: {repo_root}")
    print()
    
    if not skip_backup:
        print("=" * 80)
        print("STEP 1: BACKUP ESSENTIAL DATA")
        print("=" * 80)
        print()
        
        try:
            result = subprocess.run(
                [sys.executable, "scripts/dump_essential_data.py"],
                cwd=repo_root,
                capture_output=True,
                text=True,
                timeout=30,
            )
            
            print(result.stdout)
            if result.returncode != 0 and not result.stderr.startswith("[WARN]"):
                print(result.stderr)
                print("[ERROR] Backup failed. Aborting reset.")
                return False
        except Exception as e:
            print(f"[ERROR] Error running backup: {e}")
            return False
    else:
        print("[SKIP] Skipping backup (--no-backup)")
    
    print()
    print("=" * 80)
    print("STEP 2: DROP ALL TABLES")
    print("=" * 80)
    print()
    
    try:
        await drop_all_tables()
    except Exception as e:
        print(f"[ERROR] Error dropping tables: {e}")
        return False
    
    print()
    print("=" * 80)
    print("STEP 3: WIPE MIGRATION HISTORY")
    print("=" * 80)
    print()
    
    if not wipe_migrations():
        return False
    
    print()
    print("=" * 80)
    print("STEP 4: CREATE FRESH INITIAL MIGRATION")
    print("=" * 80)
    print()
    
    if not create_initial_migration():
        return False
    
    print()
    print("=" * 80)
    print("STEP 5: APPLY MIGRATIONS")
    print("=" * 80)
    print()
    
    if not apply_migrations():
        return False
    
    if not skip_seed:
        print()
        print("=" * 80)
        print("STEP 6: SEED ESSENTIAL DATA")
        print("=" * 80)
        print()
        
        if not seed_data():
            print("[WARN] Seeding failed, but database is ready")
    else:
        print()
        print("[SKIP] Skipping seed (--skip-seed)")
    
    print()
    print("=" * 80)
    print("[OK] HARD RESET COMPLETE!")
    print("=" * 80)
    print()
    print("[NOTE] Next steps:")
    print("  1. Verify database is healthy: psql -U <user> -d medx_db -c 'SELECT COUNT(*) FROM users;'")
    print("  2. Start the backend: python -m backend.main")
    print("  3. If seeding failed, run: python scripts/seed_essential_data.py")
    print()
    
    return True


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
