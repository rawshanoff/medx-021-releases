"""
Custom logging handlers: Telegram notifications for WARNING and above.
"""
import logging

import requests

from backend.core.config import settings

TELEGRAM_MAX_MESSAGE_LENGTH = 4096


def _get_telegram_token() -> str:
    return settings.LOG_TELEGRAM_BOT_TOKEN or settings.OBSERVER_BOT_TOKEN or ""


class TelegramLogHandler(logging.Handler):
    """Sends log records to a Telegram chat (WARNING and above)."""

    def emit(self, record: logging.LogRecord) -> None:
        chat_id = getattr(settings, "LOG_TELEGRAM_CHAT_ID", "") or ""
        token = _get_telegram_token()
        if not chat_id or not token:
            return

        try:
            msg = self.format(record)
            if len(msg) > TELEGRAM_MAX_MESSAGE_LENGTH:
                msg = msg[: TELEGRAM_MAX_MESSAGE_LENGTH - 20] + "\n... (truncated)"
            text = f"<b>{record.levelname}</b> {record.name}\n<pre>{_escape_html(msg)}</pre>"
            url = f"https://api.telegram.org/bot{token}/sendMessage"
            payload = {
                "chat_id": chat_id,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True,
            }
            requests.post(url, json=payload, timeout=10)
        except Exception:
            self.handleError(record)


def _escape_html(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
