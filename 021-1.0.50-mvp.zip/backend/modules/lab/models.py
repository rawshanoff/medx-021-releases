import enum

from backend.core.database import Base, SoftDeleteMixin
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Enum as SQLEnum,
    Float,
    ForeignKey,
    Integer,
    JSON,
    String,
    Text,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func


class LabCategory(Base):
    """Test categories (e.g., Biochemistry, Hormones)"""

    __tablename__ = "lab_categories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False, index=True)

    tests = relationship("LabTest", back_populates="category")


class LabOrderStatus(str, enum.Enum):
    CREATED = "CREATED"
    PAID = "PAID"
    SAMPLED = "SAMPLED"
    PROCESSING = "PROCESSING"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"
    PENDING = "PENDING"  # legacy
    IN_PROGRESS = "IN_PROGRESS"  # legacy


class LabTest(SoftDeleteMixin, Base):
    """Catalog of available lab tests"""

    __tablename__ = "lab_tests"

    id = Column(Integer, primary_key=True, index=True)
    category_id = Column(Integer, ForeignKey("lab_categories.id"), nullable=True, index=True)
    name = Column(String, nullable=False, index=True)
    code = Column(String, unique=True, nullable=True)
    price = Column(Integer, default=0)  # in tiyin/cents
    duration_minutes = Column(Integer, nullable=True)
    units = Column(String, nullable=True)  # e.g., "mmol/L"
    reference_min = Column(Float, nullable=True)
    reference_max = Column(Float, nullable=True)
    template_values = Column(JSON, nullable=True)  # optional defaults for results
    is_active = Column(Boolean, default=True)

    category = relationship("LabCategory", back_populates="tests")
    results = relationship("LabResult", back_populates="test")


class LabOrder(SoftDeleteMixin, Base):
    """Patient's lab test order"""

    __tablename__ = "lab_orders"

    id = Column(Integer, primary_key=True, index=True)
    patient_id = Column(Integer, ForeignKey("patients.id"), nullable=False, index=True)
    doctor_id = Column(Integer, ForeignKey("doctors.id"), nullable=True)
    status = Column(
        SQLEnum(
            LabOrderStatus,
            name="laborderstatus",
            values_callable=lambda enum_cls: [e.name for e in enum_cls],
        ),
        nullable=False,
        default=LabOrderStatus.PENDING,
    )
    total_amount = Column(Integer, default=0)  # in tiyin/cents
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    completed_at = Column(DateTime(timezone=True), nullable=True)

    patient = relationship("Patient")
    doctor = relationship("Doctor")
    results = relationship("LabResult", back_populates="order", cascade="all, delete-orphan")


class LabResult(SoftDeleteMixin, Base):
    """Result of a specific test within a lab order"""

    __tablename__ = "lab_results"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("lab_orders.id"), nullable=False, index=True)
    test_id = Column(Integer, ForeignKey("lab_tests.id"), nullable=False)
    value = Column(Text, nullable=False)
    is_abnormal = Column(Boolean, default=False)
    comment = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    performed_at = Column(DateTime(timezone=True), nullable=True)

    order = relationship("LabOrder", back_populates="results")
    test = relationship("LabTest", back_populates="results")
