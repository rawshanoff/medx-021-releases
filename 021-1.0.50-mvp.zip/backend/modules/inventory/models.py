import enum
from backend.core.database import Base, SoftDeleteMixin
from sqlalchemy import (
    Column,
    DateTime,
    Enum as SQLEnum,
    Float,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func


class StockMovementReason(str, enum.Enum):
    PURCHASE = "PURCHASE"
    USAGE = "USAGE"
    ADJUSTMENT = "ADJUSTMENT"


class InventoryItem(SoftDeleteMixin, Base):
    """Consumable item in inventory"""

    __tablename__ = "inventory_items"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False, index=True)
    unit = Column(String, default="pcs")  # pcs, ml, mg, etc.
    current_stock = Column(Float, default=0.0)
    low_stock_threshold = Column(Float, default=0.0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    movements = relationship("StockMovement", back_populates="item")
    test_consumables = relationship("LabTestConsumable", back_populates="item")


class StockMovement(SoftDeleteMixin, Base):
    """Track stock changes"""

    __tablename__ = "stock_movements"

    id = Column(Integer, primary_key=True, index=True)
    item_id = Column(Integer, ForeignKey("inventory_items.id"), nullable=False, index=True)
    change_amount = Column(Float, nullable=False)  # Negative for deductions
    reason = Column(
        SQLEnum(
            StockMovementReason,
            name="stockmovementreason",
            values_callable=lambda enum_cls: [e.name for e in enum_cls],
        ),
        nullable=False,
    )
    order_id = Column(Integer, ForeignKey("lab_orders.id"), nullable=True)  # Which lab order caused this
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    item = relationship("InventoryItem", back_populates="movements")


class LabTestConsumable(SoftDeleteMixin, Base):
    """Link between Lab Test and Consumable items (the 'recipe')"""

    __tablename__ = "lab_test_consumables"

    id = Column(Integer, primary_key=True, index=True)
    lab_test_id = Column(Integer, ForeignKey("lab_tests.id"), nullable=False, index=True)
    inventory_item_id = Column(Integer, ForeignKey("inventory_items.id"), nullable=False)
    quantity_per_test = Column(Float, nullable=False)  # How much to use per test
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    item = relationship("InventoryItem", back_populates="test_consumables")
